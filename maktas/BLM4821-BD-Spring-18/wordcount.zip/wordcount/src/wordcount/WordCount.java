package wordcount;
import java.io.IOException;
import java.util.StringTokenizer;


import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class WordCount implements Tool{

 
	public int run(String[] args) throws Exception
	{
	

		
	    Configuration conf = new Configuration();
	    Job job = Job.getInstance(conf, "word count");
	    job.setJarByClass(WordCount.class);
	    job.setMapperClass(TokenizerMapper.class);
	    job.setCombinerClass(IntSumReducer.class);
	    job.setReducerClass(IntSumReducer.class);
	    job.setOutputKeyClass(Text.class);
	    job.setOutputValueClass(IntWritable.class);
	    FileInputFormat.addInputPath(job, new Path("/temp/wordcount.txt"));
	    FileOutputFormat.setOutputPath(job, new Path("/output/outputcount.txt"));
		boolean success = job.waitForCompletion(true);
	    return success ? 0 : 1;

	}


  public static void main(String[] args) throws Exception {
	  WordCount driver = new WordCount();
		int exitCode = ToolRunner.run(driver, args);
		System.exit(exitCode);
  }


@Override
public Configuration getConf() {
	// TODO Auto-generated method stub
	return null;
}


@Override
public void setConf(Configuration arg0) {
	// TODO Auto-generated method stub
	
}
}