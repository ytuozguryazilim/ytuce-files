package chapter5;

public class Test {

	   public static void main(String args[]) {
	      int a = 60;	/* 60 = 0011 1100 */
	      int b = 13;	/* 13 = 0000 1101 */
	      int c = 0;
                            /*& (bitwise and)*/
	      c = a & b;        /* 12 = 0000 1100 */
	      System.out.println("a & b = " + c );

	      					/*| (bitwise or)*/
	      c = a | b;        /* 61 = 0011 1101 */
	      System.out.println("a | b = " + c );

	                        /*^ (bitwise XOR) */ //XOR Operator copies the bit if it is set in one operand but not both.
	      c = a ^ b;        /* 49 = 0011 0001 */
	      System.out.println("a ^ b = " + c );

	                        /*left shift*/ //The left operands value is moved left by the number of bits specified by the right operand.
	      c = a << 2;       /* 240 = 1111 0000 */
	      System.out.println("a << 2 = " + c );
	      					
	      					/* (right shift)*/	
	      c = a >> 2;       /* 15 = 1111 */ //The left operands value is moved right by the number of bits specified by the right operand.
	      System.out.println("a >> 2  = " + c );

	   }
	}
