package chapter6;

import edu.rit.crypto.blockcipher.AES256Cipher;

import edu.rit.util.Hex;

import java.security.SecureRandom;

public class TestEncryption {

    public static void main(String[] args) throws Exception {
        //32x8 = 256bit random number
    	String keyStr = Hex.toString(SecureRandom.getSeed(32));
        System.out.println("randomly generated secure key: " + keyStr);
        byte[] key = Hex.toByteArray(keyStr);
        
        String message = "testing message";
        System.out.println("message : "+ message);

        byte[] messageBytes = message.getBytes();
        System.out.println("message length: "+ messageBytes.length+" bytes");

        byte[] encryptedMessage = new byte[16];
        System.arraycopy(messageBytes, 0, encryptedMessage, 0, Math.min(messageBytes.length, 16));
        System.out.println("message to be encrypted: " + Hex.toString(encryptedMessage));

        // Encrypt2 plaintext.
        AES256Cipher cipher = new AES256Cipher(key);
        cipher.encrypt(encryptedMessage);
        System.out.println("encrypted message:       "+ Hex.toString(encryptedMessage));
        
        
    }
}
