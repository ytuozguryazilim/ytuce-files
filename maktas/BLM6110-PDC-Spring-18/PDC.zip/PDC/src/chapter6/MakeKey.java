package chapter6;

import edu.rit.crypto.blockcipher.AES256Cipher;
import edu.rit.util.Hex;

import java.security.SecureRandom;

public class MakeKey {

    public static void main(String[] args) throws Exception {
        //32x8 = 256bit random number
    	String keyStr = Hex.toString(SecureRandom.getSeed(32));
        System.out.println(keyStr);
     
        
    }
}
