package chapter6;

import edu.rit.crypto.blockcipher.AES256Cipher;
import edu.rit.util.Hex;

public class FindKeySeq {

	// Prevent construction.
    private FindKeySeq() {
    }

    // Shared variables.
    // Command line arguments.
    static byte[] plaintext;
    static byte[] ciphertext;
    static byte[] partialkey;
    static int n;
    // Variables for doing trial encryptions.
    static int keyLast4Bytes;
    static int maxcounter;
    static byte[] foundkey;
    static byte[] trialkey;
    static byte[] trialCipherText;
    static AES256Cipher cipher;

    // Main program.
    /**
     * AES partial key search main program.
     */
    public static void main(String[] args)
            throws Exception {
        //Comm.init (args);

        // Start timing.
        long t1 = System.currentTimeMillis();

        // Parse command line arguments.
//        if (args.length != 4) {
//            usage();
//        }
//        plaintext = Hex.toByteArray(args[0]);
        plaintext = Hex.toByteArray("74657374696e67206d65737361676500");
//        ciphertext = Hex.toByteArray(args[1]);
        ciphertext = Hex.toByteArray("ee0c30ac9b03efc3c516d63a83097a26");
//        partialkey = Hex.toByteArray(args[2]);
        partialkey = Hex.toByteArray("b661ca5d5df7e4e66944751923247a91c1632bf1dc5821a5cd8d83fd4d800000");
//        n = Integer.parseInt(args[3]);
        n = 20;

        // Make sure n is not too small or too large.
        if (n < 0) {
            System.err.println("n = " + n + " is too small");
            System.exit(1);
        }
        if (n > 30) {
            System.err.println("n = " + n + " is too large");
            System.exit(1);
        }

        // Set up variables for doing trial encryptions.
        // transfer the value of last four bytes to an int variable: keylsbs
        keyLast4Bytes =
                ( (partialkey[28] & 0xFF) << 24)
                | ((partialkey[29] & 0xFF) << 16)
                | ((partialkey[30] & 0xFF) << 8)
                | ((partialkey[31] & 0xFF));
        
        // calculate the number of keys to test 2^n
        maxcounter = (1 << n);
        
        // construct a trial key. this will get a new value in every iteration
        trialkey = new byte[32];
        System.arraycopy(partialkey, 0, trialkey, 0, 32);
        
        // trialCipherText will get the encrypted message in every iteration
        trialCipherText = new byte[16];
        cipher = new AES256Cipher(trialkey);

        // Try every possible combination of low-order key bits.
        for (int counter = 0; counter < maxcounter; ++counter) {
            // Fill in low-order key bits.
            int last4Bytes = keyLast4Bytes | counter;
            trialkey[28] = (byte) (last4Bytes >> 24);
            trialkey[29] = (byte) (last4Bytes >> 16);
            trialkey[30] = (byte) (last4Bytes >> 8);
            trialkey[31] = (byte) (last4Bytes);

            // Try the key.
            cipher.setKey(trialkey);
            cipher.encrypt(plaintext, trialCipherText);

            // If the result equals the ciphertext, we found the key.
            if (match(ciphertext, trialCipherText)) {
                foundkey = new byte[32];
                System.arraycopy(trialkey, 0, foundkey, 0, 32);
            }
        }

        // Stop timing.
        long t2 = System.currentTimeMillis();

        // Print the key we found.
        System.out.println(Hex.toString(foundkey));
        System.out.println((t2 - t1) + " msec");
    }



// Hidden operations.
    /**
     * Returns true if the two byte arrays match.
     */
    private static boolean match(byte[] a,
            byte[] b) {
        boolean matchsofar = true;
        int n = a.length;
        for (int i = 0; i < n; ++i) {
            matchsofar = matchsofar && a[i] == b[i];
        }
        return matchsofar;
    }

    /**
     * Print a usage message and exit.
     */
    private static void usage() {
        System.err.println("Usage: java edu.rit.smp.keysearch.FindKeySeq <plaintext> <ciphertext> <partialkey> <n>");
        System.err.println("<plaintext> = Plaintext (128-bit hexadecimal number)");
        System.err.println("<ciphertext> = Ciphertext (128-bit hexadecimal number)");
        System.err.println("<partialkey> = Partial key (256-bit hexadecimal number)");
        System.err.println("<n> = Number of key bits to search for");
        System.exit(1);
    }
}

