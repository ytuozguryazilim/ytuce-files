package chapter6;

import edu.rit.crypto.blockcipher.AES256Cipher;
import edu.rit.util.Hex;

public class Encrypt2 {

// Prevent construction.
    private Encrypt2() {}

    private static final int[] mask = new int[]{0xff, 0xfe, 0xfc, 0xf8, 0xf0, 0xe0, 0xc0, 0x80};

    public static void main(String[] args) throws Exception {
        // Parse command line arguments.
        //if (args.length != 3) {
        //    usage();
        // }
        
        //String message = args[0];
        String message = "testing message";

        //String keyStr = args[1];
        String keyStr = "b661ca5d5df7e4e66944751923247a91c1632bf1dc5821a5cd8d83fd4d8d439f";
        byte[] key = Hex.toByteArray(keyStr);

        // number of key bits to search for
        //int n = Integer.parseInt (args[2]);
        int n = 20;

        // Set up plaintext block.
        byte[] messageBytes = message.getBytes();
        System.out.println("mesasge length: "+messageBytes.length+" bytes");

        byte[] encryptedMessage = new byte[16];
        System.arraycopy(messageBytes, 0, encryptedMessage, 0, Math.min(messageBytes.length, 16));
        System.out.println("message to be encrypted: " + Hex.toString(encryptedMessage));

        // Encrypt2 plaintext.
        AES256Cipher cipher = new AES256Cipher(key);
        cipher.encrypt(encryptedMessage);
        System.out.println("encrypted message:       "+ Hex.toString(encryptedMessage));

        // Wipe out n least significant bits of the key.
        int off = 31;
        int len = n;
        while (len >= 8) {
            key[off] = (byte) 0;
            --off;
            len -= 8;
        }
        key[off] &= mask[len];
        System.out.println("original key:             "+keyStr);
        System.out.println("last "+n+" bits deleted key: "+Hex.toString(key));
    }
    

// Hidden operations.
    /**
     * Print a usage message and exit.
     */
    private static void usage() {
        System.err.println("Usage: java edu.rit.smp.keysearch.Encrypt <message> <key> <n>");
        System.err.println("<message> = Message string to encrypt");
        System.err.println("<key> = Encryption key (256-bit hexadecimal number)");
        System.err.println("<n> = Number of key bits to search for");
        System.exit(0);
    }
}
