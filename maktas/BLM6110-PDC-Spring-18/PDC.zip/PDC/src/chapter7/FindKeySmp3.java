package chapter7;

/**
 * original file: edu.rit.smp.keysearch.FindKeySmp2.java
 */
import edu.rit.crypto.blockcipher.AES256Cipher;
import edu.rit.pj.IntegerForLoop;
import edu.rit.pj.ParallelRegion;
import edu.rit.pj.ParallelTeam;
import edu.rit.util.Hex;

public class FindKeySmp3 {

// Prevent construction.
    private FindKeySmp3() {
    }
// Shared variables.
    // Command line arguments.
    static byte[] plaintext;
    static byte[] ciphertext;
    static byte[] partialkey;
    static int n;
    // The least significant 32 bits of the partial key.
    static int keyLast4Bytes;
    // The maximum value for the missing key bits counter.
    static int maxcounter;
    // The complete key.
    static byte[] foundkey;

    static boolean keyFound = false;

// Main program.
    /**
     * AES partial key search main program.
     */
    public static void main(String[] args)
            throws Exception {
        //Comm.init (args);

        // Start timing.
        long t1 = System.currentTimeMillis();

        // Parse command line arguments.
        // if (args.length != 4) usage();
//      plaintext = Hex.toByteArray(args[0]);
      plaintext = Hex.toByteArray("74657374696e67206d65737361676500");
//    ciphertext = Hex.toByteArray(args[1]);
      ciphertext = Hex.toByteArray("ee0c30ac9b03efc3c516d63a83097a26");
//    partialkey = Hex.toByteArray(args[2]);
      partialkey = Hex.toByteArray("b661ca5d5df7e4e66944751923247a91c1632bf1dc5821a5cd8d83fd4d800000");
//    n = Integer.parseInt(args[3]);
        n = 20;

        // Make sure n is not too small or too large.
        if (n < 0) {
            System.err.println("n = " + n + " is too small");
            System.exit(1);
        }
        if (n > 30) {
            System.err.println("n = " + n + " is too large");
            System.exit(1);
        }

        // Set up program shared variables for doing trial encryptions.
        keyLast4Bytes =
                ((partialkey[28] & 0xFF) << 24)
                | ((partialkey[29] & 0xFF) << 16)
                | ((partialkey[30] & 0xFF) << 8)
                | ((partialkey[31] & 0xFF));
        maxcounter = (1 << n) - 1;

        // Do trial encryptions in parallel.
        new ParallelTeam().execute(new ParallelRegion() {

            public void run() throws Exception {
                int index = getThreadIndex();
                System.out.println("my index: "+index);
                
                execute(0, maxcounter, new IntegerForLoop() {

                	// Thread local variables.
                    byte[] trialkey;
                    byte[] trialciphertext;
                    AES256Cipher cipher;

                    // Set up thread local variables.
                    public void start() {
                        trialkey = new byte[32];
                        System.arraycopy(partialkey, 0, trialkey, 0, 32);
                        trialciphertext = new byte[16];
                        cipher = new AES256Cipher(trialkey);
                    }

                    // Try every possible combination of low-order key bits.
                    public void run(int first, int last) {
                        for (int counter = first; counter <= last && foundkey==null ; ++counter) {
                            // Fill in low-order key bits.
                            int last4Bytes = keyLast4Bytes | counter;
                            trialkey[28] = (byte) (last4Bytes >>> 24);
                            trialkey[29] = (byte) (last4Bytes >>> 16);
                            trialkey[30] = (byte) (last4Bytes >>> 8);
                            trialkey[31] = (byte) (last4Bytes);

                            // Try the key.
                            cipher.setKey(trialkey);
                            cipher.encrypt(plaintext, trialciphertext);

                            // If the result equals the ciphertext, we found the
                            // key.
                            if (match(ciphertext, trialciphertext)) {
                                byte[] key = new byte[32];
                                System.arraycopy(trialkey, 0, key, 0, 32);
                                foundkey = key;
                            }
                        }
                    }
                    public void finish()
                    {
                    // Per-thread post-loop finalization code
                    }
                });
            }
        });

        // Stop timing.
        long t2 = System.currentTimeMillis();

        // Print the key we found.
        System.out.println(Hex.toString(foundkey));
        System.out.println((t2 - t1) + " msec");
    }

// Hidden operations.
    /**
     * Returns true if the two byte arrays match.
     */
    private static boolean match(byte[] a,
            byte[] b) {
        boolean matchsofar = true;
        int n = a.length;
        for (int i = 0; i < n; ++i) {
            matchsofar = matchsofar && a[i] == b[i];
        }
        return matchsofar;
    }

    /**
     * Print a usage message and exit.
     */
    private static void usage() {
        System.err.println("Usage: java [-Dpj.nt=<K>] edu.rit.smp.keysearch.FindKeySmp <plaintext> <ciphertext> <partialkey> <n>");
        System.err.println("<K> = Number of parallel threads");
        System.err.println("<plaintext> = Plaintext (128-bit hexadecimal number)");
        System.err.println("<ciphertext> = Ciphertext (128-bit hexadecimal number)");
        System.err.println("<partialkey> = Partial key (256-bit hexadecimal number)");
        System.err.println("<n> = Number of key bits to search for");
        System.exit(1);
    }
}

