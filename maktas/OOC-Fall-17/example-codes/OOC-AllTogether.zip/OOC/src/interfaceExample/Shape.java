package interfaceExample;

public interface Shape {
   public double area();
   public double volume();
   public String getName();
}
