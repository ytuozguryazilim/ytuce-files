package ooc01c;

public class StringOps {
	
	
	   public static void main( String args[] ) {
			String strA, strB, strC;
			strA = "An apple!";
			strB = "This is another one.";
			strC = "An app";
			
			System.out.println(strA.compareTo(strB));
			
			System.out.println(strA.compareTo(strC));
		   }

}
