package ooc07;

public interface CommercialVehicle {
	public double calculateAmortizedTax( double baseTax, int currentYear );
}
