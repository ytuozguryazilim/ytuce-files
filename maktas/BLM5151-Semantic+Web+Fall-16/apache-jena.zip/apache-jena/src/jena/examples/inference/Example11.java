/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package
///////////////
package jena.examples.inference;


// Imports
///////////////
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Iterator;








import org.apache.jena.riot.tokens.PrintTokenizer;

import jena.examples.ontology.classHierarchy.ClassHierarchy;

import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;
import com.hp.hpl.jena.reasoner.Derivation;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ReasonerRegistry;
import com.hp.hpl.jena.reasoner.ValidityReport;
import com.hp.hpl.jena.reasoner.ValidityReport.Report;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.RDFSRuleReasonerFactory;
import com.hp.hpl.jena.reasoner.rulesys.Rule;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.OWL;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;
import com.hp.hpl.jena.vocabulary.ReasonerVocabulary;


/**
 * <p>
 * Execution wrapper for describe-class example
 * </p>
 */
public class Example11 {
    // Constants
    //////////////////////////////////

    // Static variables
    //////////////////////////////////

    // Instance variables
    //////////////////////////////////

    // Constructors
    //////////////////////////////////

    // External signature methods
    //////////////////////////////////
    public static void printIterator(Iterator<?> i, String header) {
        System.out.println(header);
        for(int c = 0; c < header.length(); c++)
            System.out.print("=");
        System.out.println();
        
        if(i.hasNext()) {
	        while (i.hasNext()) 
	            System.out.println( i.next() );
        }       
        else
            System.out.println("<EMPTY>");
        
        System.out.println();
    }
	
	
    public static void main( String[] args ) {
    	  Example11 ex11 = new Example11();
    	  System.out.println("Results with plain RDF Model");
    	  System.out.println("----------------------------");
    	  System.out.println();
    	  String ont="http://protege.cim3.net/file/pub/ontologies/koala/koala.owl#";
    	  String ns="http://protege.stanford.edu/plugins/owl/owl-library/koala.owl#";
    	  Reasoner reasoner=ReasonerRegistry.getOWLReasoner();
    	  Model emptyModel=ModelFactory.createDefaultModel();
    	  InfModel model=ModelFactory.createInfModel(reasoner,emptyModel);
    	  model.read(ont);
    	  ValidityReport report=model.validate();
    	  ex11.printIterator(report.getReports(),"Validation Results");
    	  Resource c=model.getResource(ns + "MaleStudentWith3Daughters");
    	  ex11.printIterator(model.listObjectsOfProperty(c,RDFS.subClassOf),"All super classes of " + c.getLocalName());
    	  System.out.println();	  
    	  
    	  
    }

}
