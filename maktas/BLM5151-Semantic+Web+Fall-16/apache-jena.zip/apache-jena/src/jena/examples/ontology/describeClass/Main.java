/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// Package
///////////////
package jena.examples.ontology.describeClass;


// Imports
///////////////
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Iterator;








import org.apache.jena.riot.tokens.PrintTokenizer;

import jena.examples.ontology.classHierarchy.ClassHierarchy;

import com.hp.hpl.jena.ontology.*;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.reasoner.Derivation;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ReasonerRegistry;
import com.hp.hpl.jena.reasoner.ValidityReport;
import com.hp.hpl.jena.reasoner.rulesys.GenericRuleReasoner;
import com.hp.hpl.jena.reasoner.rulesys.RDFSRuleReasonerFactory;
import com.hp.hpl.jena.reasoner.rulesys.Rule;
import com.hp.hpl.jena.util.FileManager;
import com.hp.hpl.jena.vocabulary.RDF;
import com.hp.hpl.jena.vocabulary.RDFS;
import com.hp.hpl.jena.vocabulary.ReasonerVocabulary;


/**
 * <p>
 * Execution wrapper for describe-class example
 * </p>
 */
public class Main {
    // Constants
    //////////////////////////////////

    // Static variables
    //////////////////////////////////

    // Instance variables
    //////////////////////////////////

    // Constructors
    //////////////////////////////////

    // External signature methods
    //////////////////////////////////

    public static void main( String[] args ) {
        // read the argument file, or the default
        //String source = (args.length == 0) ? "http://www.w3.org/2001/sw/WebOnt/guide-src/wine" : args[0];
        String source = "http://www.w3.org/2001/sw/WebOnt/guide-src/wine";


        OntModel m = ModelFactory.createOntologyModel(OntModelSpec.OWL_MEM, null);

        // we have a local copy of the wine ontology
        addFoodWineAltPaths( m.getDocumentManager() );

        // read the source document
        m.read( source );

        DescribeClass dc = new DescribeClass();

//        if (args.length >= 2) {
//            // we have a named class to describe
//            OntClass c = m.getOntClass( args[1] );
//            dc.describeClass( System.out, c );
//        }
//        else {
		    PrintStream toFile = null;
			try {
				toFile = new PrintStream(new File ("./data/describe_classes.txt"));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
      
            for (Iterator<OntClass> i = m.listClasses();  i.hasNext(); ) {
                // now list the classes
                //dc.describeClass(System.out, i.next() );
                dc.describeClass(toFile, i.next() );
            }
            toFile.close();
//        }
            
            
            
            ////////////////////////////////////////
         String NS = "urn:x-hp-jena:eg/";

         // Build a trivial example data set
         Model rdfsExample = ModelFactory.createDefaultModel();
         Property p = rdfsExample.createProperty(NS, "p");
         Property q = rdfsExample.createProperty(NS, "q");
         rdfsExample.add(p, RDFS.subPropertyOf, q);
         rdfsExample.createResource(NS+"a").addProperty(p, "foo");
         
         InfModel inf = ModelFactory.createRDFSModel(rdfsExample);  // [1
         
         Resource a = inf.getResource(NS+"a");
         //System.out.println(inf.createList());
         System.out.println("Statement: " + a.getProperty(q));
         
         
         Reasoner reasoner = ReasonerRegistry.getRDFSReasoner();
         InfModel inf_new = ModelFactory.createInfModel(reasoner, rdfsExample);
         
         Reasoner reasoner_new = RDFSRuleReasonerFactory.theInstance().create(null);
         InfModel inf_newer = ModelFactory.createInfModel(reasoner, rdfsExample);
         
         Resource config = ModelFactory.createDefaultModel()
                 .createResource()
                 .addProperty(ReasonerVocabulary.PROPsetRDFSLevel, "simple");
         Reasoner reasoner_newest = RDFSRuleReasonerFactory.theInstance().create(config);
         InfModel inf_newest = ModelFactory.createInfModel(reasoner, rdfsExample);         
         
        // Reasoner boundReasoner = reasoner.bindSchema(schema);
        // InfModel inf = ModelFactory.createInfModel(boundReasoner, data);         
         
         //String fname = "testing/reasoners/rdfs/dttest2.nt";
         String fname = "testing/reasoners/rdfs/dttest3.nt";
         Model data = FileManager.get().loadModel(fname);
         InfModel infmodel = ModelFactory.createRDFSModel(data);
         ValidityReport validity = infmodel.validate();
         if (validity.isValid()) {
             System.out.println("OK");
         } else {
             System.out.println("Conflicts");
             for (Iterator i = validity.getReports(); i.hasNext(); ) {
                 System.out.println(" - " + i.next());
             }
         }  
         
         
//         String rules = "[rule1: (?a eg:p ?b) (?b eg:p ?c) -&gt; (?a eg:p ?c)]";
//         Reasoner reasoner_newer = new GenericRuleReasoner(Rule.parseRules(rules));
//         reasoner.setDerivationLogging(true);
//         InfModel inf_newerrrr = ModelFactory.createInfModel(reasoner, rawData);   
//         
//         PrintWriter out = new PrintTokenizer(System.out);
//         for (StmtIterator i = inf.listStatements(A, p, D); i.hasNext(); ) {
//             Statement s = i.nextStatement();
//             System.out.println("Statement is " + s);
//             for (Iterator id = inf.getDerivation(s); id.hasNext(); ) {
//                 Derivation deriv = (Derivation) id.next();
//                 deriv.printTrace(out, true);
//             }
//         }
//         out.flush();    
         
         
//         Model schema = FileManager.get().loadModel("file:data/rdfsDemoSchema.rdf");
//         Model data_ = FileManager.get().loadModel("file:data/rdfsDemoData.rdf");
//         InfModel infmodel_ = ModelFactory.createRDFSModel(schema, data_);
//
//         Resource colin = infmodel.getResource("urn:x-hp:eg/colin");
//         System.out.println("colin has types:");
//         //printStatements(infmodel, colin, RDF.type, null);
//
//         Resource Person = infmodel.getResource("urn:x-hp:eg/Person");
//         System.out.println("\nPerson has types:");
//         //printStatements(infmodel, Person, RDF.type, null);         
         
         
    }


    // Internal implementation methods
    //////////////////////////////////

    /**
     * Add alternate paths to save downloading the default ontologies from the Web
     */
    protected static void addFoodWineAltPaths( OntDocumentManager odm ) {
        odm.addAltEntry( "http://www.w3.org/2001/sw/WebOnt/guide-src/wine",
                         "file:MyDatabases/wine.owl" );
        odm.addAltEntry( "http://www.w3.org/2001/sw/WebOnt/guide-src/wine.owl",
                         "file:MyDatabases/wine.owl" );
        odm.addAltEntry( "http://www.w3.org/2001/sw/WebOnt/guide-src/food",
                         "file:MyDatabases/food.owl" );
        odm.addAltEntry( "http://www.w3.org/2001/sw/WebOnt/guide-src/food.owl",
                         "file:MyDatabases/food.owl" );
    }

    //==============================================================================
    // Inner class definitions
    //==============================================================================

}
