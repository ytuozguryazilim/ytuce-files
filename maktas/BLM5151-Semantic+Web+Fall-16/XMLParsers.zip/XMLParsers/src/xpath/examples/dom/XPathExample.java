package xpath.examples.dom;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

public class XPathExample {

	public static void main(String[] args) {
		try {
			DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
			domFactory.setNamespaceAware(true);
			
			DocumentBuilder builder = domFactory.newDocumentBuilder();
			  
			Document document = builder.parse(new InputSource("file:.\\xmldata\\catalog.xml"));
			
			XPathFactory factory = XPathFactory.newInstance();
			XPath xpath = factory.newXPath();
			xpath.setNamespaceContext(new NamespaceContext() {
				public String getNamespaceURI(String prefix) {
					if (prefix.equals("edx")) {
						return "http://examples/";
					}
					
					return "";
				}

				public String getPrefix(String namespaceURI) {
					if (namespaceURI.equals("http://examples/")) {
						return "edx";
					}
					
					return "";
				}

				public Iterator getPrefixes(String namespaceURI) {
					List<String> list = new ArrayList<String>();

					if (namespaceURI.equals("http://examples/")) {
						list.add("edx");
					}
					
					return list.iterator();
				}
			});
			  
			Object nodes = xpath.evaluate("//edx:cd", document.getDocumentElement(), XPathConstants.NODESET);
						
			if (nodes instanceof NodeList) {
				for (int i = 0; i < ((NodeList)nodes).getLength(); i++) {
					System.out.println(((NodeList)nodes).item( i).getTextContent());
				}
			}

		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (XPathExpressionException e) {
			e.printStackTrace();
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}