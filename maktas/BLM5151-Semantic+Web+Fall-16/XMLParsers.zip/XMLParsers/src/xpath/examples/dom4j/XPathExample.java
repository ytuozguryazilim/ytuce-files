package xpath.examples.dom4j;

import java.util.HashMap;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Node;
import org.dom4j.XPath;
import org.dom4j.io.SAXReader;
import org.jaxen.SimpleNamespaceContext;

public class XPathExample {

	public static void main( String[] args) {
		try {
            SAXReader reader = new SAXReader();
            Document document = reader.read("file:.\\xmldata\\catalog.xml");
            
            HashMap<String, String> map = new HashMap<String, String>();
            map.put("edx", "http://examples/");
            
            XPath xpath = DocumentHelper.createXPath("//edx:cd/edx:artist");
            xpath.setNamespaceContext(new SimpleNamespaceContext(map));
            
            List nodes = xpath.selectNodes(document);

			for (int i = 0; i < nodes.size(); i++) {
				System.out.println(((Node)nodes.get(i)).getStringValue());
			}
  
		} catch (DocumentException e) {
			// the document is not well-formed.
			e.printStackTrace();
		}	
	}
}
