package oop03b;

public class Electronics implements Item {
	public String toString( ) {
		return "An electronic item";
	}

}
