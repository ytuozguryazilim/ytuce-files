package oop03b;

public interface Item {
	/* Some methods excluding expiration*/
}
