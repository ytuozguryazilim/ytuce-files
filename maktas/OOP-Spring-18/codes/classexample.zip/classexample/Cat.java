package oop04a.classexample;

@SuppressWarnings("serial") 
public class Cat extends Pet {
	
	public Cat(String name) {	super(name);	}
	
	public void run() {
		System.out.println("(" + getName() + "): Meaow!");
	}
}

