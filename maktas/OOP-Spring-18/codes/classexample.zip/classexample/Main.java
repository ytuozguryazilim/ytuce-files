package oop04a.classexample;

import java.io.File;
import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		
		String name = "Bob";
		
		Person jon = new Person(name);
		
		Cat garfield = new Cat("Garfield");
		Dog lessie = new Dog("Lessie");
		
		try {
			jon.addPet(garfield);
			jon.addPet(garfield);
		} 
		catch (DuplicateInformation e) {
			e.printStackTrace();
		}

		try {
			jon.addPet(lessie);
		} 
		catch (DuplicateInformation e) {
			e.printStackTrace();
		}		
		
		jon.savePets();
		

		
		LinkedList<Pet> pets = jon.loadPets();
		
		for( Pet pet : pets ){
			Pet aPet = pet;
			System.out.println("pet name = " + aPet.getName());
		}
		
		Pet p = jon.searchPet("Garfield");
		System.out.println("search result: pet name = " + p.getName());
		
		//analyzePath(name+"sPets.dat");
		
	}

	   // display information about file user specifies
	   public static void analyzePath( String path )
	   {
	      // create File object based on user input
	      File name = new File( path );

	      if ( name.exists() ) // if name exists, output information about it
	      {
	          // display file (or directory) information
	          System.out.println(
	                  "name : " + name.getName() + "\n" +
	                  "isFile() : " + name.isFile() + "\n" +
	                  "isDirectory() : " + name.isDirectory() + "\n" +
	                  "isAbsolute() : " + name.isAbsolute() + "\n" +
	                  "lastModified() : " + name.lastModified() + "\n" +
	                  "length() : " + name.length() + "\n" +
	                  "getPath() : " + name.getPath() + "\n" +
	                  "getAbsolutePath() : " + name.getAbsolutePath());  


	      } // end outer if
	      else // not file or directory, output error message
	      {
	         System.out.printf( "%s %s", path, "does not exist." );
	      } // end else  
	   } // end method analyzePath
	
	
}

