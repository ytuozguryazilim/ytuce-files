package oop04a.classexample;

@SuppressWarnings("serial") 
public abstract class Pet implements java.io.Serializable {

	private String name;

	public Pet(String name) { this.name = name;	}
	
	public String getName() { return name;	}
}

