package oop04a.classexample;

import java.io.*;

@SuppressWarnings("serial") 
public class DuplicateInformation extends IOException {
	
	public DuplicateInformation( String msg ) {
		super(msg);
	}
}
