package oop04a2;

import java.io.*;
import java.util.*;

public class ArkadasGoster {
	
  public static void main( String[] args ) {
	  
	String dosyaAdi = "arkadaslarAlt.dat";
	try {
		ObjectInputStream okuyucu = new ObjectInputStream( 
				new FileInputStream( dosyaAdi ) );
		@SuppressWarnings("unchecked")
		
		LinkedList<Arkadas> arkadaslar = (LinkedList<Arkadas>)okuyucu.readObject();
		for( Arkadas arkadas : arkadaslar ) {
				System.out.println(arkadas);
		}
		okuyucu.close();
	} 
	catch( IOException e ) {
		System.out.println("Dosya okuma islemleri sirasinda" +
					" bir hata olustu.");
		e.printStackTrace();
	} 
	catch( ClassNotFoundException e ) {
		System.out.println("Okunan kayitlari islerken " +
				"bir hata olustu.");
		e.printStackTrace();
	}
  }

}
