package oop04a2;

import java.util.*;
import java.io.*;

public class ArkadasOlustur {
	public static void main(String[] args) {
		LinkedList<Arkadas> arkadaslar = new LinkedList<Arkadas>();
		Scanner giris = new Scanner( System.in );
		System.out.println("Bu program arkadaslarinizin iletisim " +
				" bilgilerini diskteki bir dosyaya kaydeder.");
		System.out.print("Ka� arkadasinizin bilgisini gireceksiniz? ");
		int arkadasSayisi = giris.nextInt( );
		giris.nextLine( );
		for( int i = 0; i < arkadasSayisi; i++ ) {
			System.out.print((i+1)+". arkadasinizin ismi nedir? ");
			Arkadas arkadas = new Arkadas( giris.nextLine() );
			System.out.print("Bu arkadasinizin telefonu nedir? ");
			arkadas.setTelefon( giris.nextLine() );
			System.out.print("Bu arkadasinizin e-posta adresi nedir? ");
			arkadas.setEPosta( giris.nextLine() );
			arkadaslar.add(arkadas);
		}
		giris.close();		
		try {
			String dosyaAdi = "arkadaslarAlt.dat";
			ObjectOutputStream yazici = new ObjectOutputStream( 
					new FileOutputStream( dosyaAdi )  );
			yazici.writeObject( arkadaslar );
			yazici.close();
			System.out.println("Girilen bilgiler " + dosyaAdi + 
				" adli dosyaya basariyla kaydedildi.");
			
		} 
		catch( IOException e ) {
			System.out.println("Dosyaya kayit islemi sirasinda"+ 
				" bir hata olustu.");
			e.printStackTrace();
		}
	}
}
