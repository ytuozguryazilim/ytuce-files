package oop04a2;

public class Arkadas implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	private String isim, telefon, ePosta;

	public Arkadas( String name ) { this.isim = name; }
	public String getIsim( ) { return isim; }
	public String getTelefon( ) { return telefon; }
	public void setTelefon( String telefon ) {
		this.telefon = telefon;	}
	public String getEPosta( ) { return ePosta; }
	public void setEPosta( String posta ) { ePosta = posta; }
	public String toString( ) {
		return isim + " - " + telefon + " - " + ePosta;
	}
}
