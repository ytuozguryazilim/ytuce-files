package oop04a.classexample;

import java.io.*;

public class DuplicateInformation extends IOException {
	
	public DuplicateInformation( String msg ) {
		super(msg);
	}
}
