package oop00;

public class Dog {


	public String name;
	
	Dog(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String n){
		name = n;
	}


}
