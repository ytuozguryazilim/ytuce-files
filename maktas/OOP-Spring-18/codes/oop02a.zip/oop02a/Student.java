package oop02a;

public class Student {
	private String number;
	private String name;

	public Student(String no, String name) {
		this.number = no;
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public String getName() {
		return name;
	}
	
}
