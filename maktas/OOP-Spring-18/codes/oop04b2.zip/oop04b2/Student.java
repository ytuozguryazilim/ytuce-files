package oop04b2;

public class Student extends Person  {
	private String number;
	private String name;

	public Student(String no, Integer ID) {
		super(no);
		this.number = no;
		this.name = (new Integer(ID)).toString();
	}	
	
	public Student(String no, String name) {
		super(no);
		this.number = no;
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public String getName() {
		return name;
	}
	
}

