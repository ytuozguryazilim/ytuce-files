package oop04b2;

import java.io.Serializable;
import java.util.*;

public class Course implements Serializable {
	
	private String code; private String name; private int capacity;
	private HashMap<String,Student> students;
	private Lecturer lecturer;

	public Course(String code, String name) {
		this.code = code; this.name = name; 
		students = new HashMap<String,Student>();
	}	
	
	public Course(String code, String name, int capacity) {
		this.code = code; this.name = name; this.capacity = capacity;
		students = new HashMap<String,Student>();
	}
	public String getCode() { return code; }
	public String getName() { return name; }
	public int getCapacity() { return capacity; }
	public int getStudentCount() { 
		return students.size(); 
	}
	
	public void setTeacher(Lecturer lecturer) {
		this.lecturer = lecturer;
	}
	
	public Student findStudent( String number ) {
		return students.get(number);
	}
	
	public void increaseCapacity( int newCapacity ) {
		if( newCapacity <= capacity )
			return;
		capacity = newCapacity;
	}
	
	public void showClassList( ) {
		System.out.println("Class List of "+code+" "+name);
		System.out.println("Student#  Name, Surname");
		System.out.println("--------  -----------------------------");
		for( Student aStudent : students.values() )
			System.out.println(aStudent.getNumber()+
			" " + aStudent.getName());
	}
	
	public void setCapacity( int capacity ) throws InvalidCapacityException {
		if( capacity >= students.size() )
			this.capacity = capacity;
		else
			throw new InvalidCapacityException("Students already enrolled: "
					+ students.size() + ", desired capacity: " + capacity);
	}
	
	public void addStudent( Student std ) throws StudentAlreadyExistsException {
		if( findStudent(std.getNumber()) != null && capacity > students.size() )
			students.put(std.getNumber(), std);
		else
			throw new StudentAlreadyExistsException("A student with number " 
					+ std.getNumber() + " already exits.");
	}
	
	
	
	
}