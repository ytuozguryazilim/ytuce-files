package oop04b2;

import java.io.IOException;

public class InvalidCapacityException extends IOException {

	private static final long serialVersionUID = 1L;
	
	public InvalidCapacityException(String arg0) {
		super(arg0);
	}
}

