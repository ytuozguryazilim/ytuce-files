package oop04b2;

import java.io.IOException;

public class StudentAlreadyExistsException extends IOException {

	private static final long serialVersionUID = 1L;

	public StudentAlreadyExistsException(String arg0) {
		super(arg0);
	}
}

