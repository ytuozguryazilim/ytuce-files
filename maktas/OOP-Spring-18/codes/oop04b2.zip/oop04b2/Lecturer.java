package oop04b2;

public class Lecturer extends Person  {

	private Integer ID;

	public Lecturer(String name, Integer ID) {
		super(name);
		this.ID = ID;
	}
	public Integer getID() { return ID; }
}
