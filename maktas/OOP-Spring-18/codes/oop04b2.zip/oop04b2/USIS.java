package oop04b2;

import java.io.*;
import java.util.*;
public class USIS{
	private HashMap<String,Course> courses;
	private HashMap<Integer,Person> people;

	public USIS() {
		courses = new HashMap<String,Course>() ;
		people = new HashMap<Integer,Person>();
	}
	public void createStudent( String name, Integer ID ) {
		people.put( ID, new Student(name,ID) );
	}
	public void createLecturer( String name, Integer ID ) {
		people.put( ID, new Lecturer(name,ID) );
	}
	public void createCourse(String code, String name, int capacity, Integer lecturerID){
		try {
			Course course = new Course(code, name);
			course.setCapacity(capacity);
			Lecturer teacher = (Lecturer) people.get(lecturerID);
			course.setTeacher(teacher);
			courses.put(code, course);
		} 
		catch (InvalidCapacityException e) {
			e.printStackTrace();
		}
	}
	public void setCapacity( String code, int capacity ) {
		try {
			courses.get(code).setCapacity(capacity);
		} 
		catch (InvalidCapacityException e) {
			e.printStackTrace();
		}
		catch (NullPointerException e) {
			e.printStackTrace();
		}
	}
	public void addStudentToCourse( String courseCode, Integer studentNr ) {
		try {
			Person p = people.get(studentNr);
			Course c = courses.get(courseCode);
			if( p != null && c != null && p instanceof Student ) {
				Student std = (Student) p;
				c.addStudent(std);
			}
		} 
		catch (StudentAlreadyExistsException e) {
			e.printStackTrace();
		}
	}
	public void saveAllObjectsToFile( String path ) {
		try {
			ObjectOutputStream stream = new ObjectOutputStream( 
					new FileOutputStream(path) );
			stream.writeObject(courses);
			stream.writeObject(people);
			stream.close();
		} 
		catch ( IOException e ) {
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void loadAllObjectsFromFile( String path ) {
		try {
			ObjectInputStream stream = new ObjectInputStream( 
					new FileInputStream(path) );
			courses = (HashMap<String, Course>) stream.readObject();
			people = (HashMap<Integer, Person>) stream.readObject();
			stream.close();
		} 
		catch ( IOException e ) {
			e.printStackTrace();
		} 
		catch ( ClassNotFoundException e ) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
		USIS usis = new USIS();
	
		usis.createCourse("BLM2581", "00P", 45, 100);
		usis.createLecturer("ali hoca", 100);

		usis.createStudent("veli", 001);
		usis.createStudent("ahmet", 002);

		usis.saveAllObjectsToFile("sinif.dat");
		usis.loadAllObjectsFromFile("sinif.dat");
		
		System.out.println(usis.courses);
		System.out.println(usis.people);
		
	}

}

