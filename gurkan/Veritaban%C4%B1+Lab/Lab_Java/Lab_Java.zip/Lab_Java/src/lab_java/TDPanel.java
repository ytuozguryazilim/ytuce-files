/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_java;

import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.Date;
import javax.swing.table.DefaultTableModel;

class TDPanel extends JPanel{

    private final JLabel inputLbl = new JLabel("Bir departman numarası giriniz: ");
    private final JTextField txt = new JTextField(2);
    private final JButton btn1 = new JButton("Dept. Bilgisi Göster");
    private final JButton btn2 = new JButton("Çalışan Ekle");
    private final JButton btn3 = new JButton("Kapat");
    private final JLabel outputLbl = new JLabel(" ");
    private final DefaultTableModel calisanlar;
    private Connection conne;
    final JPanel uayripanel = new JPanel();
        
    public TDPanel (Connection conn)  {
		
        //TDPanel'in parametre olarak aldığı conn nesnesini yerel Connection sınıfından conne nesnesine atayalım.
        conne = conn;
        
        //Panel üzerindeki kolonların sırasıyla isimlerini belirleyelim.
	Object[] columnNames = {"Ad", "Soyad", "SSN", "D-Tarihi", "Adres", "Cinsiyet", "Maaş"};
        
        //calisanlar tablosunu verilen kolon isimleriyle oluşturalım.
	calisanlar = new DefaultTableModel(columnNames, 0);
	JTable tbl = new JTable(calisanlar);
        
        //Oluşturulan tablonun üzerine butonların ve bilgi yazılarının yer aldığı paneli ekleyelim.
	JScrollPane sp = new JScrollPane(tbl);
	add(inputLbl);	//"Bir departman numarası giriniz: " yazısı panele eklenir.
        add(txt); //departman numarasını bekleyen metin girdi alanı panele eklenir.	
        add(btn1); //"Dept. Bilgisi Göster" butonu panele eklenir.
        add(btn2); //"Çalışan Ekle" butonu panele eklenir.	
        add(btn3); //"Kapat" butonu panele eklenir.
	add(outputLbl); // Uyarı ve çıktı mesajlarını verecek alan panele eklenir.
        add(sp);
		
	btn1.addActionListener(new ActionListener() {//btn1'e tıklandığında ne olacağını kodluyoruz.			
            public void actionPerformed(ActionEvent arg0) {
		goster(); //btn1'e yani "Dept. Bilgisi Göster" butonuna tıklanınca "goster()" metodu çalışsın.
            }			 
	});			
		
	btn2.addActionListener(new ActionListener() {			
            public void actionPerformed(ActionEvent arg0) {
		ekle(); //btn2'e yani "Çalışan Ekle" butonuna tıklanınca "ekle()" metodu çalışsın.
            }			 
	});	
		
	btn3.addActionListener(new ActionListener() { //btn3'e yani "Kapat" butonuna tıklanınca			
            public void actionPerformed(ActionEvent arg0) {
		try {
                    conne.close(); //önce VTYS ile bağlantıyı kopar.
		} catch (SQLException e) {
                    System.err.println("VTYS ile bağlantı koparılamadı !\n" + e);
		}
		setVisible(false);
		System.exit(0); //sonra da paneli kapat.
            }			 
	});	
    }
		
    private void goster()  {
		
        //Panelde departman numarası girilecek alandan okunan veriyi integer tipine pars et ve dnum değişkenine yaz.
        int dnum = Integer.parseInt(txt.getText()); 
        
        //Öncelikle ilgili departmanın yöneticinin ismini bulacak sorguyu girilen parametre ile hazırlayalım.
	String query ="SELECT dname, fname, lname FROM employee, department WHERE ssn = mgrssn AND dnumber = " + dnum;
	PreparedStatement p;
	try {
            p = conne.prepareStatement(query);
            ResultSet r = p.executeQuery();
            calisanlar.setRowCount(0);
	        
	    //Sonuçları inceleyelim
            if (!r.next()){ //Eğer hiç sonuç dönmemişse böyle bir departman olmadığı uyarısını verelim.
		outputLbl.setText("Böyle bir departman bulunmamaktadır! ");
            }else{ //Eğer en az 1 sonuç dönmüşse;
                //Öncelikle departmanın ismini ve yöneticisinin ismini poanele yazalım.
		String dname    = r.getString(1);
		String y_fname  = r.getString(2);
		String y_lname  = r.getString(3);
                
		outputLbl.setText("Departman ismi: " + dname + ", Yöneticisinin ismi: " + y_fname + " " + y_lname);
		p.close(); //Oluşturduğumuz sorgudan tüm bilgileri aldığımıza göre sorguyu silelim.
		
                //Şimdi de o departmanda çalışanları bulacak sorguyu hazırlayıp çağıralım.
		String query2 = "SELECT * FROM employee WHERE dno = ?";
		PreparedStatement p2 = conne.prepareStatement(query2);
                p2.setInt(1, dnum);
		ResultSet r2 = p2.executeQuery();
		
                //Sırasıyla tüm çalışanların bilgilerini ekrana yazdıralım.
		while (r2.next ()) {
		    String fname    = r2.getString("fname"); // veya String fname = r2.getString(1); yazılabilir.
                    String lname    = r2.getString("lname");    	
		    String ssn      = r2.getString("ssn");
		    Date bdate      = r2.getDate("bdate"); 
		    String address  = r2.getString("address");
		    String sex      = r2.getString("sex"); 
		    double salary   = r2.getDouble("salary");
		      
                    //İlgili çalışanın bilgilerinden bir satır oluşturulup, paneldeki tabloya ekleniyor.
		    Object[] satir = {fname, lname, ssn, bdate, address, sex, salary};
		    calisanlar.addRow(satir);
		}
                //Sorgumuz siliniyor.
		p2.close();
            }
	} catch (SQLException e) {
            System.err.println("VTYS bağlantısında sorun çıktı !\n" + e);
	}				
    }
	
    private void ekle()  {
        //Eklenecek çalışanın bilgilerini sırasıyla kullanıcıya soralım.
	String ad       = JOptionPane.showInputDialog("Çalışan adını giriniz");
	String soyad    = JOptionPane.showInputDialog("Çalışan soyadını giriniz");
	String ssn      = JOptionPane.showInputDialog("Çalışan SSN'ini giriniz");
	String dtarih   = JOptionPane.showInputDialog("Çalışan doğum tarihini DD/MM/YYYY formatında giriniz");
	String address  = JOptionPane.showInputDialog("Çalışan adresini giriniz");
	String sex      = JOptionPane.showInputDialog("Çalışan cinsiyetini giriniz");
	String maas     = JOptionPane.showInputDialog("Çalışan maaşını giriniz");
	String dno      = JOptionPane.showInputDialog("Çalışanın departman numarasını giriniz");
		
        String query = 
                    "INSERT INTO employee(fname, lname, ssn, bdate, address, sex, salary, dno) " +
                    "VALUES('" + ad + "', '" + soyad + "', '" + ssn + "', '" + dtarih + "', '" + 
                    address + "', '" + sex + "', " + maas + ", " + dno + ");";

	Statement s = null;
	try {
            s = conne.createStatement();
            s.executeUpdate(query);
            conne.setAutoCommit(false);
            conne.commit();
            s.close();
            JOptionPane.showMessageDialog(uayripanel, "Çalışan başarıyla eklendi.", "Information", JOptionPane.INFORMATION_MESSAGE);
	}catch (SQLException e) {
            JOptionPane.showMessageDialog(uayripanel, "Çalışan eklenirken sorunla karşılaşıldı !", "Error", JOptionPane.WARNING_MESSAGE);
            System.err.println("Bilgileri girilen çalışan sisteme eklenemedi ! \n" + e);
        }		
    }
}