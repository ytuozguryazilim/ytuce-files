/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_java;

import java.sql.*;
import javax.swing.*;

/**
 *
 * @author GÜRKAN
 */
public class Lab_Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
       
        Class.forName("org.postgresql.Driver");
	//Bağlantı için parametreler ayarlanıyor.
        String user, pass, db_name;
        user    = "postgres";
        pass    = "1234";
        db_name = "company";
        
        //Bağlantı (connection) nesnesi oluşturuluyor.
        Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/"+db_name, user,pass);
        
	JFrame frame = new TDFrame(conn);
	frame.setVisible(true);
       
    }
    
}
