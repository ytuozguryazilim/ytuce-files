/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab_java;


import java.sql.*;
import javax.swing.*;

public class TDFrame extends JFrame {
	
    public TDFrame (Connection conn) {

	setTitle("Department Information");
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setSize(750, 500);
	setLocation(200, 200);
	getContentPane().add(new TDPanel(conn));		
    }
}
