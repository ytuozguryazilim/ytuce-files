/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
/**
 *
 * @author TCYCEKNAZ
 */
public class WritingProcess {
   public void write(String text){
       try {

			

			File file = new File("Logs.txt");

			// if file doesnt exists, then create it
			if (!file.exists()) {
				file.createNewFile();
			}

                       text = text.concat(System.getProperty("line.separator"));

                       Files.write(Paths.get("Logs.txt"), text.getBytes(), StandardOpenOption.APPEND);
                       
                       
			

		} catch (IOException e) {
			e.printStackTrace();
		}
   } 
}
