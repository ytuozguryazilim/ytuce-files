#include <stdio.h>

int main(){
	
	printf("Boyut: %d\n", sizeof(float));

	return 0;
}	
