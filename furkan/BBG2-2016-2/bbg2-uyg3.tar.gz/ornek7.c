#include <stdio.h>
#include <math.h>
int main(){

	//char a = 85;
	//printf("%c -> %d\n", a, a);
	float akok;
	/*akok = sqrt(a);
	printf("%d nin karakoku %.2f tir\n", a, akok);
	char a = 85;
	akok = log(a);
	printf("%d nin logu %.2f tir\n", a, akok);
	char a = 85;
	akok = log10(a);
	printf("%d nin logu %.2f tir\n", a, akok);
	char a = -85;
	akok = fabs(a);
	printf("%d nin mutlak degeri %.2f tir\n", a, akok);
	float a = -85.2;
	akok = floor(a); //ceil
	printf("%.2f nin mutlak degeri %.2f tir\n", a, akok);*/
	int a = 3, b = 4;
	akok = pow(a, b); 
	printf("%.2f tir\n", akok);
	//sin, cos, tan
	return 0;
}
