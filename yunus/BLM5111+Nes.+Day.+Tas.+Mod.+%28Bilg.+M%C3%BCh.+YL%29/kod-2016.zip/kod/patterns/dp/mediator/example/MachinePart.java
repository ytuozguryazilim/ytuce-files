package dp.mediator.example;

public class MachinePart implements ManufacturingItem {
	private int partID, parentID;
	private String name, factory;
	
	public MachinePart(int partID, int parentID, String name, String factory) {
		this.partID = partID;
		this.parentID = parentID;
		this.name = name;
		this.factory = factory;
	}
	
	public int getPartID() { return partID; }
	public int getParentID() { return parentID; }
	public String getName( ) { return name; }
	public String getFactory() { return factory; }
	public void setFactory(String factory) { this.factory = factory; }
	public MachinePart clone( int newParentID ) {
		MachinePart newPart = new MachinePart(partID, newParentID, name, factory);
		return newPart;
	}

	public void accept(ManufacturingItemVisitor visitor) {
		visitor.visit(this);
	}

	
}
