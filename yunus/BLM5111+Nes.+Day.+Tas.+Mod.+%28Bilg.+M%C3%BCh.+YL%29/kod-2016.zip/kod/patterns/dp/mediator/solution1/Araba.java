package dp.mediator.solution1;

public class Araba {
	private String plaka;
	private Insan sahip;
	public Araba( String plaka ) { this.plaka = plaka; }
	void setSahip(Insan sahip) { this.sahip = sahip; }
	public String toString( ) {
		String mesaj = "Plakam: " + plaka;
		mesaj += ", Sahibim: " + sahip.getAdSoyad();
		return mesaj;
	}
	public String getPlaka() { return plaka; }
}
