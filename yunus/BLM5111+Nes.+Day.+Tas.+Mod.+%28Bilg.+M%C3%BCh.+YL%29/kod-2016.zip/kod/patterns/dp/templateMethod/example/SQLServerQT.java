package dp.templateMethod.example;

public class SQLServerQT extends QueryTemplate {
	String formatConnect(String DBname) {
		//SQL Server'a g�re �zel bi�imlendirme komutlar�n� ver.
		return DBname;
	}
	String formatSelect(String querySpec) {
		//SQL Server'a g�re �zel bi�imlendirme komutlar�n� ver.
		return querySpec;
	}
}
