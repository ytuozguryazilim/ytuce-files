package dp.templateMethod.example;

public class QueryControl {
	private QueryTemplate qt;
	public QueryControl(QueryTemplate qt) {
		this.qt = qt;
	}
	public void aMethodThatNeedsSelect( ) {
		qt.doQuery("myDB", "*");
	}
}
