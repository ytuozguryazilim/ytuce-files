package dp.strategy.solution1;

public enum Country { TR, US, EU }
