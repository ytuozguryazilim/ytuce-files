package dp.strategy.solution1;

public class TaskController {
	private Country code;

	public void setCountry(Country code) {
		this.code = code;
	}
	
	public double taxAmount( double income ) {
		switch (code) {
		case TR:
			return income * 0.18;
		case EU:
			return income * 0.15;
		case US:
			return income * 0.12;
		default:
			return income * 0.10;
		} 
	}

}
