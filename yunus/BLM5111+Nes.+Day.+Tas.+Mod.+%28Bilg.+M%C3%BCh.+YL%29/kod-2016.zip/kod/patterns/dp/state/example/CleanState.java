package dp.state.example;
import java.io.*;
public class CleanState extends State {
	public void edit( ){
		PIMApplication.setCurrentState(PIMApplication.DIRTY);
	}
	public void save(File f, Serializable s) throws IOException {
		PIMApplication.setCurrentState(PIMApplication.CLEAN);
		super.save(f, s);
	}
}
