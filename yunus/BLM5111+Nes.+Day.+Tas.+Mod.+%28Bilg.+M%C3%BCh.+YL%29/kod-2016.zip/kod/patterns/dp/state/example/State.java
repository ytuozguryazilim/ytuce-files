package dp.state.example;
import java.io.*;
public abstract class State {
	public void save(File f, Serializable s) throws IOException {
		FileOutputStream fos = new FileOutputStream(f);
		ObjectOutputStream out = new ObjectOutputStream(fos);
		out.writeObject(s);
		out.close();
	}
	public void edit( ) { /*Gerekli i�ler*/ }
}
