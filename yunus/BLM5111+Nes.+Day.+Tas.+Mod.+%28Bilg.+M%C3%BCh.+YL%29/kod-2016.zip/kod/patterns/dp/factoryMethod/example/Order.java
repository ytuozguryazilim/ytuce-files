package dp.factoryMethod.example;

public abstract class Order {
	public abstract void prepare( );
	public abstract void orderFromSupplier( );
	public abstract void pack( );
	public abstract void sendToCustomer( );

}
