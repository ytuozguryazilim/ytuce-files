package dp.factoryMethod.example;

/**
 * @uml.dependency   supplier="factoryMethod.example.Books"
 */
public class BookStore extends Store {

	@Override
	protected Order createOrder(String type) {
		Books newBookOrder = new Books(type);
		//Kitap sipari�i i�in yap�lacak i�lemlerin tan�mlanmas�
		return newBookOrder;
	}

}
