package dp.composite.solution1;

import java.util.Iterator;

public class MachinePart extends ManufacturingItem {
	private int parentID;

	public MachinePart( int machineID, int parentID, String name, String factory) {
		super(machineID, name, factory);
		this.parentID = parentID;
	}
	public int getParentID() {
		return parentID;
	}
	public void setParentID(int parentID) {
		this.parentID = parentID;
	}

	public Iterator<ManufacturingItem> getParts() {
		return null;
	}
	public boolean addPart(ManufacturingItem part) {
		return false;
	}
	public boolean removePart(ManufacturingItem part) {
		return false;
	}

}
