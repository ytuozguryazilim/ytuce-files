package dp.decorator.example;

public class Factory {
    public Component getComponent () {
    	/*Component myComponent;
    	myComponent = new SalesTicket();
    	myComponent = new Header2(myComponent);
    	myComponent = new Header1(myComponent);
    	myComponent = new Footer1(myComponent);
    	return myComponent;*/
    	return new Header1( new Footer2( new Footer1( new SalesTicket() ) ) );
        /*
        Component myComponent;
        myComponent= new SalesTicket();
        myComponent= new Header1(myComponent);
        myComponent= new Footer1(myComponent);
        return myComponent;
        */
        //VEYA: A�a��daki kod ayn� etkiyi yapar 
        //return(  new Header2( new Footer2 (new Footer1 ( new SalesTicket()))));
    	//return(new Footer1(new Header1(new SalesTicket())));
    	/*Component myComponent;
        myComponent= new SalesTicket();
        Footer1 f1 = new Footer1(myComponent);
        return f1;*/
    	
    }
}
