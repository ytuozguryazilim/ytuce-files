package dp.decorator.example;

public class Header2 extends TicketDecorator {
    public Header2 (Component myComponent) {
        super(myComponent);
    }
    public void prtTicket () {
        // place printing header 2 code here
       System.out.println(getClass().getName());
       super.callTrailer();
    }
}
