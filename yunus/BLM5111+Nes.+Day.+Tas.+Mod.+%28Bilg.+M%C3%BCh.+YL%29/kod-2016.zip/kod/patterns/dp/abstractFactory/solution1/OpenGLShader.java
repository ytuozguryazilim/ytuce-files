package dp.abstractFactory.solution1;

public class OpenGLShader {
	//do shading in OpenGL
	public void shadeOpA() { }
	public void shadeOpB() { }
	public void shadeOpC() { }
}
