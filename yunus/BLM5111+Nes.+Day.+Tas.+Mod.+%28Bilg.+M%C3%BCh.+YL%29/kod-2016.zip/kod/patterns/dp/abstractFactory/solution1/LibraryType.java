package dp.abstractFactory.solution1;

public enum LibraryType {
	OpenGL, DirectX; 
}
