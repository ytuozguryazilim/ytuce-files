package dp.abstractFactory.solution3;

public class DirectXFactory extends ComponentFactory {
	public Renderer createRenderer() {
		return new DirectXRenderer();
	}
	public Shader createShader() {
		return new DirectXShader();
	}
}
