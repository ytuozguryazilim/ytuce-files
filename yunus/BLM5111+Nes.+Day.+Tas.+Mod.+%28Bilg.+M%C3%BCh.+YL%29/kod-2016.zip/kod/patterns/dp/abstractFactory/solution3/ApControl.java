package dp.abstractFactory.solution3;

public class ApControl {
	private ComponentFactory library;
	private Renderer r; 
	private Shader s;
	public ApControl( ) {
		/*library nesnesini ilklendirerek k�t�phane t�r�n� belirle
		library = new OpenGLFactory();
		library = new DirectXFactory();
		*/
		r = library.createRenderer();
		s = library.createShader();
	}
	void doRendering ( ) {
		r.renderOpA();
		r.renderOpB();
		r.renderOpC();
	}
	void doShading ( ) { 
		s.shadeOpA();
		s.shadeOpB();
		s.shadeOpC();
	}
}
