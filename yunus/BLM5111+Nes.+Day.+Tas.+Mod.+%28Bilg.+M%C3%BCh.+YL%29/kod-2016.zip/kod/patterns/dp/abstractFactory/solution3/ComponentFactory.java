package dp.abstractFactory.solution3;

public abstract class ComponentFactory {
	public abstract Renderer createRenderer();
	public abstract Shader createShader();
}
