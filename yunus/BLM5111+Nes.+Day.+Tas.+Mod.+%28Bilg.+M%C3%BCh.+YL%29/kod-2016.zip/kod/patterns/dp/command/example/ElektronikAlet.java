package dp.command.example;
public class ElektronikAlet implements AcKapa {
	private String isim;
	public ElektronikAlet(String isim) { this.isim = isim; }
	public String toString( ) { return "AcKapa:" + isim; }
	public boolean ac() {
		System.out.println("ACIK: " + this);
		return true; }
	public boolean kapa() { 
		System.out.println("KAPALI: " + this);
		return true; }
}
