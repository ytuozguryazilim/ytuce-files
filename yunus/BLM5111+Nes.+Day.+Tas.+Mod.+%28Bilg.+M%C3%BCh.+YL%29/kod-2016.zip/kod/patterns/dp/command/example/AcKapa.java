package dp.command.example;

public interface AcKapa {
	public boolean ac( );
	public boolean kapa( );
}
