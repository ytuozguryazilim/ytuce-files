package dp.mementoV2.innerClass;

public class Caretaker {
	public void test( ) {
		Originator subject = new Originator( );
		subject.modify("ilk durum");
		Originator.Memento mem = subject.createMemento( );
		subject.modify("yeni durum");
		//bir s�re sonra...
		subject.setMemento( mem );
		
		System.out.println(subject);
	}
	
	public static void main( String[] args ) {
		Caretaker ct = new Caretaker();
		ct.test();
	}
}
