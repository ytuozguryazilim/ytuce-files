/**
 * 
 */
package dp.chainOfResponsibility.example;

public enum GelirDuzeyi { A, B, C }