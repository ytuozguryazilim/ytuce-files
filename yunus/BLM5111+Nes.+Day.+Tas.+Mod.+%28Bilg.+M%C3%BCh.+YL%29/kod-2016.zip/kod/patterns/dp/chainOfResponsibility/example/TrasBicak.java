package dp.chainOfResponsibility.example;
public class TrasBicak extends Reklam {

	public TrasBicak(Banner banner, Reklam sonraki) {
		super(banner, sonraki);
	}

	public void reklamGoster(User u) {
		//Gerekli komutlar
	}

	public boolean reklamUygunMu(User u) {
		if( u.getCinsiyet() == Cinsiyet.ERKEK )
			if( u.yasDahilMi(18, 39))
				return true;
		return false;
	}

}
