package dp.chainOfResponsibility.example;

public class Banner {
	public void show() { }
}
