package dp.bridge.solution2;

public class DP2 {
	public static void drawline( double x1, double x2, 
			double y1, double y2 ) {
		//�izimi yap
	}
	public static void drawcircle ( double x, double y,
			double r ) {
		//�izimi yap
	}
}
