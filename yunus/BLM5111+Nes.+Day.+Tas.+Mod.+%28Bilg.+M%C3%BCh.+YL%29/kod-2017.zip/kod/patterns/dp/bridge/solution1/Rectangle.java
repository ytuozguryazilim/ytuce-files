package dp.bridge.solution1;

public abstract class Rectangle {
	private double _x1, _x2, _y1, _y2;
	public void draw( ) {
		drawLine(_x1,_y1,_x2,_y1);
		drawLine(_x2,_y1,_x2,_y2);
		drawLine(_x2,_y2,_x1,_y2);
		drawLine(_x1,_y2,_x1,_y1);
	}
	abstract protected void	drawLine ( double x1, double y1, 
		double x2, double y2);
}
