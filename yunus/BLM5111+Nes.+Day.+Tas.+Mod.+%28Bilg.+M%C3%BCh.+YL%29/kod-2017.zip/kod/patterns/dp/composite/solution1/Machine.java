package dp.composite.solution1;

import java.util.*;

public class Machine extends ManufacturingItem {
	private ArrayList<ManufacturingItem> parts;
	
	public Machine( int machineID, String name, String factory ) {
		super(machineID, name, factory);
		parts = new ArrayList<ManufacturingItem>();
	}

	public int getParentID() { return 0; }
	public void setParentID(int parentID) { } 
	
	public boolean addPart( ManufacturingItem part ) { 
		part.setParentID(getMachineID());
		for( ManufacturingItem aPart : parts )
			if( aPart == part )
				return false;
		return parts.add(part); 
	}
	public boolean removePart( ManufacturingItem part ) { return parts.remove(part); }
	public Iterator<ManufacturingItem> getParts( ) { return parts.iterator(); }

}
