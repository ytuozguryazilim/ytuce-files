package dp.composite.solution1;

import java.util.*;

public class Report {
	public static int findItems( ManufacturingItem items[], String factory ) {
		int nr = 0;
		System.out.println("Items manufactured in " + factory + ":");
		System.out.println("Nr.\tID\tName");
		System.out.println("----------------------------------");
		for( ManufacturingItem item : items ) {
			if( item==null )				continue;
			if( item.getFactory().compareToIgnoreCase(factory) == 0 ) {
				nr++;
				System.out.println( nr + ".\t" + item.getMachineID() + 
						"\t" + item.getName() );
			}
			Iterator<ManufacturingItem> subItems = item.getParts();
			if( subItems==null )				continue;
			while( subItems.hasNext() ) {
				ManufacturingItem part = subItems.next();
				if( part.getFactory().compareToIgnoreCase(factory) == 0 ) {
					nr++;
					System.out.println( nr + ".\t" + part.getMachineID() + 
							"\t" + part.getName() );
				}
			}
		}
		if( nr == 0 )
			System.out.println("No such item found.");
		return nr;
	}
}
