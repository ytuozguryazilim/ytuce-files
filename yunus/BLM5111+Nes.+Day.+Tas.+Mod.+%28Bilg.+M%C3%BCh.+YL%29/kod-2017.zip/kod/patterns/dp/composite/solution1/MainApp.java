package dp.composite.solution1;

public class MainApp {

	public static void main(String[] args) {
		ManufacturingItem[ ] items = new ManufacturingItem[4];
		items[0] = new MachinePart(99, 127, "Krank �aft� K�-7", "Bursa");
		Machine jenerator = new Machine(135, "Jenerat�r JMX-99", "�stanbul" );
		jenerator.addPart( new MachinePart(259, 135, "Flan� FTR-5", "Bursa") );
		jenerator.addPart( new MachinePart(378, 135, "Kasnak KS-9", "�stanbul") );
		jenerator.addPart( new MachinePart(196, 135, "Rulman RL-3", "Ankara") );
		items[1] = jenerator;
		items[2] = new MachinePart(63, 76, "Distrib�t�r DST-12", "Bursa");
		items[3] = new MachinePart(82, 19, "Pn�matik Vana VPN-7", "Ankara");
		int sayi = ReportV2.findItems(items, "Bursa");
		System.out.println("\t" + sayi + " par�a bulundu.");
	}

}
