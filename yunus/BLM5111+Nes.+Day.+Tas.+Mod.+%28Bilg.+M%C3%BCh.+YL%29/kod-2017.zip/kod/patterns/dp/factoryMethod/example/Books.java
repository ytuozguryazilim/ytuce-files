package dp.factoryMethod.example;

public class Books extends Order {
	@SuppressWarnings("unused")
	private String barcode;

	public Books(String barcode) {
		super();
		this.barcode = barcode;
	}

	@Override
	public void orderFromSupplier() {
		//Kitap i�in yap�lacak i�lemlerin tan�mlanmas�
	}

	@Override
	public void pack() {
		//Kitap i�in yap�lacak i�lemlerin tan�mlanmas�
	}

	@Override
	public void prepare() {
		//Kitap i�in yap�lacak i�lemlerin tan�mlanmas�
	}

	@Override
	public void sendToCustomer() {
		//Kitap i�in yap�lacak i�lemlerin tan�mlanmas�
	}

}
