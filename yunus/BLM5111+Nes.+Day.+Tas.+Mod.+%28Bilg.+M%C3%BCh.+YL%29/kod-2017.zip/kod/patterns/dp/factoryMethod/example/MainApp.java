package dp.factoryMethod.example;

public class MainApp {

	public static void main(String[] args) {
		Store store;
		//Elektronik �r�n sipari�i geldi
		store = new ElectronicsStore( );
		store.createOrder("5524345678");
		//Kitap sipari�i geldi
		store = new BookStore( );
		store.createOrder("8693243565");
	}

}
