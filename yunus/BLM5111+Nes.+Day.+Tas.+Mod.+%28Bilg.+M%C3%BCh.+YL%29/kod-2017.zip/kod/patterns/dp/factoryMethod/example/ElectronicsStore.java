package dp.factoryMethod.example;

/**
 * @uml.dependency   supplier="factoryMethod.example.Electronics"
 */
public class ElectronicsStore extends Store {

	@Override
	protected Order createOrder( String type ) {
		Electronics newElectronicsOrder = new Electronics( type );
		//Elektronik malzeme sipari�i i�in yap�lacak i�lemlerin tan�mlanmas�
		return newElectronicsOrder;
	}

}
