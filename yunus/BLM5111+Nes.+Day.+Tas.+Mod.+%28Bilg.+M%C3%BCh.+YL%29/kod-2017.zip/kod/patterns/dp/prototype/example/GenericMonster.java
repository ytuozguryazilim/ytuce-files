package dp.prototype.example;

public class GenericMonster extends Monster {

	public GenericMonster(int hp, int dex, int agl, int luck, int chr) {
		super(hp, dex, agl, luck, chr);
		type = "Generic Monster";
	}

	@Override
	public Monster clone( ) {
		return new GenericMonster(HP, DEX, AGL, LUCK, CHR);
	}

}
