package dp.observer.example;
import java.util.*;

public class Customer {
	private static Vector<ICObserver> myObs = 
		new Vector<ICObserver>( ); //G�zleyiciler ortak olacak.
	public static void attach(ICObserver o){
        myObs.addElement(o);
    }
    public static void detach(ICObserver o){
        myObs.remove(o);
    }
    public String getState () {
        // TODO: Burada durum bilgisini d�nd�r 
        return null;
    }
    public void notifyObs () {
        for( ICObserver obs : myObs ) {
        	obs.update(this);
        }
    }

}
