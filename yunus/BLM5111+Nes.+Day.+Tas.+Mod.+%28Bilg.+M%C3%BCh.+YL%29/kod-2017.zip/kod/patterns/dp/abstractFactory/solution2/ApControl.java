package dp.abstractFactory.solution2;

public class ApControl {
	private LibraryType library;
	private Renderer r; 
	private Shader s;
	public ApControl( ) {
		//library nesnesini ilklendirerek k�t�phane t�r�n� belirle
		switch (library){
			case OpenGL:
				r = new OpenGLRenderer();
				s = new OpenGLShader();
				break;
			case DirectX:
				r = new DirectXRenderer();
				s = new DirectXShader();
				break;
		}
	}
	void doRendering ( ) {
		r.renderOpA();
		r.renderOpB();
		r.renderOpC();
	}
	void doShading ( ) { 
		s.shadeOpA();
		s.shadeOpB();
		s.shadeOpC();
	}
}
