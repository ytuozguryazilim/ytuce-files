package dp.abstractFactory.solution2;

public class DirectXShader extends Shader {
	//do shading in DirectX
	public void shadeOpA() { }
	public void shadeOpB() { }
	public void shadeOpC() { }
}
