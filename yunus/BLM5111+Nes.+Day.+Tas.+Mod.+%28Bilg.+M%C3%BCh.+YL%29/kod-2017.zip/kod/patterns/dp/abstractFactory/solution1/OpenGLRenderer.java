package dp.abstractFactory.solution1;

public class OpenGLRenderer {
	//do rendering in OpenGL
	public void renderOpA() { }
	public void renderOpB() { }
	public void renderOpC() { }
}
