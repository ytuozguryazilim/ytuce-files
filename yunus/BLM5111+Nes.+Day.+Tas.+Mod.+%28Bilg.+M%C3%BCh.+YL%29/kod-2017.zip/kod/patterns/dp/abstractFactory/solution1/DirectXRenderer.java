package dp.abstractFactory.solution1;

public class DirectXRenderer {
	//do rendering in DirectX
	public void renderOpA() { }
	public void renderOpB() { }
	public void renderOpC() { }
}
