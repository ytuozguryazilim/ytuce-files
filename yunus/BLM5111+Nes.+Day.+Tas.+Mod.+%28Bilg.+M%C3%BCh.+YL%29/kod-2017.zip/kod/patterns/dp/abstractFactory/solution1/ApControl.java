package dp.abstractFactory.solution1;

public class ApControl {
	private LibraryType library;
	private OpenGLRenderer or; 
	private OpenGLShader os;
	private DirectXRenderer dr; 
	private DirectXShader ds;
	public ApControl( ) {
		//library nesnesini ilklendirerek k�t�phane t�r�n� belirle
	}
	void doRendering ( ) {
		switch (library){
			case OpenGL:
				or.renderOpA();
				or.renderOpB();
				or.renderOpC();
				break;
			case DirectX:
				dr.renderOpA();
				dr.renderOpB();
				dr.renderOpC();
				break;
		}
	}
	void doShading ( ) { 
		switch (library){
			case OpenGL:
				os.shadeOpA();
				os.shadeOpB();
				os.shadeOpC();
				break;
			case DirectX:
				ds.shadeOpA();
				ds.shadeOpB();
				ds.shadeOpC();
				break;
		}
	}
}
