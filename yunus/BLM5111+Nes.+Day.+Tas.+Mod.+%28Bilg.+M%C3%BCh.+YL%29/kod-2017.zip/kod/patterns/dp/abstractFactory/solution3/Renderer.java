package dp.abstractFactory.solution3;

public abstract class Renderer {
	public void renderOpA() { }
	public void renderOpB() { }
	public void renderOpC() { }
}
