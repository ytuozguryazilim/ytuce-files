package dp.strategy.solution2;

public class TRrules implements TaxRule {

	public double taxAmount(double income) {
		return income * 0.18;
	}

}
