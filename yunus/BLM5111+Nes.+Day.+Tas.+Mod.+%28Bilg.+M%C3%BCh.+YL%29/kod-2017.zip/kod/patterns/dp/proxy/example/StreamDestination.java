package dp.proxy.example;

public class StreamDestination {
	private StreamSource server;
	private String address;

	public StreamDestination(String address) {
		this.address = address;
	}
	public String getAddress() { return address; }
	public void setServer(StreamSource server) {
		this.server = server;
	}
	public boolean makePayment( double amount ) {
		//�demeyi yap.
		return true;
	}
	public boolean requestProgram( String programID ) {
		return server.stream(programID, address);
	}
}
