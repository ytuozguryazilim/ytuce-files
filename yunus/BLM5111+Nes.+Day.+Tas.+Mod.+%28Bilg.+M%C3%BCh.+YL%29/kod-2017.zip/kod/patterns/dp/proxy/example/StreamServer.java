package dp.proxy.example;


public class StreamServer implements StreamSource {

	public boolean stream(String programID, String destination) {
		// Program� haz�rla ve g�nder
		return true;
	}

}
