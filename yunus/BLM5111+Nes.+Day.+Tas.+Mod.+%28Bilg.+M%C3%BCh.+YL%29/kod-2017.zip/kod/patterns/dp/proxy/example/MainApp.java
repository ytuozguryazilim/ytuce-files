package dp.proxy.example;

public class MainApp {
	public static void main(String[] args) {
		StreamServer realServer = new StreamServer();
		StreamProxy proxyServer = new StreamProxy(realServer);
		StreamDestination client = new StreamDestination("12:aa:34:ff:54");
		client.setServer(proxyServer);
	}
}
