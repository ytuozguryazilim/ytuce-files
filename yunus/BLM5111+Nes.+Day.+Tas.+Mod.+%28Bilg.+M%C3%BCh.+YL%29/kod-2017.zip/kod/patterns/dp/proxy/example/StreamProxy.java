package dp.proxy.example;

public class StreamProxy implements StreamSource {
	private StreamSource original;

	public StreamProxy(StreamSource original) {
		this.original = original;
	}
	
	public boolean stream(String programID, String destination) {
		if( checkPayment(programID, destination) )
			return original.stream(programID, destination);
		else
			return false;
	}
	
	public boolean checkPayment(String programID, String destination) {
		// �demeyi destination parametresine g�re kontrol et
		// �deme yap�lm��sa true, aksi halde false d�nd�r.
		return false;
	}

}
