package dp.proxy.example;

public interface StreamSource {
		public boolean stream(String programID, String destination);
}
