package dp.singleton.example;

public class USrules implements TaxRule {
	private static USrules instance;

	private USrules( ) {
		//gerekli ilklendirmeler
	}
	
	public static USrules getInstance() {
		if( instance == null )
			instance = new USrules( );
		return instance;
	}

	public double taxAmount(double income) {
		return income * 0.12;
	}

}
