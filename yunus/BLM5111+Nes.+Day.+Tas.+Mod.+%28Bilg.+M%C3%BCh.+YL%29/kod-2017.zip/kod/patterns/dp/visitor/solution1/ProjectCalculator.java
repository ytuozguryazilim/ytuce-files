package dp.visitor.solution1;

public class ProjectCalculator {
	private Project project;
	public ProjectCalculator(Project project) {
		this.project = project;
	}
	public double calculateTimeRequired( ) {
		double time = 0.0;
		for( ProjectItem item : project.getProjectItems() ) {
			if( item instanceof Task ) {
				time += calculateTimeRequired((Task)item);
			}
		}
		return time;
	}
	private double calculateTimeRequired( Task subTask ) {
		double time = subTask.getTimeRequired();
		for( ProjectItem item : subTask.getProjectItems() ) {
			if( item instanceof Task ) {
				time += calculateTimeRequired((Task)item);
			}
		}
		return time;
	}
	public double calculateCost( ) {
		double cost = 0.0;
		for( ProjectItem item : project.getProjectItems() ) {
			if( item instanceof Deliverable )
				cost += ((Deliverable)item).getMaterialsCost()+
						((Deliverable)item).getProductionCost();
			if( item instanceof Task )
				cost += calculateCost((Task)item);
		}	
		return cost;
	}
	private double calculateCost( Task subTask ) {
		double cost = 0.0;
		for( ProjectItem item : subTask.getProjectItems() ) {
			if( item instanceof Deliverable )
				cost += ((Deliverable)item).getMaterialsCost()+
						((Deliverable)item).getProductionCost();
			if( item instanceof Task )
				cost += calculateCost((Task)item);
		}
		return cost;
	}

}
