package dp.flyweight.solution3;
import java.util.*;
public class Karisim {
	private String isim;
	private LinkedList<Bilesen> maddeler = new LinkedList<Bilesen>();
	public String getIsim() { return isim; }
	public void setIsim(String isim) { this.isim = isim; }
	public void maddeEkle( String simge, double gram ) {
		maddeler.add( new Bilesen(gram, MaddeFabrikasi.maddeBul(simge)) );
	}
	public String tarifEt( ) {
		String tarif = isim;
		for( Bilesen madde : maddeler )
			tarif += "\n" + madde.getGram() + "gr " + madde.getMaddeAdi();
		return tarif;
	}
}
