package dp.flyweight.solution3;

public class Bilesen {
	private double gram;
	private KimyasalMadde madde;

	public Bilesen( double gram, KimyasalMadde madde ) {
		this.gram = gram; this.madde = madde;
	}
	public double getGram( ) { return gram; }
	public double getMol( ) { return madde.getMol(gram); }
	public String getMaddeAdi( ) { return madde.getIsim( ); }
}
