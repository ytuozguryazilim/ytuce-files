package dp.flyweight.solution3;

public class MainApp {
	public static void main(String[] args) {
		Karisim karaBarut = new Karisim();
		karaBarut.setIsim("Kara barut");
		karaBarut.maddeEkle("NaNO3", 75);
		karaBarut.maddeEkle("C", 15);
		karaBarut.maddeEkle("S", 10);
		System.out.println( karaBarut.tarifEt() );
		Karisim temizBarut = new Karisim();
		temizBarut.setIsim("Temiz barut");
		temizBarut.maddeEkle("KNO3", 75);
		temizBarut.maddeEkle("C", 20);
		temizBarut.maddeEkle("S", 25);
		System.out.println( temizBarut.tarifEt() );
	}

}
