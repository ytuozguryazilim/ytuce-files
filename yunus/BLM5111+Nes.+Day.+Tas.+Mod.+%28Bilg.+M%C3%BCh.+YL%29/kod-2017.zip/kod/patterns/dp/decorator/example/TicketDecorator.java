package dp.decorator.example;

public abstract class TicketDecorator extends Component {
	private Component myTrailer;
    public TicketDecorator (Component myComponent) {
        myTrailer= myComponent;
    }
    public void callTrailer () {
        if (myTrailer != null) myTrailer.prtTicket();
    }

}
