package dp.decorator.example;

public abstract class Component {
	abstract public void prtTicket();
}
