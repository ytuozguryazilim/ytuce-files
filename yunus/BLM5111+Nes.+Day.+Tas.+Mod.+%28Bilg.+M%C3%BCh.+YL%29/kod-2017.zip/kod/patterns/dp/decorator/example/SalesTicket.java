package dp.decorator.example;

public class SalesTicket extends Component {
	public void prtTicket() {
		// place sales ticket printing code here
	       System.out.println(getClass().getName());
	}
}
