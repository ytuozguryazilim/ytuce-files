package dp.mediator.example;

public interface ManufacturingItem {
	public void accept( ManufacturingItemVisitor visitor );
}
