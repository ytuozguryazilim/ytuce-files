package dp.mediator.example;

import java.util.*;

public class Machine implements ManufacturingItem {
	private int machineID;
	private String name, factory;
	private ArrayList<MachinePart> parts;

	public Machine(int machineID, String name, String factory) {
		this.machineID = machineID;
		this.name = name;
		this.factory = factory;
		parts = new  ArrayList<MachinePart>();
	}

	public int getMachineID() { return machineID; }
	public String getName( ) { return name; }
	public String getFactory() { return factory; }
	public void setFactory(String factory) { this.factory = factory; }

	public boolean addPart( Mediator med, MachinePart part ) { 
			return med.addPartToMachine(this, part); 
	}
	boolean addPart( MachinePart part ) { return parts.add(part); }
	public boolean removePart( Mediator med, MachinePart part ) { 
		return med.removePartFromMachine(this, part); 
	}
	boolean removePart( MachinePart part ) { return parts.remove(part); }

	public void accept(ManufacturingItemVisitor visitor) {
		visitor.visit(this);
		for( MachinePart part : parts )
			visitor.visit(part);
	}
}
