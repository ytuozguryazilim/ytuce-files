package dp.mediator.example;

public class PrintItem implements ManufacturingItemVisitor {
	private Machine initial;

	public PrintItem(Machine initial) { this.initial = initial; }
	public void beginPrinting( ) { initial.accept(this); }

	public void visit(Machine machine) {
		System.out.println(machine.getMachineID()+"\t"+machine.getName());
	}

	public void visit(MachinePart part) {
		System.out.println(part.getParentID()+"\t"+part.getPartID()+"\t"+part.getName());
	}


}
