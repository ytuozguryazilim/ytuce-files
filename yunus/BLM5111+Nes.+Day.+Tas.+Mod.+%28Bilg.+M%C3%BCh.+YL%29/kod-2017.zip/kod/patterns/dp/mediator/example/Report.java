package dp.mediator.example;

public class Report implements ManufacturingItemVisitor {
	private int nr;
	private ManufacturingItem items[];
	private String factory;
	
	public Report(ManufacturingItem[] items, String factory) {
		nr = 0;
		this.items = items;
		this.factory = factory;
	}
	

	public int findItems( ) {
		System.out.println("Items manufactured in " + factory);
		System.out.println("Nr.\tID\tName");
		System.out.println("----------------------------------");
		for( ManufacturingItem item : items ) {
			item.accept(this);
		}
		if( nr == 0 )
			System.out.println("No such item found.");
		return nr;
	}
	
	public void visit( Machine machine ) {
		if( machine.getFactory().equalsIgnoreCase(factory)) {
			nr++;
			System.out.println( nr + ".\t" + machine.getMachineID() + 
					"\t" + machine.getName() );
		}
	}

	public void visit( MachinePart part ) {
		if( part.getFactory().equalsIgnoreCase(factory)) {
			nr++;
			System.out.println( nr + ".\t" + part.getPartID() + 
					"\t" + part.getName() );
		}
	}

}
