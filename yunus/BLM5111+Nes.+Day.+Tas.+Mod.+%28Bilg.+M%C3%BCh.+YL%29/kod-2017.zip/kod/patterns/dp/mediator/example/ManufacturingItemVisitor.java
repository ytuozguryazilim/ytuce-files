package dp.mediator.example;

public interface ManufacturingItemVisitor {
	public void visit( Machine machine );
	public void visit( MachinePart part );
}
