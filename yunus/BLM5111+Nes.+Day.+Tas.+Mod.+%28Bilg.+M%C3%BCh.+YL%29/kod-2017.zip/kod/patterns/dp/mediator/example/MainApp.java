package dp.mediator.example;

public class MainApp {

	public static void main(String[] args) {
		Mediator med = new MediatorImpl( );
		Machine jenerator = new Machine(135, "Jenerat�r JMX-99", "�stanbul" );
		MachinePart part1 = new MachinePart(259, 135, "Flan� FTR-5", "Bursa");
		MachinePart part2 = new MachinePart(378, 332, "Kasnak KS-9", "Konya");
		//part2'deki hatay� g�rd�n�z m�?
		med.addPartToMachine(jenerator,part1);
		med.addPartToMachine(jenerator,part2);
		//yine de ekleyecek
		PrintItem rapor = new PrintItem(jenerator);
		rapor.beginPrinting();
		
	}

}
