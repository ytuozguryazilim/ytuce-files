package dp.iterator.example;
import java.util.*;
public class WaitressQuickAndDirty {
	private PancakeHouseMenu pancakeHouseMenu;
	private DinerMenu dinerMenu;
	
	public WaitressQuickAndDirty() {
		pancakeHouseMenu = new PancakeHouseMenu();
		dinerMenu = new DinerMenu();
	}
	
	public void printMenu() {
		System.out.println("MENU\n----\nBREAKFAST");
		ArrayList<MenuItem> breakfastItems = pancakeHouseMenu.getMenuItems();
		for( int i=0; i<breakfastItems.size(); i++ ) {
			MenuItem item = breakfastItems.get(i);
			printMenuItem(item);
		}
		System.out.println("\nLUNCH");
		MenuItem[] dinerItems = dinerMenu.getMenuItems();
		for( int i=0; i<dinerItems.length; i++ ) {
			MenuItem item = dinerItems[i];
			printMenuItem(item);
		}
	}
	private void printMenuItem( MenuItem menuItem ) {
		System.out.print(menuItem.getName() + ", ");
		System.out.print(menuItem.getPrice() + " -- ");
		System.out.println(menuItem.getDescription());
	}

	public void printVegetarianMenu() {
		System.out.println("\nVEGETARIAN MENU\n----\nBREAKFAST");
		ArrayList<MenuItem> breakfastItems = pancakeHouseMenu.getMenuItems();
		for( int i=0; i<breakfastItems.size(); i++ ) {
			MenuItem item = breakfastItems.get(i);
			if( item.isVegetarian() )
				printMenuItem(item);
		}
		System.out.println("\nLUNCH");
		MenuItem[] dinerItems = dinerMenu.getMenuItems();
		for( int i=0; i<dinerItems.length; i++ ) {
			MenuItem item = dinerItems[i];
			if( item.isVegetarian() )
				printMenuItem(item);
		}
	}
	public void printBreakfastMenu() {
		System.out.println("MENU\n----\nBREAKFAST");
		ArrayList<MenuItem> breakfastItems = pancakeHouseMenu.getMenuItems();
		for( int i=0; i<breakfastItems.size(); i++ ) {
			MenuItem item = breakfastItems.get(i);
			printMenuItem(item);
		}
	}
	public void printDinerMenu() {
		System.out.println("MENU\n----\nLUNCH");
		MenuItem[] dinerItems = dinerMenu.getMenuItems();
		for( int i=0; i<dinerItems.length; i++ ) {
			MenuItem item = dinerItems[i];
			printMenuItem(item);
		}
	}
	
	public static void main(String args[]) {
		WaitressQuickAndDirty w = new WaitressQuickAndDirty();
		w.printMenu();
	}

}
