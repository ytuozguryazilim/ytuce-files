package dp.iterator.example;

public interface Menu {
	public java.util.Iterator<MenuItem> createIterator();
}
