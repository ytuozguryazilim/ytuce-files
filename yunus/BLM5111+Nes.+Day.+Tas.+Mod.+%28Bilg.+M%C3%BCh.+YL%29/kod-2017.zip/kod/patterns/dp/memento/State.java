package dp.memento;

public class State {
	private String durum;

	public String getDurum() {
		return durum;
	}

	public void setDurum(String durum) {
		this.durum = durum;
	}
	

}
