package dp.memento;

public class Memento {
	private State state;

	State getState() {
		return state;
	}

	void setState(State state) {
		this.state = new State();
		this.state.setDurum(state.getDurum());
	}

}
