package dp.mementoV2.innerClass;

public class Originator {
	private State state;
	
	public Originator( ) {
		state = new State( );
	}

	public Memento createMemento( ) {
		Memento m = new Memento( );
		m.setState(state.clone());
		return m;
	}
	
	public void setMemento( Memento m ) {
		state = m.getState();
	}
	
	public void modify( String str ) {
		state.setDurum(str);
	}
	
	public String toString() {
		return state.getDurum();
	}
	
	public class Memento {
		private State state;

		private State getState() {
			return state;
		}

		private void setState(State state) {
			this.state = state;
		}

	}

}
