package dp.mementoV2.innerClass;

public class Caretaker {
	public void test( ) {
		Originator subject = new Originator( );
		subject.modify("ilk durum");
		subject.modify("yeni durum");
		//bir s�re sonra...
		System.out.println(subject);
	}
	
	public static void main( String[] args ) {
		Caretaker ct = new Caretaker();
		ct.test();
	}
}
