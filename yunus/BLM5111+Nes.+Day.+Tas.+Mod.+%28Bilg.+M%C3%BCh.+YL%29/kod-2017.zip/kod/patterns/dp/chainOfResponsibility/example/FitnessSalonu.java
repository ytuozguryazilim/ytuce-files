package dp.chainOfResponsibility.example;
public class FitnessSalonu extends Reklam {

	public FitnessSalonu(Banner banner, Reklam sonraki) {
		super(banner, sonraki);
	}

	public void reklamGoster(User u) {
		//Gerekli komutlar
	}

	public boolean reklamUygunMu(User u) {
		if( u.getCinsiyet() == Cinsiyet.KADIN )
			if( u.yasDahilMi(18, 39))
				return true;
		return false;
	}

}
