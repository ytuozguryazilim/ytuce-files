package dp.templateMethod.example;

public abstract class QueryTemplate {
	public final void doQuery( String DBname, String querySpec ) {
		@SuppressWarnings("unused")
		String dbCommand;
		dbCommand = formatConnect( DBname );
		//dbCommand komutunu y�r�terek ba�lant�y� kur.
		dbCommand = formatSelect( querySpec );
		//dbCommand komutunu y�r�terek kay�tlar� oku.
		//Olu�an veri k�mesini geri d�nd�r.
	}
	abstract String formatConnect( String DBname );
	abstract String formatSelect( String querySpec );
}
