package ooc02;

public class Car {
	private String plate;
	public Car( String plateNr ) {
		plate = plateNr;
	}
	public String getPlate() {
		return plate;
	}
}
