package ooc01c;
public class MathOps01 {
	public static void main(String[] args) {
		double value = Math.random();
		System.out.println("The generated random value is: " + value);
	}
}
