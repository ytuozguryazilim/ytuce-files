package ooc01c;
public class MathOps2 {
	public static void main(String[] args) {
		double value = 3.5;
		double result = Math.round(value);
		System.out.println(value + " becomes " + result);
	}
}
