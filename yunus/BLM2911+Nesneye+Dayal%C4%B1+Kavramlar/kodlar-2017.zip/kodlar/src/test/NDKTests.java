package test;

import ooc01a.*;
//import java.util.*;

public class NDKTests {

	public static void main(String[] args) {
/*		Scanner input = new Scanner(System.in);
		System.out.println("Enter license Plate: ");
		String plate = input.nextLine();
		System.out.println("Enter chassis nr: ");
		String chassis = input.nextLine();
		Car aCar = new Car(plate,chassis);
		System.out.println("Enter new plate: ");
		aCar.setPlate(input.nextLine());
		System.out.println(aCar.getPlate() + " " 
				+ aCar.getChassisNR() );
		input.close();*/
		Car.main(args);
	}

}
