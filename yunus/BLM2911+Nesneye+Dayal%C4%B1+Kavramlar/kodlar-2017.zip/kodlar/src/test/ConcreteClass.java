package test;

public class ConcreteClass extends TestOfInterface{

	public ConcreteClass() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void aMethod() {
		// TODO Auto-generated method stub
		
	}

}
