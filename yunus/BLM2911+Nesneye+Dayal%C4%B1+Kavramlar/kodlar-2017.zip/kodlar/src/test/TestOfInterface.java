package test;

public abstract class TestOfInterface implements IMethodTests {

	public TestOfInterface() {
		// TODO Auto-generated constructor stub
	}

}
