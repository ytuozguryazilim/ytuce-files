package test;

public interface IMethodTests {
	public void aMethod();
}
