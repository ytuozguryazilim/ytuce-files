package examples01;
import java.util.*;
public class Rectangle {
	private int rows, cols;
	public final static int maxRow = 24, maxCol = 80;
	
	public Rectangle( int rows, int cols ) {
		this.rows = rows; this.cols = cols;
		if( !isRowValid() )
			this.rows = maxRow;
		if( !isColValid() )
			this.cols = maxCol;
	}
	public int getRows() { return rows; }
	public int getCols() { return cols; }
	public void draw() {
		for( int i=0; i<rows; i++ ) {
			for( int j=0; j<cols; j++ ) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	public boolean isRowValid() {
		if( rows > 0 && rows <= maxRow )
			return true;
		return false;
	}
	public boolean isColValid() {
		if( cols > 0 && cols <= maxCol )
			return true;
		return false;
	}
	public static void main2( String[] args ) {
		Rectangle r1 = new Rectangle(30, 88);
		r1.draw();
		if( r1.isColValid() && r1.isRowValid() )
			System.out.println("Test1 OK");
		else
			System.out.println("Test1 Fail");
		System.out.println("Rows: " + r1.getRows() 
				+ ", Cols: " + r1.getCols() );
	}
	public static void main( String[] args ) {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter row count: ");
		int rows = in.nextInt();
		System.out.print("Enter column count: ");
		int cols = in.nextInt();
		Rectangle r1 = new Rectangle(rows, cols);
		r1.draw();
		in.close();
	}

}
