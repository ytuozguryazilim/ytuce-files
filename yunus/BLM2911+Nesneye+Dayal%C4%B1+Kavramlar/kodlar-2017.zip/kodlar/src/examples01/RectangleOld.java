package examples01;
import java.util.Scanner;
public class RectangleOld {
	private int sideA, sideB;
	private final static int maxSideA = 24, maxSideB = 80;
	public RectangleOld(int sideA, int sideB) {
		if( sideA > maxSideA )
			this.sideA = maxSideA;
		else
			this.sideA = sideA;
		if( sideB > maxSideB )
			this.sideB = maxSideB;
		else
			this.sideB = sideB;
	}
	public void setSideA( int sideA ) {
		if( sideA > maxSideA )
			this.sideA = maxSideA;
		else
			this.sideA = sideA;
	}
	public void setSideB( int sideB ) {
		if( sideB > maxSideB )
			this.sideB = maxSideB;
		else
			this.sideB = sideB;
	}
	public void draw() {
		for( int i=0; i<sideA; i++ ) {
			for( int j=0; j<sideB; j++ ) {
				if( i == 0 || i == sideA-1 
						|| j == 0 || j == sideB-1)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
	}
	public static void main( String[] args ) {
		Scanner in = new Scanner( System.in );
		System.out.print("Enter side A: ");
		int a = in.nextInt();
		System.out.print("Enter side B: ");
		int b = in.nextInt();
		RectangleOld r = new RectangleOld( a, b );
		r.draw();
		in.close();
	}
}
