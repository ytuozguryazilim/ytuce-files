package ooc07;

public interface PersonalVehicle {
	public double calculateTax( double baseTax );
}
