package ooc08.strategy;

public class Adult implements IAge {

	@Override
	public void buyCigarette() {
		System.out.println("Cigarettes are bought. Smoking Kills!");
	}

	@Override
	public void buyCandy() {
		System.out.println("Candies are bought. Do not get fat.");
	}

}
