package ooc08.strategy;

public class YoungAdult implements IAge {

	@Override
	public void buyCigarette() {
		System.out.println("Cigarettes are bought. You should consider quitting.");
	}

	@Override
	public void buyCandy() {
		System.out.println("Candies are bought.");
	}

}
