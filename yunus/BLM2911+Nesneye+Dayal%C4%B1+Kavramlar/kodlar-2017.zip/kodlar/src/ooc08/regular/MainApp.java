package ooc08.regular;

public class MainApp {
	public static void main( String[] args ) {
		Person[] people = new Person[3];
		people[0] = new Kid("Olcan Sel�uk");
		people[1] = new YoungAdult("F�rat Ertemel");
		people[2] = new Adult("Yunus Emre Sel�uk");
		for(Person person : people) {
			person.buyCandy();
			person.buyCigarette();
		}
	}
}
