package ooc08.regular;

public class YoungAdult extends Person {
	public YoungAdult(String name) {
		super(name);
	}
	public void buyCigarette() {
		System.out.println("Cigarettes are bought. You should consider quitting.");
	}
	public void buyCandy() {
		System.out.println("Candies are bought.");
	}

}
