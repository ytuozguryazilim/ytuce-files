package ooc08.regular;

public class Kid extends Person {
	public Kid(String name) {
		super(name);
	}
	public void buyCigarette() {
		System.out.println("A kid cannot buy cigarettes");
		return;
	}
	public void buyCandy() {
		System.out.println("Wow. So many candies!");
	}
}
