package ooc05;

public class GalleryOwner extends Person {
	private String galleryName;
	private Car[] cars;
	private int carCount;

	public GalleryOwner( String isim ) { 
		super( isim );
		carCount = 0;
		cars = new Car[30];
	}
	public String getGalleryName() { return galleryName; }
	public void setGalleryName(String galleryName) { 
		this.galleryName = galleryName; 
	}
	public String toString( ) {
		String intro = "[GalleryOwner]"+introduceSelf();
		intro += " and I run a car gallery named " + galleryName;
		intro += ", having " + carCount + " cars to sell.";
		return intro;
	}
	public boolean addCar( Car araba ) {
		if( !searchCar(araba) && carCount < cars.length ) {
			cars[ carCount ] = araba;
			carCount++;
			return true;
		}
		return false;
	}
	public boolean searchCar( Car aCar ) {
		for( Car car : cars )
			if( car == aCar )
				return true;
		return false;
	}
	public Car searchCar( String plate ) {
		for( int i = 0; i < carCount; i++ )
			if( cars[i].getPlate().compareTo(plate) == 0 )
				return cars[i];
		return null;
	}
	public Car removeCar( String plate ) {
		for( int i = 0; i < carCount; i++ ) {
			if( cars[i].getPlate().compareTo(plate) == 0 ) {
				Car theCar = cars[i];
				for( int j = i; j < carCount; j++ ) 
					cars[j] = cars[j+1];
				cars[carCount] = null;
				return theCar;
			}
		}
		return null;
	}
	public boolean sell( String plate ) {
		if( removeCar(plate) != null ) {
			//TODO: code monetary issues
			return true;
		}
		return false;
	}
}
