package ooc01c;

public class StringOps01 {
	   public static void main( String args[] ) {
			String strA, strB;
			strA = "A string!";
			strB = "This is another one. A longer one.";
			System.out.println(strA.compareTo(strB));
		   }

}
