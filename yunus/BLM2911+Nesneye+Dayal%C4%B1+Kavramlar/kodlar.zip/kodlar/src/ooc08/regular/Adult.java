package ooc08.regular;

public class Adult extends Person {
	public Adult(String name) {
		super(name);
	}
	public void buyCigarette() {
		System.out.println("Cigarettes are bought. Smoking Kills!");
	}
	public void buyCandy() {
		System.out.println("Candies are bought. Do not get fat.");
	}

}
