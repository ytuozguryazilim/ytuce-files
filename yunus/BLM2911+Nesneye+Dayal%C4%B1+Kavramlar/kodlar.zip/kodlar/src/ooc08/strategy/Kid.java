package ooc08.strategy;

public class Kid implements IAge {

	@Override
	public void buyCigarette() {
		System.out.println("A kid cannot buy cigarettes");
		return;
	}

	@Override
	public void buyCandy() {
		System.out.println("Wow. So many candies!");
	}

}
