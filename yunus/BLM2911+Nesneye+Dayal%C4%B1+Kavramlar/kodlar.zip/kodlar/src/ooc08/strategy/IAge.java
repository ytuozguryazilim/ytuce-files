package ooc08.strategy;

public interface IAge {
	public void buyCigarette();
	public void buyCandy();
}
