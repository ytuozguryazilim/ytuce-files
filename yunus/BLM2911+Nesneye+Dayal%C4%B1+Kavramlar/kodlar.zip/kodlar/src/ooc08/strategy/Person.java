package ooc08.strategy;

public class Person {
	private String name;
	private IAge age;

	public Person(String name, IAge age) {
		this.name = name;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void buyCandies() {
		age.buyCandy();
	}
	public void buyCigars() {
		age.buyCigarette();
	}
	public static void main( String[] args ) {
		Person[] people = new Person[3];
		people[0] = new Person("Olcan Sel�uk", new Kid());
		people[1] = new Person("F�rat Ertemel", new YoungAdult());
		people[2] = new Person("Yunus Emre Sel�uk", new Adult());
		for(Person person : people) {
			person.buyCandies();
			person.buyCigars();
		}
		
	}
	

}
