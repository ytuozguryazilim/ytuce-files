package ooc01a;

public class Car {
	   private String plate;
	   public Car( String plateNr ) {
	      plate = plateNr;
	   }   
	   public String getPlate() {
	      return plate;
	   }
	   public void setPlate(String plate) {
	      this.plate = plate;
	   }
	   public void introduceSelf( ) {
	      System.out.println( "My plate: " + getPlate() );
	   }
	   public void introduceOtherCar( Car another ) {
		   System.out.println( "Plate of other car is " + another.plate);
	   }
	   public void introducePerson( Person someone ) {
		   System.out.println("That person is called " + someone.getName());
	   }
	   public static void main( String[] args ) {
	      Car aCar;
	      aCar = new Car( "34 RA 440" );
	      aCar.introduceSelf( );
	      Car car2 = new Car("06 ANK 876");
	      aCar.introduceOtherCar(car2);
	      Person yunus = new Person("Yunus Emre");
	      aCar.introducePerson(yunus);
	      
	   }
	}
