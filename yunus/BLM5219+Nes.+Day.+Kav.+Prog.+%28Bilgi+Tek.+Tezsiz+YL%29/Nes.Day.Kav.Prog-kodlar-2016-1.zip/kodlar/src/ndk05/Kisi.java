package ndk05;

public class Kisi {
	private String isim;

	public Kisi( String name ) {
		this.isim = name;
	}

	public String getIsim( ) {
		return isim;
	}
	
}
