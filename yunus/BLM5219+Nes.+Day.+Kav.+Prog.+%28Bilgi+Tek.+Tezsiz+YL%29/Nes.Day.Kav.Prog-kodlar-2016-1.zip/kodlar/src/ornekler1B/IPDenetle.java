package ornekler1B;

import java.util.*;

public class IPDenetle {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("Bir IP adresi giriniz: ");
		String adres = giris.nextLine();
		String[] parcalar = adres.split(".");
		/* RegExp'de . demek any char demekmi�. �nce .->: de�i�tir mesela sonra onu ay�r vb ek i�.
		 * */
		for( String s : parcalar )
			System.out.println(s);
		giris.close();
	}
}
