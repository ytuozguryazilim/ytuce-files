package ornekler1B;
import java.util.*;
public class AritmetikOrta {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("Ka� adet say�n�n aritmetik ortalamas�n� bulacaks�n�z? ");
		int n = giris.nextInt();
		int toplam = 0;
		for( int i = 0; i < n; i++ ) {
			System.out.print("Tamsay� giriniz: ");
			toplam += giris.nextInt();
		}
		double ortalama = toplam / n;
		System.out.println("Aritmetik ortalama: " + ortalama);
		giris.close();
	}
}
