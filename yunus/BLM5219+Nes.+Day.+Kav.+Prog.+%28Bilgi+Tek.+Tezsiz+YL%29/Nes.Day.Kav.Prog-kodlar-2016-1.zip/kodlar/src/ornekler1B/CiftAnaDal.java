package ornekler1B;
import java.util.*;
public class CiftAnaDal {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("��rencinin not ortalamas�n� girin: ");
		double notOrt = giris.nextDouble();
		if( notOrt >= 2.75 ) {
			System.out.print("��rencinin d�nemini girin: ");
			int donem = giris.nextInt();
			if( donem >= 3 && donem <= 5 ) {
				System.out.println("��renci �AP yapabilir.");
			}
			else {
				System.out.println("��renci �AP yapamaz.");
				System.out.println("D�nem gereksinimi kar��lanm�yor.");
			}
		}
		else {
			System.out.println("��renci �AP yapamaz.");
			System.out.println("Not gereksinimi kar��lanm�yor.");
		}
		giris.close();
	}
}
