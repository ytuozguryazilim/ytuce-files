package ornekler1B;
import java.util.*;
public class TamBolenler {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("Bir tamsay� giriniz: ");
		int sayi = giris.nextInt();
		for( int i=1; i<=sayi/2; i++ )
			if( sayi % i == 0 )
				System.out.print( i + " " );
		giris.close();
	}
}
