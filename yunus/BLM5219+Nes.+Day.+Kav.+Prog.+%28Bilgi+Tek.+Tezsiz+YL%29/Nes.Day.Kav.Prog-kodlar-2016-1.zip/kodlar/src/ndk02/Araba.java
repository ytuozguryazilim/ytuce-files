package ndk02;

public class Araba {
	   private String plaka;
	   //private final static String cins = "Ben bir araba nesnesiyim.";
	   
	   public Araba( String plakaNo ) {
		   plaka = plakaNo;
	   }
	   public String getPlaka( ) {
	      return plaka;
	   }
	   /*public void setPlaka( String plaka ) {
	      this.plaka = plaka;
	   }*/
	   /*public void kendiniTanit( ) {
	      System.out.println( cins );
	      System.out.println( "Plakam: " + getPlaka() );
	   }
	   
	   public static void main( String[] args ) {
	      Araba benimArabam;
	      benimArabam = new Araba( "34 RA 440" );
	      benimArabam.kendiniTanit( );
	   }*/

}
