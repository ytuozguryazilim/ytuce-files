package ornekler1C.EBS;

public class Doktor extends Insan {
	private int sicilNo;

	public Doktor(String ad, String soyad, long TCkimlik, int sicilNo) {
		super(ad, soyad, TCkimlik);
		this.sicilNo = sicilNo;
	}
	public int getSicilNo() {
		return sicilNo;
	}

}
