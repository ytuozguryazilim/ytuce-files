package ornekler1C.EBS;

public abstract class Insan {
	private String ad, soyad;
	private long TCkimlik;
	public Insan(String ad, String soyad, long tCkimlik) {
		this.ad = ad; this.soyad = soyad; 
		TCkimlik = tCkimlik;
	}
	public String getAd() { return ad; }
	public String getSoyad() { return soyad; }
	public long getTCkimlik() { return TCkimlik; }
}
