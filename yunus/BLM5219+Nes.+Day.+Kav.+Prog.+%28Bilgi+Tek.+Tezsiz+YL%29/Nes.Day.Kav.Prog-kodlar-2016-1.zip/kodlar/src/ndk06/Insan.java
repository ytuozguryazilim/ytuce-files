package ndk06;

public class Insan {
	private String isim;
	private Araba araba;

	public Insan( String isim ) {
		this.isim = isim;
	}

	public String getIsim( ) { return isim; }

	public Araba getAraba( ) { return araba; }

	public void setAraba( Araba araba ) { 
		this.araba = araba; 
		if( this.araba.getSahip() != this )
			this.araba.setSahip(this);
	}
	
	public String toString( ) {
		String tanitim;
		tanitim = "Merhaba, benim ad�m " + isim + ".";
		if( araba != null )
			tanitim += "\n" + araba.getPlaka()+" plakal� bir arabam var.";
		return tanitim;
	}

}
