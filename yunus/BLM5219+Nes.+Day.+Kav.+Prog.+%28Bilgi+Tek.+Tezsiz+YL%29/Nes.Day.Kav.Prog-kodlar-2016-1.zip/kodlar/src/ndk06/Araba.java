package ndk06;
public class Araba {
	private String plaka;
	private Insan sahip;
	public final static String cins = "Ben bir araba nesnesiyim.";

	public Araba( String plakaNo ) { plaka = plakaNo; }
	public Araba(String plaka, Insan sahip) {
		this.plaka = plaka;
		this.sahip = sahip;
	}
	public void setSahip( Insan sahip ) { 
		this.sahip = sahip;
		if( this.sahip.getAraba() != this )
			this.sahip.setAraba(this);
	}
	public Insan getSahip() { return sahip; }
	public String getPlaka( ) { return plaka; }
	public void setPlaka( String plaka ) { this.plaka = plaka; }
	public String kendiniTanit( ) {
		String tanitim;
		tanitim = cins + "Plakam: " + getPlaka() + ".";
		if( sahip != null )
			tanitim += "\nSahibimin ad�: " + sahip.getIsim();
		return tanitim;
	}
}
