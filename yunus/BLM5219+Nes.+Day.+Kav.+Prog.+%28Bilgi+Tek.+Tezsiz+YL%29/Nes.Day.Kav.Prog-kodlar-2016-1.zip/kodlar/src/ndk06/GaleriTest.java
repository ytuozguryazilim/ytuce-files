package ndk06;

public class GaleriTest {

	public static void main(String[] args) {
		GalericiInsan yunus = new GalericiInsan("Yunus Zengin");
		Araba honda = new Araba("34 GH 001");
		boolean sonuc = yunus.arabaEkle(honda);
		if( sonuc )
			System.out.println("Test1 OK");
		else
			System.out.println("Test1 FAIL");
		sonuc = yunus.arabaEkle(honda);
		if( !sonuc )
			System.out.println("Test2 OK");
		else
			System.out.println("Test2 FAIL");
		yunus.arabaEkle( new Araba("34 GA 002") );
		yunus.arabaEkle( new Araba("34 GA 003") );
		yunus.arabaEkle( new Araba("34 GA 004") );
		if( yunus.arabaAra("34 GA 003") != null )
			System.out.println("Test3 OK");
		else
			System.out.println("Test3 FAIL");
		if( yunus.arabaSat("34 GA 002") )
			System.out.println("Test4 OK");
		else
			System.out.println("Test4 FAIL");
		if( yunus.arabaAra("34 GA 002") == null )
			System.out.println("Test5 OK");
		else
			System.out.println("Test5 FAIL");
		if( yunus.arabaAra("34 GA 003") != null )
			System.out.println("Test6 OK");
		else
			System.out.println("Test6 FAIL");
		System.out.println(yunus);
		
	}

}
