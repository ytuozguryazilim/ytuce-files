package ndk06;

public class GalericiInsan extends Insan {
	private String galeriAdi;
	private Araba[] arabalar;
	private int arabaSayisi;

	public GalericiInsan( String isim ) { 
		super( isim );
		arabaSayisi = 0;
		arabalar = new Araba[4];
	}

	public String getGaleriAdi() { return galeriAdi; }
	public void setGaleriAdi(String galeriAdi) { this.galeriAdi = galeriAdi; }
	public String toString( ) {
		String tanitim = super.toString();
		tanitim += "\n�stelik " + galeriAdi + " adl� bir araba galerim var.";
		tanitim += "\nGalerimde " + arabaSayisi + " adet araba var.";
		return tanitim;
	}
	
	public boolean arabaEkle( Araba araba ) {
		if( arabaAra(araba.getPlaka()) != null )
			return false;
		if( arabaSayisi < arabalar.length ) {
			arabalar[ arabaSayisi ] = araba;
			arabaSayisi++;
			return true;
		}
		else
			return false;
	}
	public boolean arabaVarMi( Araba araba ) {
		for( int i=0; i<arabalar.length; i++ )
			if( arabalar[i] == araba )
				return true;
		return false;
	}
	public Araba arabaAra( String plaka ) {
		for( int i=0; i<arabaSayisi; i++ )
			if( arabalar[i].getPlaka().equalsIgnoreCase(plaka) )
				return arabalar[i];
		return null;
		
	}
	private int arabaBul( String plaka ) {
		for( int i=0; i<arabaSayisi; i++ )
			if( arabalar[i].getPlaka().equalsIgnoreCase(plaka) )
				return i;
		return -1;
		
	}
	public boolean arabaSat( String plaka ) {
		int yer = arabaBul(plaka);
		if( yer != -1 ) {
			for( int i=yer; i<arabaSayisi-1; i++ )
				arabalar[i] = arabalar[i+1];
			arabaSayisi--; arabalar[arabaSayisi] = null;
			return true;
		}
		return false;
	}

}
