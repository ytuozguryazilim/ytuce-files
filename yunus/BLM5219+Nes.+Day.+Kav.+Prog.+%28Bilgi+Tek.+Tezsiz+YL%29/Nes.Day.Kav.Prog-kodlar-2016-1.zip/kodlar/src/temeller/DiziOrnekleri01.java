package temeller;
import java.util.Scanner;
public class DiziOrnekleri01 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int diziBoyutu;
		System.out.print( "Dizi ka� eleman i�ersin? " );
		diziBoyutu = in.nextInt( );
		int[] dizi = new int[ diziBoyutu ];
		for( int i = 0; i < diziBoyutu; i++ ) {
			System.out.print( (i+1) + ". eleman� girin: " );
			dizi[i] = in.nextInt( );
		}
		int enKucuk = 0, enBuyuk = 0;
		for( int i = enKucuk+1; i < dizi.length; i++ ) {
			if( dizi[enKucuk] > dizi[i] ) 
				enKucuk = i;
			if( dizi[enBuyuk] < dizi[i] )
				enBuyuk = i;
		}
		System.out.println( "Dizinin en k���k eleman�: " + dizi[enKucuk] );
		System.out.println( "Dizinin en b�y�k eleman�: " + dizi[enBuyuk] );
		System.out.println("Tek say�lar: ");
		for( int i = 0; i < dizi.length; i++ )
			if( dizi[i] % 2 == 1 )
				System.out.print(dizi[i]+" ");
		System.out.println("\n�ift say�lar: ");
		for( int i = 0; i < dizi.length; i++ )
			if( dizi[i] % 2 == 0 )
				System.out.print(dizi[i]+" ");
		System.out.println("\nAsal say�lar: ");
		for( int i = 0; i < dizi.length; i++ ) {
			boolean asalMi = true;
			for( int j = 2; j <= dizi[i]/2; j++ ) {
				if( dizi[i] % j == 0 ) {
					asalMi = false; break;
				}
			}
			if( asalMi )
				System.out.print(dizi[i]+" ");
		}
		
		in.close();
	}
}
