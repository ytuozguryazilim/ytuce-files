package temeller;
import java.util.*;
public class KararVerme03 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int piyango = (int)(Math.random() * 100);
		piyango = 34;
		System.out.print("Tahmininizi girin: ");
		int tahmin = in.nextInt();
		System.out.println("�ekilen say�: " + piyango);
		int tahminBirler = tahmin % 10;
		int tahminOnlar = tahmin / 10;
		int piyangoBirler = piyango % 10;
		int piyangoOnlar = piyango / 10;
		if (tahmin == piyango)
			System.out.println("Do�ru bildiniz: �d�l�n�z 10,000TL");
		else if (tahminBirler == piyangoOnlar / 10 && tahminOnlar / 10 == piyangoBirler % 10)
			System.out.println("�ki rakam bildiniz: �d�l�n�z 3,000TL");
		else if (tahmin % 10 == piyango / 10 || tahmin % 10 == piyango % 10
				|| tahmin / 10 == piyango / 10 || tahmin / 10 == piyango % 10)
			System.out.println("Tek rakam bildiniz: �d�l�n�z 1,000TL");
		else
			System.out.println("�zg�n�m, kaybettiniz.");
		in.close();

	}

}
