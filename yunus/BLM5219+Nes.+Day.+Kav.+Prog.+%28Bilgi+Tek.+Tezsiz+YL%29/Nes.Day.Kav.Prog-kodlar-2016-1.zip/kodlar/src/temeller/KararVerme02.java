package temeller;
import java.util.*;
public class KararVerme02 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int piyango = (int)(Math.random() * 100);
		System.out.println("�ekilen say�: " + piyango);
		System.out.print("Tahmininizi girin: ");
		int tahmin = in.nextInt();
		if( tahmin > 0 && tahmin <= 99 ) { 
			if (tahmin == piyango)
				System.out.println("Do�ru bildiniz: �d�l�n�z 10,000TL");
			else if (tahmin % 10 == piyango / 10 && tahmin / 10 == piyango % 10)
				System.out.println("�ki rakam bildiniz: �d�l�n�z 3,000TL");
			else if (tahmin % 10 == piyango / 10 || tahmin % 10 == piyango % 10
					|| tahmin / 10 == piyango / 10 || tahmin / 10 == piyango % 10)
				System.out.println("Tek rakam bildiniz: �d�l�n�z 1,000TL");
			else
				System.out.println("�zg�n�m, kaybettiniz.");
		}
		else
			System.out.println("Hatal� giri� yapt�n�z");
		in.close();

	}

}
