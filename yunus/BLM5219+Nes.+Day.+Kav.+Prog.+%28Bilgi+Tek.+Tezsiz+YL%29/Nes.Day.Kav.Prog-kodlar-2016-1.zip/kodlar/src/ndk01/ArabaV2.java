package ndk01;
import java.util.Scanner;
public class ArabaV2 {
	private String plaka;

	public ArabaV2( String plakaNo ) {
		plaka = plakaNo;
	}
	public String getPlaka( ) {
		return plaka;
	}
	public void setPlaka( String plaka ) {
		this.plaka = plaka;
	}
	public void kendiniTanit( ) {
		System.out.println( "Plakam: " + getPlaka() );
	}

	public static void main( String[] args ) {
		ArabaV2 birAraba;
		Scanner input = new Scanner( System.in );
		System.out.print("Enter a license plate: ");
		String plakaNr =  input.nextLine( );
		birAraba = new ArabaV2( plakaNr );
		birAraba.kendiniTanit( );
		input.close();
	}

}
