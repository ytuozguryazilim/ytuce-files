package ndk01;

public class StringOps01 {
	   public static void main( String args[] ) {
			String strA, strB;
			strA = "A string!";
			strB = "This is another one.";
			System.out.println(strA.compareTo(strB));
		   }

}
