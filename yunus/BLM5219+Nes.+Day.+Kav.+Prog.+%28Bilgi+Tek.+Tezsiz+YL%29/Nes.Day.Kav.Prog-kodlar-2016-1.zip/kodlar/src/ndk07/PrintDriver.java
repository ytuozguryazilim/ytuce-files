package ndk07;

public abstract class PrintDriver {
	public void initSpooler( ) {
		/* necessary codes*/
	}
	public abstract void print( Document doc );
}
