package ndk07;

public class PCL6Driver extends PrintDriver {
	public void print(Document doc) {
		//necessary code is inserted here
	}
}
