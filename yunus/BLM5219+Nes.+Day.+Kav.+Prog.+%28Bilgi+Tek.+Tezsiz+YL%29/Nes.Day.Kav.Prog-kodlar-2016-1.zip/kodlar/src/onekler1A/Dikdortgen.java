package onekler1A;

import java.util.*;

public class Dikdortgen {
	private int kenarA, kenarB;

	public Dikdortgen(int kenarA, int kenarB) {
		this.kenarA = kenarA;
		this.kenarB = kenarB;
	}
	public void cizDolu() {
		for( int j=0; j<kenarA; j++ ) {
			for( int i=0; i<kenarB; i++) {
				System.out.print("* ");
			}
			System.out.println();
		}
	}
	public void cizBos() {
		for( int j=0; j<kenarA; j++ ) {
			for( int i=0; i<kenarB; i++) {
				if( j == 0 || j == kenarA-1 )
					System.out.print("* ");
				else if( i == 0 || i == kenarB-1 )
					System.out.print("* ");
				else
					System.out.print("  ");
			}
			System.out.println();
		}
	}
	public static void main( String args[] ) {
		Scanner in = new Scanner( System.in );
		System.out.print("Enter side A: ");
		int a = in.nextInt();
		System.out.print("Enter side B: ");
		int b = in.nextInt();
		Dikdortgen d = new Dikdortgen(a,b);
		System.out.println("��i bo� dikd�rtgen:");
		d.cizBos();
		System.out.println("��i dolu dikd�rtgen:");
		d.cizDolu();
		in.close();
	}
}