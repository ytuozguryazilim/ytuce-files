package onekler1A;

public class Denetlemeler {
	public static boolean denetleEMail( String eMail ) {
		if( eMail.length() < 7 )
			return false;
		int atKonum = eMail.indexOf("@");
		if( atKonum == -1 || atKonum != eMail.lastIndexOf("@") )
			return false;
		String sol = eMail.substring(0, atKonum);
		String sag = eMail.substring(atKonum+1, eMail.length());
		if( sol.length() < 1 || sag.length() < 5 || sag.indexOf(".") == -1 )
			return false;
		return true;
	}
	public static boolean denetleIP( String adres ) {
		int sayi, konum; String parca;
		adres += ".";
		for( int i = 0; i < 4; i++ ) {
			konum = adres.indexOf(".");
			if( konum == -1 )
				return false;
			parca = adres.substring(0, konum );
			adres = adres.substring(konum+1,adres.length() );
			sayi = Integer.valueOf(parca);
			if( sayi < 0 || sayi > 255 )
				return false;
		}
		return true;
	}
	public static void main( String args[] ) {
		System.out.println(denetleEMail("yunus@gmail.com"));
		System.out.println(denetleEMail("a@b.com"));
		System.out.println(denetleEMail("a@b.c"));
		System.out.println(denetleIP("123.45.67.8"));
		System.out.println(denetleIP("123.45.678.9"));
	}
}
