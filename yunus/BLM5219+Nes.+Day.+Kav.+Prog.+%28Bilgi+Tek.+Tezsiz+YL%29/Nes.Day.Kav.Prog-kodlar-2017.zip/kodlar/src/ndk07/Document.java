package ndk07;

public class Document {

}
