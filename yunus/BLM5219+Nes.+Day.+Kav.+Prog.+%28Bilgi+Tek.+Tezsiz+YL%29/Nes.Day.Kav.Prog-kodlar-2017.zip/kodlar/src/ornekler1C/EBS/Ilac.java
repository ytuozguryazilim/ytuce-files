package ornekler1C.EBS;

public class Ilac {
	private String isim;
	public Ilac( String isim ) {
		this.isim = isim;
	}
	public String getIsim() {
		return isim;
	}
}
