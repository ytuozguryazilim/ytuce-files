package ornekler1C.EBS;

public class EBS {
	private Recete onayliReceteler[];
	private int receteSayisi, maxRecete;
	
	public EBS( ) {
		maxRecete = 100;
		onayliReceteler = new Recete[maxRecete];
	}
	private void diziGenislet() {
		Recete yeniReceteler[] = new Recete[maxRecete*2];
		for( int i=0; i<maxRecete; i++ )
			yeniReceteler[i] = onayliReceteler[i];
		onayliReceteler = yeniReceteler;
		maxRecete *= 2;
	}
	public Recete receteAra( String receteNo ) {
		for( Recete recete : onayliReceteler )
			if( recete.getReceteNo().equalsIgnoreCase(receteNo) )
				return recete;
		return null;
	}
	public boolean denetle( Recete recete ) {
		if( receteAra( recete.getReceteNo() ) == recete )
			return true;
		return false;
	}
	public void receteEkle( Recete recete ) {
		if( receteSayisi == maxRecete )
			diziGenislet();
		if( denetle(recete) )
			return;
		onayliReceteler[receteSayisi] = recete;
		receteSayisi++;
	}
}
