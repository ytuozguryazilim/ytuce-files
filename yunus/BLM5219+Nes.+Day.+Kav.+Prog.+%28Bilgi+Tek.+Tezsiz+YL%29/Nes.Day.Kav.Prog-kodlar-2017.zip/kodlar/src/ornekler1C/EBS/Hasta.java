package ornekler1C.EBS;

public class Hasta extends Insan implements ProtokolSahibi {
	private int protokolNo;

	public Hasta(String ad, String soyad, long TCkimlik, int protNo) {
		super(ad, soyad, TCkimlik);
		protokolNo = protNo;
	}
	public int getProtokolNo() {
		return protokolNo;
	}

}
