package ornekler1C.EBS;

public interface ProtokolSahibi {
	public int getProtokolNo();
}
