package ornekler1B;
public class AsalDizi {
	public static void asalListele( int[] sayilar ) {
		for( int i=0; i<sayilar.length; i++ ) {
			boolean isPrime = true;
			for( int j=2; j<=sayilar[i]/2; j++ ) {
				if( sayilar[i] % j == 0 ) {
					isPrime = false; break;
				}
			}
			if( isPrime )
				System.out.print(sayilar[i]+" ");
		}
	}
	public static void main(String[] args) {
		int dizi[] = { 4, 19, 45, 17, 60 };
		asalListele( dizi );
	}
}
