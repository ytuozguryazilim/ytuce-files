package ornekler1B;
import java.util.*;
public class KareToplamlar {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("Bir tamsay� giriniz: ");
		int sayi = giris.nextInt();
		System.out.println(sayi+" say�s�n�n kare toplam� a��l�mlar�:");
		for( int i=0; i<=sayi/2; i++ )
		      for( int j=0; j<=sayi/2; j++ )
		        if( i*i + j*j == sayi )
		           System.out.println( i+"*"+i+"+"+j+"*"+j );
		giris.close();
	}
}
