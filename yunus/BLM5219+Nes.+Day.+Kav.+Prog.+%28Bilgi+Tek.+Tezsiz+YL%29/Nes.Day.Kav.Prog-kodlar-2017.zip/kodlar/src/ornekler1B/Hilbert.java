package ornekler1B;
import java.util.*;
public class Hilbert {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("Bir tamsay� giriniz: ");
		int sayi = giris.nextInt();
		if( sayi % 4 == 1 ) {
			System.out.println("Bu bir Hilbert say�s�d�r.");
		}
		else {
			System.out.println("Bu bir Hilbert say�s� de�ildir.");
		}
		giris.close();
	}
}
