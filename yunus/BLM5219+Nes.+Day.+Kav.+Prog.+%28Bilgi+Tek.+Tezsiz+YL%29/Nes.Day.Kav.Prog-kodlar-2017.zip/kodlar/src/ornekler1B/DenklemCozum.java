package ornekler1B;
import java.util.*;
public class DenklemCozum {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.println("�kinci derece denklem ��z�c�.");
		System.out.print("a katsay�s�n� girin: ");
		int a = giris.nextInt( );
		System.out.print("b katsay�s�n� girin: ");
		int b = giris.nextInt( );
		System.out.print("c katsay�s�n� girin: ");
		int c= giris.nextInt( );
		double delta = b*b - 4*a*c;
		if( delta > 0 ) {
			double x1 = (-b+Math.sqrt(delta))/(2*a);
			double x2 = (-b-Math.sqrt(delta))/(2*a);
			System.out.println("�ki k�k mevcut: " + x1 + " ve " + x2);
		}
		else if( delta == 0 ) {
			double x = (-b+Math.sqrt(delta))/(2*a);
			System.out.println("Bir k�k mevcut: " + x);
		}
		else
			System.out.println("Ger�ek say� k�k yoktur.");
		giris.close();
	}
}
