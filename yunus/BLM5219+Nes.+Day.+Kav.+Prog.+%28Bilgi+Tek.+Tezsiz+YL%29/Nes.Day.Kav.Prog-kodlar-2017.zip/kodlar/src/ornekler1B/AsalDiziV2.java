package ornekler1B;
public class AsalDiziV2 {
	public static void asalListele( int[] sayilar ) {
		for( int i=0; i<sayilar.length; i++ ) {
			if( asalMi(sayilar[i]) )
				System.out.print(sayilar[i]+" ");
		}
	}
	public static boolean asalMi( int sayi ) {
		for( int i=2; i<=sayi/2; i++ ) {
			if( sayi % i == 0 ) {
				return false;
			}
		}
		return true;
	}
	public static void main(String[] args) {
		int dizi[] = { 4, 19, 45, 17, 60 };
		asalListele( dizi );
	}
}
