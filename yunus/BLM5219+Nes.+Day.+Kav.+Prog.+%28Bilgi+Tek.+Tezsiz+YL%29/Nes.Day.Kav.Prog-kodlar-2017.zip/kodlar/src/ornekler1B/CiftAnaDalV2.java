package ornekler1B;
import java.util.*;
public class CiftAnaDalV2 {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("��rencinin not ortalamas�n� girin: ");
		double notOrt = giris.nextDouble();
		System.out.print("��rencinin d�nemini girin: ");
		int donem = giris.nextInt();
		if( notOrt >= 2.75 && donem >= 3 && donem <= 5 ) {
				System.out.println("��renci �AP yapabilir.");
		}
		else {
			System.out.println("��renci �AP yapamaz.");
			System.out.println("En az bir gereksinim kar��lanm�yor.");
		}
		giris.close();
	}
}
