package ornekler1B;
import java.util.*;
public class Fahrenheit2Kelvin {
	public static void main(String args[]) {
		Scanner giris = new Scanner(System.in);
		System.out.print("Fahrenheit cinsinden bir de�er giriniz: ");
		double fahrenheit = giris.nextDouble();
		double kelvin = ((fahrenheit-32)/1.8)+273.15;
		System.out.println("Kelvin kar��l���: " + kelvin);
		giris.close();
	}
}
