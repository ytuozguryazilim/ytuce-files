package ndk02;

public class Araba {
	   private String plaka;
	   
	   public Araba( String plakaNo ) {
		   plaka = plakaNo;
	   }
	   public String getPlaka( ) {
	      return plaka;
	   }
}
