package ndk01;
public class Araba {
	private String plaka;

	public Araba( String plakaNo ) {
		plaka = plakaNo;
	}
	public String getPlaka( ) {
		return plaka;
	}
	public void setPlaka( String plaka ) {
		this.plaka = plaka;
	}
	public void kendiniTanit( ) {
		System.out.println( "Plakam: " + getPlaka() );
	}

	public static void main( String[] args ) {
		Araba birAraba;
		birAraba = new Araba( "34 RA 440" );
		birAraba.kendiniTanit( );
		birAraba.setPlaka("34 PL 123");
		birAraba.kendiniTanit( );
		Araba digerAraba = new Araba("06 AN 456");
		digerAraba.kendiniTanit();
		birAraba = new Araba ("34 �S 345");
		birAraba.kendiniTanit();
		birAraba = digerAraba;
	}

}
