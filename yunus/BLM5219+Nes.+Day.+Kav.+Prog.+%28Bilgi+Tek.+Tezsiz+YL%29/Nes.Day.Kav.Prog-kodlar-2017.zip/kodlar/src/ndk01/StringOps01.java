package ndk01;

public class StringOps01 {
	   public static void main( String args[] ) {
			String strA, strB;
			strA = "A String!";
			strB = "a String!";
			System.out.println(strA.compareTo(strB));
	   }

}
