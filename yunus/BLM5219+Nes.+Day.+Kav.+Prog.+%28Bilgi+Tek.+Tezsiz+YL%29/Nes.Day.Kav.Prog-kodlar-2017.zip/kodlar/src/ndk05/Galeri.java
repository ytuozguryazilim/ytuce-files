package ndk05;

public class Galeri {
	private Insan galeriSahibi;
	private String galeriAdi;
	private Araba[] arabalar;
	private int arabaSayisi;

	public Galeri( String galeriAd, Insan sahip ) { 
		galeriAdi = galeriAd; galeriSahibi = sahip;
		arabaSayisi = 0;
		arabalar = new Araba[30]; 
		// 30 umar�m yeterince b�y�kt�r? Dizi kapasite sorunlar�n� vurgula.
	}

	public String getGaleriAdi() { return galeriAdi; }
	public void setGaleriAdi(String galeriAdi) { this.galeriAdi = galeriAdi; }
	public String kendiniTanit( ) {
		String tanitim;
		tanitim = galeriAdi + " adl� galerinin sahibi: " + galeriSahibi.getIsim();
		tanitim += "\nGaleride " + arabaSayisi + " adet araba var.";
		return tanitim;
	}
	public boolean arabaEkle( Araba araba ) {
		if( arabaAra(araba.getPlaka()) != null )
			return false;
		if( arabaSayisi < arabalar.length ) {
			arabalar[ arabaSayisi ] = araba;
			arabaSayisi++;
			return true;
		}
		else
			return false;
	}
	public Araba arabaAra( String plaka ) {
		for( int i=0; i<arabaSayisi; i++ )
			if( arabalar[i].getPlaka().equalsIgnoreCase(plaka) )
				return arabalar[i];
		return null;
	}
	private int arabaBul( String plaka ) {
		for( int i=0; i<arabaSayisi; i++ )
			if( arabalar[i].getPlaka().equalsIgnoreCase(plaka) )
				return i;
		return -1;
		
	}
	public boolean arabaSat( String plaka ) {
		/* Asl�nda daha �ok arabaSil gibi.
		 * Sat�� i�in mali konular devreye girer. 
		 * �dev olarak yapar m�s�n�z? */
		int yer = arabaBul(plaka);
		if( yer != -1 ) {
			for( int i=yer; i<arabaSayisi-1; i++ )
				arabalar[i] = arabalar[i+1];
			arabaSayisi--; arabalar[arabaSayisi] = null;
			return true;
		}
		return false;
	}

}
