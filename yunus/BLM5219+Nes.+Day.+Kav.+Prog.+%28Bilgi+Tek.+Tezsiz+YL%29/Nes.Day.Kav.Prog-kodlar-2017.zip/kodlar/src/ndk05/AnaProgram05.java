package ndk05;

public class AnaProgram05 {

	public static void main(String[] args) {
		Insan insan = new Insan("Yunus Zengin");
		Galeri galeri = new Galeri("Yunus Oto", insan);
		Araba honda = new Araba("34 GH 001");
		boolean sonuc = galeri.arabaEkle(honda);
		if( sonuc )
			System.out.println("Test1 OK");
		else
			System.out.println("Test1 FAIL");
		sonuc = galeri.arabaEkle(honda);
		if( !sonuc )
			System.out.println("Test2 OK");
		else
			System.out.println("Test2 FAIL");
		galeri.arabaEkle( new Araba("34 GA 002") );
		galeri.arabaEkle( new Araba("34 GA 003") );
		galeri.arabaEkle( new Araba("34 GA 004") );
		if( galeri.arabaAra("34 GA 003") != null )
			System.out.println("Test3 OK");
		else
			System.out.println("Test3 FAIL");
		if( galeri.arabaSat("34 GA 002") )
			System.out.println("Test4 OK");
		else
			System.out.println("Test4 FAIL");
		if( galeri.arabaAra("34 GA 002") == null )
			System.out.println("Test5 OK");
		else
			System.out.println("Test5 FAIL");
		if( galeri.arabaAra("34 GA 003") != null )
			System.out.println("Test6 OK");
		else
			System.out.println("Test6 FAIL");
		System.out.println(galeri);
		
	}

}
