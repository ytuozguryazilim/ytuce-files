package temeller;
import java.util.*;
public class KararVerme01 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("�lkedeki yeti�kinlik ya�� s�n�r�n� girin: ");
		int sinir = in.nextInt();
		System.out.print("Ki�inin ya��n� girin: ");
		int yas = in.nextInt();
		if( yas >= sinir )
			System.out.println("Ki�i kanunen bir yeti�kindir.");
		else
			System.out.println("Ki�i hen�z re�it de�ildir.");
		in.close();
	}
}
