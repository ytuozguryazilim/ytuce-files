package temeller;
import java.util.*;
public class Donguler01For {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.print("Asall��� s�nanacak say�y� girin: ");
		int N = in.nextInt();
		boolean asal = true;
		for( int i=2; i<=N/2; i++ ){
			if( N % i == 0 ) {
				asal = false;
				break;
			}
		}
		if( N !=0 && N !=1 && asal ) 
			System.out.println("Girilen say� asald�r.");
		else
			System.out.println("Girilen say� asal de�ildir.");
		in.close();
	}

}
