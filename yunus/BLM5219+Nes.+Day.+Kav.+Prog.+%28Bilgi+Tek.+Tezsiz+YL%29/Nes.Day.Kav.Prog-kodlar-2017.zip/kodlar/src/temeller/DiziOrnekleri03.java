package temeller;
import java.util.Arrays;
import java.util.Scanner;
public class DiziOrnekleri03 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int diziBoyutu;
		System.out.print( "Dizi ka� eleman i�ersin? " );
		diziBoyutu = in.nextInt( );
		int[] dizi = new int[ diziBoyutu ];
		for( int i = 0; i < diziBoyutu; i++ ) {
			System.out.print( (i+1) + ". eleman� girin: " );
			dizi[i] = in.nextInt( );
		}
		Arrays.sort(dizi);
		System.out.print( "S�ralanm�� dizi: " );
		for( int eleman: dizi )
			System.out.print( eleman + " " );
		System.out.println();
		char c; int aranan, bas, son, orta, yer;
		do {
			System.out.print("Aramak istedi�iniz eleman� girin: ");
			aranan = in.nextInt();

			bas = 0; son = dizi.length-1; yer = -1;
			while( bas <= son ) {
				orta = ( bas + son ) / 2;
				System.out.print(" bas: " + bas);
				System.out.print(" son: " + son);
				System.out.print(" orta: " + orta);
				System.out.println(" dizi[orta]: " + dizi[orta]);
				if( dizi[orta] == aranan ) {
					yer = orta; break;
				}
				else {
					if( dizi[orta] < aranan )
						bas = orta + 1;
					else
						son = orta - 1;
				}
			}
			if( yer != -1 )
				System.out.println("Aranan de�er " + (yer+1) + ". s�rada bulundu.");
			else
				System.out.println("Aranan de�er bulunamad�.");
			System.out.print("Devam etmek istiyor musunuz (e/h)? ");
			in.nextLine();
			c = in.nextLine().charAt(0);
		} while( c == 'E' || c == 'e');
		in.close();
	}
}
