package temeller;
import java.util.*;
public class Donguler02While3 {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Girilen say�lar�n karek�klerini hesaplayan");
		System.out.println("bu programdan ��kmak i�in 0 girebilirsiniz.");
		double deger;
		System.out.print("Bir say� girin: ");
		deger = in.nextDouble();
		while( deger != 0 ) {
			if( deger > 0 )
				System.out.println("Karek�k�: " + Math.sqrt(deger) );
			else
				System.out.println("Negatif say�lar�n karek�k� hesaplanamaz.");
			System.out.print("Bir say� girin: ");
			deger = in.nextDouble();
		}
		in.close();
	}

}
