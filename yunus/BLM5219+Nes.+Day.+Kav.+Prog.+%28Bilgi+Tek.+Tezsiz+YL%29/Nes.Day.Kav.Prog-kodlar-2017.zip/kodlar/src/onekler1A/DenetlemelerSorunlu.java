package onekler1A;

public class DenetlemelerSorunlu {
	
	public static boolean denetleISBN( String isbn ) {
		if( isbn.length() != 10 )
			return false;
		int sinama = 0;
		System.out.println(sinama);
		for( int i = 0; i < isbn.length(); i++ ){ 
			sinama += (10 - i ) * Integer.valueOf( isbn.charAt(i) );
			System.out.print((10 - i ));
			System.out.print(" * ");
			System.out.print(Integer.valueOf( isbn.charAt(i) ));
			System.out.print(" ��nk� " + isbn.charAt(i) );
			System.out.println();
			/*G�r�yorum ki hep 48 fazlas�n� veriyor. Neden ki?*/
		}
		System.out.println(sinama);
		sinama = (11 - sinama) % 11;
		System.out.println(sinama);
		char dogru;
		if( sinama == 10 )
			dogru = 'x';
		else
			dogru = Integer.toString(sinama).toUpperCase().charAt(0);
		if( dogru == isbn.charAt(isbn.toUpperCase().length()-1) )
			return true;
		return false;
	}
	public static void main( String args[] ) {
		String dogruISBN = "9519854894";
		System.out.println(denetleISBN(dogruISBN));
	}
}
