package ndk04;

public class AnaProgram04 {

	public static void main(String[] args) {
		Insan oktay = new Insan("Oktay Sinano�lu");
		Araba rover = new Araba("06 OS 1934");
		//oktay.setAraba(rover);
		rover.setSahip(oktay);
		System.out.println( oktay.kendiniTanit() );
		System.out.println( rover.kendiniTanit() );

		Insan serkan = new Insan("Serkan An�l�r");
		Araba honda = new Araba("34 JAXA 73");
		serkan.setAraba(honda);
		//honda.setSahip(serkan);
		System.out.println( serkan.kendiniTanit() );
		System.out.println( honda.kendiniTanit() );
	}

}
