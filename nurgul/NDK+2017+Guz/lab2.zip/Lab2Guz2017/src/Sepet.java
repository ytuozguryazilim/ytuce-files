public class Sepet {
	private String sepetSahibi;
	private Urun[] urunler;
	private int sayac_urun;
	private final static int MAX_URUN = 5;

	public Sepet(String sepetSahibi) {
		this.sepetSahibi = sepetSahibi;
		sayac_urun = 0;
		urunler = new Urun[MAX_URUN];
	}

	public String getSepetSahibi() {
		return sepetSahibi;
	}

	public void setSepetSahibi(String sepetSahibi) {
		this.sepetSahibi = sepetSahibi;
	}

	public int getSayac_urun() {
		return sayac_urun;
	}

	public void ekleUrun(Urun urun) {
		if (sayac_urun < MAX_URUN) {// bolum kotasi yeterli mi
			// doner
			if (!araUrun(urun)) {
				urun.setSepet(this);
				urunler[sayac_urun] = urun;
				sayac_urun++;
				System.out.println("Urun eklendi");
				// }
				// else {
				// System.out.println("Bolum baska bir bolum altinda tanimlanmis.");
				// }
			} else {
				System.out.println("Urun zaten var");
			}
		} else {
			System.out.println("Urun eklenemedi. Sepet kotasi yeterli degil.");
		}
	}

	public boolean araUrun(Urun urun) {
		for (Urun urun1 : urunler)
			if (urun1 == urun)
				return true;
		return false;
	}

	public void silUrun(Urun urun) {
		for (int i = 0; i < sayac_urun; i++) {
			if (urunler[i].getBarkod() == urun.getBarkod()) {
				// Bolum xbolum = bolumler[i];
				for (int j = i; j < sayac_urun; j++)
					urunler[j] = urunler[j + 1];
				urunler[sayac_urun] = null;
				sayac_urun--;
				System.out.println("Urun silindi");
			}
		}

	}

	public double hesaplaTutar() {
		double tutar = 0;
		for (int i = 0; i < sayac_urun; i++) {
			tutar += urunler[i].getFiyat();
		}

		if (tutar > 1000) {
			//tutar = yapIndirim(tutar);
			tutar*=0.8;
		}
		return tutar;
	}

	/*public double yapIndirim(double toplamTutar) {
		return toplamTutar * 0.8;
	}*/

	public double hesaplaToplamKDV() {
		double kdv_toplam = 0;
		for (int i = 0; i < sayac_urun; i++) {
			kdv_toplam += urunler[i].hesaplaKDV();
		}
		return kdv_toplam;
	}

	@Override
	public String toString() {
		return "Sepet [sepetSahibi=" + sepetSahibi + ", urun adedi="
				+ sayac_urun + ", Toplam Tutar()=" + hesaplaTutar()
				+ ", Toplam KDV()=" + hesaplaToplamKDV() + "]";
	}
	
	
}
