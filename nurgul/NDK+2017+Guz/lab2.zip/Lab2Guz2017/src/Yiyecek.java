public class Yiyecek extends Urun {
	private int tuketimSuresi;

	public Yiyecek(String ad, int barkod, double fiyat, double kdv_Oran,
			int tuketimSuresi) {
		super(ad, barkod, fiyat, kdv_Oran);
		this.tuketimSuresi = tuketimSuresi;
	}

	public int getTuketimSuresi() {
		return tuketimSuresi;
	}

	public String toString() {
		return "Yiyecek [tuketimSuresi=" + tuketimSuresi + ", ad=" + ad
				+ ", barkod=" + barkod + ", fiyat=" + fiyat + ", KDV_ORAN="
				+ KDV_ORAN + ", getTuketimSuresi()=" + getTuketimSuresi()
				+ ", hesaplaKDV()=" + hesaplaKDV() + "]";
	}

}
