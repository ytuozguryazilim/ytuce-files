
public class Test {

	public static void main(String[] args) {
		Sepet sepet1=new Sepet("Sepet1");
		
		Urun u1=new Urun("Gomlek",1,100,0.08);
		System.out.println(u1.hesaplaKDV());
		System.out.println(u1.toString());
		
		Urun u2=new Urun("Etek",4,100,0.08);
		Urun u3=new Urun("Mont",1,300,0.08);
		Urun u4=new Urun("Bot",1,200,0.08);
		
		ElektronikUrun e1=new ElektronikUrun("Cep telefonu", 2, 1000,0.18, 5);
		System.out.println(e1.hesaplaKDV());
		System.out.println(e1.toString());
		e1.uzatGarantiSuresi(2);
		System.out.println(e1.toString());
		
		
		Yiyecek y1=new Yiyecek("Et",2, 50, 0.01, 100);
		System.out.println(y1.hesaplaKDV());
		System.out.println(y1.toString());
		
		
		sepet1.ekleUrun(u1);
		sepet1.ekleUrun(e1);
		sepet1.ekleUrun(y1);
		System.out.println(sepet1.hesaplaTutar());
		System.out.println(sepet1.hesaplaToplamKDV());
		System.out.println(sepet1.toString());
	
		
		System.out.println(e1.getSepet().getSepetSahibi());
		sepet1.silUrun(e1);
		System.out.println(sepet1.toString());
		
		
	}

}
