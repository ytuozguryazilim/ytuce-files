public class ElektronikUrun extends Urun {
	private int garantiSuresi;

	public ElektronikUrun(String ad, int barkod, double fiyat, double kdvOran,
			int garantiSuresi) {
		super(ad, barkod, fiyat, kdvOran);
		this.garantiSuresi = garantiSuresi;
	}

	public int getGarantiSuresi() {
		return garantiSuresi;
	}

	public void uzatGarantiSuresi(int yil) {
		garantiSuresi += garantiSuresi + yil;
		fiyat += yil * 100;
	}

	public String toString() {
		return "ElektronikUrun [garantiSuresi=" + garantiSuresi + ", ad=" + ad
				+ ", barkod=" + barkod + ", fiyat=" + fiyat + ", KDV_ORAN="
				+ KDV_ORAN + ", hesaplaKDV()=" + hesaplaKDV() + "]";
	}

}
