public class Urun {
	protected String ad;
	protected int barkod;
	protected double fiyat;
	protected double KDV_ORAN;
	private Sepet sepet;

	public Urun(String ad, int barkod, double fiyat, double kdvOran) {
		this.ad = ad;
		this.barkod = barkod;
		this.fiyat = fiyat;
		KDV_ORAN = kdvOran;

	}

	public double getKdvOran() {
		return KDV_ORAN;
	}

	public void setKdvOran(double kdvOran) {
		KDV_ORAN = kdvOran;
	}

	public String getAd() {
		return ad;
	}

	public void setAd(String ad) {
		this.ad = ad;
	}

	public int getBarkod() {
		return barkod;
	}

	public void setBarkod(int barkod) {
		this.barkod = barkod;
	}

	public double getFiyat() {
		return fiyat;
	}

	public void setFiyat(double fiyat) {
		this.fiyat = fiyat;
	}
	
	public Sepet getSepet() {
		return sepet;
	}

	public void setSepet(Sepet sepet) {
		this.sepet = sepet;
	}

	public double hesaplaKDV() {
		double kdv = getFiyat() * getKdvOran();
		return kdv;
	}

	public String toString() {
		return "Urun [ad=" + ad + ", barkod=" + barkod + ", fiyat=" + fiyat
				+ ", KDV_ORAN=" + KDV_ORAN + ", hesaplaKDV()=" + hesaplaKDV()
				+"]";
	}

}
