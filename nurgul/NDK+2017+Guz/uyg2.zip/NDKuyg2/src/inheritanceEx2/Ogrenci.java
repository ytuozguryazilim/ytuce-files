package inheritanceEx2;

public class Ogrenci extends Kisi {
	// kisi_adi ve bolum degiskeni ust siniftan gelir
	private int ogrenci_No;
	private Ders[] dersler;
	private int sayac_ders;
	private final static int MAX_DERS = 10;

	public Ogrenci(String ad, int ogrenci_No) {
		super(ad);
		this.ogrenci_No = ogrenci_No;
		sayac_ders = 0;
		dersler = new Ders[MAX_DERS];
	}

	public int getOgrenci_No() {
		return ogrenci_No;
	}

	public void setOgrenci_No(int ogrenci_No) {
		this.ogrenci_No = ogrenci_No;
	}

	public int getSayac_ders() {
		return sayac_ders;
	}

	public void ekleDers(Ders ders) {
		if (!araDers(ders)) {// bolum varsa araBolum(bolum) metodundan true
								// doner
			if (sayac_ders < MAX_DERS) {
				dersler[sayac_ders] = ders;
				sayac_ders++;
				System.out.println("Ders eklendi");
			} else {
				System.out.println("Ders eklenemedi. Ders kotasi a�ildi.");
			}
		} else {
			System.out.println("ders zaten var");
		}

	}

	public boolean araDers(Ders ders) {
		// buradaki for dongusunun kullanimina dikkat
		for (Ders ders1 : dersler)
			if (ders1 == ders)
				return true;
		return false;
	}

	public void silDers(Ders ders) {
		for (int i = 0; i < sayac_ders; i++) {
			if (dersler[i].getDers_kodu() == ders.getDers_kodu()) {
				for (int j = i; j < sayac_ders; j++)
					dersler[j] = dersler[j + 1];
				dersler[sayac_ders] = null;
				sayac_ders--;
				System.out.println("ders silindi");
			}
		}
	}

	
	public void yazdir_bilgileri() {
		String info = "Ogrenci [Ogrenci=" + getKisi_Ad() + ", ders sayisi="
				+ sayac_ders + ", Bolum=" + getBolum().getBolum_ad() + ",ders sayisi="+sayac_ders+"]";
		System.out.println(info);
		System.out.println("Aldigi dersleri:");
		for (int i = 0; i < sayac_ders; i++)
			System.out.println(dersler[i].getDers_adi());

	}

}
