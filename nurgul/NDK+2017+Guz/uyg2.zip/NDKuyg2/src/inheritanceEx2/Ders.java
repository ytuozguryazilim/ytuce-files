package inheritanceEx2;

public class Ders {

	private int ders_kodu;
	private String ders_adi;

	public Ders(int ders_kodu, String ders_adi) {
		this.ders_kodu = ders_kodu;
		this.ders_adi = ders_adi;
	}

	public int getDers_kodu() {
		return ders_kodu;
	}

	public void setDers_kodu(int ders_kodu) {
		this.ders_kodu = ders_kodu;
	}

	public String getDers_adi() {
		return ders_adi;
	}

	public void setDers_adi(String ders_adi) {
		this.ders_adi = ders_adi;
	}

}
