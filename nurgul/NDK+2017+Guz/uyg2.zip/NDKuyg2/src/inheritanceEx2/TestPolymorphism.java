package inheritanceEx2;

public class TestPolymorphism {
	public static void main(String args[]){
		Kisi kisi1=new Kisi("Demet");
		
		Ogrenci ogr1=new Ogrenci("Destan", 3);
		
		kisi1.yazdir_bilgileri();
		ogr1.yazdir_bilgileri();
		
	}

}
