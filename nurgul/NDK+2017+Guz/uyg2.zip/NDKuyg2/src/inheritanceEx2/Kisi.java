package inheritanceEx2;

public class Kisi {
	private String kisi_ad;
	private Bolum bolum;

	public Kisi(String ad) {
		kisi_ad = ad;
	}

	public String getKisi_Ad() {
		return kisi_ad;
	}

	public Bolum getBolum() {
		return bolum;
	}

	public void setBolum(Bolum bolum) {
		this.bolum = bolum;
	}

	public void yazdir_bilgileri() {
		String info = "Kisi [Kisi=" + getKisi_Ad() + ", Bolum=" + getBolum()
				+ "]";
		System.out.println(info);
	}

}
