package inheritanceEx2;

public class Bolum {
	private String bolum_ad;
	private Fakulte fakulte;
	private Ogrenci[] ogrenciler;
	private int bolum_kod;
	private int sayac_ogrenci;
	private final static int MAX_OGRENCI = 50;

	public Bolum(String bolum_ad, int bolum_kod) {
		this.bolum_ad = bolum_ad;
		this.bolum_kod = bolum_kod;
		sayac_ogrenci = 0;
		ogrenciler = new Ogrenci[MAX_OGRENCI];
	}
	public void setFakulte(Fakulte f){
		fakulte=f;
	}
	
	public String getBolum_ad() {
		return bolum_ad;
	}

	public void setBolum_ad(String bolum_ad) {
		this.bolum_ad = bolum_ad;
	}

	public int getBolum_kod() {
		return bolum_kod;
	}

	public void setBolum_kod(int bolum_kod) {
		this.bolum_kod = bolum_kod;
	}

	public int getSayac_ogrenci() {
		return sayac_ogrenci;
	}

	public void ekleOgrenci(Ogrenci ogrenci) {
		if (!araOgrenci(ogrenci)) {// bolum varsa araBolum(bolum) metodundan
									// true
									// doner
			if (sayac_ogrenci < MAX_OGRENCI) {
				ogrenci.setBolum(this);
				ogrenciler[sayac_ogrenci] = ogrenci;
				sayac_ogrenci++;
				
				System.out.println("ogrenci eklendi");
			} else {
				System.out.println("ogrenci eklenemedi. ogrencikotasi asildi.");
			}
		} else {
			System.out.println("ogrenci zaten var");
		}

	}

	public boolean araOgrenci(Ogrenci ogrenci) {
		for (Ogrenci ogrenci1 : ogrenciler)
			if (ogrenci1 == ogrenci)
				return true;
		return false;
	}

	public void silOgrenci(Ogrenci ogrenci) {
		for (int i = 0; i < sayac_ogrenci; i++) {
			if (ogrenciler[i].getOgrenci_No() == ogrenci.getOgrenci_No()) {
				// Bolum xbolum = bolumler[i];
				for (int j = i; j < sayac_ogrenci; j++)
					ogrenciler[j] = ogrenciler[j + 1];
				ogrenciler[sayac_ogrenci] = null;
				sayac_ogrenci--;
				System.out.println("ogrenci silindi");
			}
		}

	}

	@Override
	public String toString() {
		return "Bolum [Bolum_Adi=" + bolum_ad + ", ogrenci sayisi="
				+ sayac_ogrenci + "]";
	}

}
