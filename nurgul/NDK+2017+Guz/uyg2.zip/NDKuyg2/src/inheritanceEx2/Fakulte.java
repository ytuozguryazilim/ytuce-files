package inheritanceEx2;

public class Fakulte {

	private String fakulte_Adi;
	
	private Bolum bolumler[];
	
	private int sayac_bolum;
	
	private final static int MAX_BOLUM = 5;

	public Fakulte(String fakulte_Adi) {
		this.fakulte_Adi = fakulte_Adi;
		sayac_bolum = 0;
		bolumler = new Bolum[MAX_BOLUM];
	}

	public String getFakulte_Adi() {
		return fakulte_Adi;
	}

	public void setFakulte_Adi(String fakulte_Adi) {
		this.fakulte_Adi = fakulte_Adi;
	}

	public int getSayac_bolum() {
		return sayac_bolum;
	}

	public void ekleBolum(Bolum bolum) {
		if (sayac_bolum < MAX_BOLUM) {// bolum kotasi yeterli mi
			// doner
			if (!araBolum(bolum)) {// bu bolumu daha once eklemediysem
				bolum.setFakulte(this);
				bolumler[sayac_bolum] = bolum;
				sayac_bolum++;
				System.out.println("Bolum eklendi");
				// }
				// else {
				// System.out.println("Bolum baska bir bolum altinda tanimlanmis.");
				// }
			} else {
				System.out.println("Bolum zaten var");
			}
		} else {
			System.out.println("Bolum eklenemedi. Bolum kotasi yeterli degil.");
		}
	}

	public boolean araBolum(Bolum bolum) {
		for (Bolum bolum1 : bolumler)
			if (bolum1 == bolum)
				return true;
		return false;
	}

	public void silBolum(Bolum bolum) {
		for (int i = 0; i < sayac_bolum; i++) {
			if (bolumler[i].getBolum_kod() == bolum.getBolum_kod()) {
				// Bolum xbolum = bolumler[i];
				for (int j = i; j < sayac_bolum; j++)
					bolumler[j] = bolumler[j + 1];
				bolumler[sayac_bolum] = null;
				sayac_bolum--;
				System.out.println("Bolum silindi");
			}
		}

	}

	@Override
	public String toString() {
		return "Fakulte [fakulte_Adi=" + fakulte_Adi + ", bolum sayisi="
				+ sayac_bolum + "]" + " ,ogrenciSayisi=" + getOgrenciSayisi();
	}

	public int getOgrenciSayisi() {
		int toplam_ogr = 0;
		for (int i = 0; i < sayac_bolum; i++) {
			toplam_ogr += bolumler[i].getSayac_ogrenci();
		}

		return toplam_ogr;
	}

}
