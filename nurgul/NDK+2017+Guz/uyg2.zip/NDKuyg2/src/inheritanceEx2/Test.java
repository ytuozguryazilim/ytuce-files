package inheritanceEx2;

public class Test {
public static void main(String args[]){
	Fakulte f1=new Fakulte("EEF");
	Fakulte f2=new Fakulte("Insaat");
	
	Bolum b1=new Bolum("Bilgisayar", 1);
	Bolum b2=new Bolum("Elektrik", 2);
	Bolum b3=new Bolum("Haberlesme", 3);
	
	Ders d1=new Ders(1, "BBG");
	Ders d2=new Ders(1, "Analiz");
	
	Kisi k1=new Kisi("Sila");
	
	Ogrenci og1=new Ogrenci("Ali", 1);
	Ogrenci og2=new Ogrenci("Veli", 2);
	Ogrenci og3=new Ogrenci("Deniz", 3);
	Ogrenci og4=new Ogrenci("Yaprak", 4);
	Ogrenci og5=new Ogrenci("Oya", 5);
	Ogrenci og6=new Ogrenci("Oya", 5);
	Ogrenci og7=new Ogrenci("Oya", 5);
	
	og1.ekleDers(d1);
	og2.ekleDers(d1);
	og2.ekleDers(d2);
	og3.ekleDers(d2);
	og4.ekleDers(d2);
	og5.ekleDers(d2);
	
	b1.ekleOgrenci(og1);
	b1.ekleOgrenci(og1);
	
	b2.ekleOgrenci(og2);
	b2.ekleOgrenci(og3);
	b2.ekleOgrenci(og4);
	b2.ekleOgrenci(og5);
	
	b3.ekleOgrenci(og6);
	b3.ekleOgrenci(og7);
	
	f1.ekleBolum(b1);
	f1.ekleBolum(b3);
	
	f2.ekleBolum(b2);
	f2.ekleBolum(b2);
	
	System.out.println(f1.toString());
	System.out.println(f2.toString());
	
	og1.yazdir_bilgileri();
	System.out.println("======================Polymorpishm Burada Incele");
	
	og2.yazdir_bilgileri();
	
	k1.yazdir_bilgileri();
	
	

}
}
