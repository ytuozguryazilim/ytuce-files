package inheritanceEx;

public class SecmeliDers extends Ders{
	private int proje;
	private int vize2;
	
	public SecmeliDers(String ad,int v1,int v2,int f,int proje){
		//super anahtarinin constructor icin kullanimi
		super(ad,v1,f);
		vize2=v2;
		this.proje=proje;
	}

	public double  hesaplaNot() {
		System.out.println("ust sinif hesapla not sonucu");
		//super anahtarinin ust sinif metod erisimi icin kullanimi
		System.out.println(super.hesaplaNot());
		System.out.println("Secmeli Ders notlari");
		
		return vize1*0.25 + vize2*0.25 + finalNot*0.30 + proje*0.2 ;
	}
	

}
