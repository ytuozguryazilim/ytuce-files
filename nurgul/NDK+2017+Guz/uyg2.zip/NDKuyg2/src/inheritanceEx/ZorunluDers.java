package inheritanceEx;

public class ZorunluDers extends Ders {
	private int vize2;
	protected int sayi=10;
	
	public ZorunluDers(String dersAdi, int vize1,int vize2, int finalNot) {
		super(dersAdi, vize1, finalNot);
		this.vize2=vize2;
		
	}

	public double hesaplaNot(){
		System.out.println("Zorunlu Ders notlari");
		return vize1*0.3 + vize2*0.3 + finalNot*0.4;
	}

	public void getUyeDegiskenler(){
		//super anahtarinin ust sinif uye degiskenine erisim icin kullanimi
		System.out.println(super.sayi);
		System.out.println(sayi);
		
	}

}
