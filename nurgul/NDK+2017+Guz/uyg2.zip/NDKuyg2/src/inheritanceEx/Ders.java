package inheritanceEx;

public class Ders {

	//protected erisim hakkini private yap dene. Neler oluyor gozlemle
	protected String dersAdi;
	protected int vize1;
	protected int finalNot;
	protected int sayi=5; 
	
	public Ders(String dersAdi,int vize1,int finalNot){
		this.dersAdi=dersAdi;
		this.vize1=vize1;
		this.finalNot=finalNot;
	}
	
	public double hesaplaNot(){
		System.out.println("Ust sinif notu:");
		return vize1*0.4 + finalNot*0.6;
	}
	
	
	

}
