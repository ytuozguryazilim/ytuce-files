package inheritanceEx;

public class TestDers {

	public static void main(String[] args) {
	
		Ders ders1=new Ders("NDK", 75, 95);
		//System.out.println(ders1.hesaplaNot());
		
		ZorunluDers bbg1=new ZorunluDers("BBG1", 80,90, 100);
		//System.out.println(bbg1.hesaplaNot());
		
		SecmeliDers sp1=new SecmeliDers("SistemProg",50, 60, 70, 80);
		System.out.println(sp1.hesaplaNot());	
		
		bbg1.getUyeDegiskenler();
		
		
		
		
		
		
		

	}

}
