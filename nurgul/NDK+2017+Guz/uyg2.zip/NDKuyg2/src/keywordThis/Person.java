package keywordThis;

//this birinci kullanim
public class Person {

	private int id;
	private String name;

	public Person(int id, String name) {
		// this anahtar sozcugunun ikinci kullanim
//dikkat. this anahtar sozcugu constructor cagirma icin kullanildiginda ilk satirda yer almali
		this(name);
		this.id = id;
	}

	public Person(String name) {
		// this birinci kullanim
		this.name = name;
	}

	public void yazdir() {
		System.out.println("id:" + id + ", name:" + name);
	}

}
