package keywordThis;

public class Aclass {

	private int i;

	public int getI() {
		return i;
	}
	public void setI(int i) {
		this.i = i;
	}
	// this anahtar sozcugunun ucuncu kullanimi
	public void method() {
		method1(this);
	}
	
	void method1(Aclass a) {
		System.out.println(a.i);
	}
}
