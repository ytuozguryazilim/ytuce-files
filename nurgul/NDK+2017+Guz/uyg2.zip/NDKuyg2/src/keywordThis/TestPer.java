package keywordThis;


public class TestPer {
	public static void main(String[] args){  
		Person per1=new Person("Nurgul");
		Person per2=new Person(1, "Deniz");
		
		per1.yazdir();
		
		per2.yazdir();
	}

}
