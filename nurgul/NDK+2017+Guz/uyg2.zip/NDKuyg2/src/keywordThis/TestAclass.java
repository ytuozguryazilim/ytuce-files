package keywordThis;

public class TestAclass {
	  public static void main(String[] args) {
	    Aclass aObj = new Aclass();
	    aObj.setI(10);
	    aObj.method();
	  }
	}
