package sonLab;

public abstract class Kisi {
	
	private String ad;
	private char cinsiyet;
	
	public Kisi(String ad,char cinsiyet){
		this.ad=ad;
		this.cinsiyet=cinsiyet;
		
	}
	public String getAd(){
		return ad;
	}
	
	public char getCinsiyet(){
		return cinsiyet;
	}
	
	public abstract String yazdirAyrintili();

}
