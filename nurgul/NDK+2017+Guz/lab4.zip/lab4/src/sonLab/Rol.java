package sonLab;

public interface Rol {
	public String getAd();
	public int getYil();

}
