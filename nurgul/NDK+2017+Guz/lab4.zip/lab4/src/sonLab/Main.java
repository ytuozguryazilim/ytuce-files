package sonLab;

public class Main {
	public static void main(String args[]){
		
		Oyuncu oyuncu1=new Oyuncu("Johnny Depp",'e');
		
		Film karayip=new Film("Karayip Korsanlari",2006);
		karayip.setImdbPuan(7.3);
		
		Film makas=new Film("Makas Eller", 1990);
		makas.setImdbPuan(7.9);
		
		Film turist=new Film("Turist", 2010);
		turist.setImdbPuan(6.0);
		
		Film pencere=new Film("Gizli Pencere", 2004);
		pencere.setImdbPuan(6.6);
		
		Film x=new Film("x", 2004);
		x.setImdbPuan(3);
		
		
		oyuncu1.ekleFilm(karayip);
		oyuncu1.ekleFilm(makas);
		oyuncu1.ekleFilm(turist);
		
		
		System.out.println(oyuncu1.yazdirAyrintili());
		
		oyuncu1.arttirFilmKapasite(5);
		
		oyuncu1.ekleFilm(pencere);
		oyuncu1.ekleFilm(x);
		
		System.out.println(oyuncu1.yazdirAyrintili());

		
		
		
	}

}
