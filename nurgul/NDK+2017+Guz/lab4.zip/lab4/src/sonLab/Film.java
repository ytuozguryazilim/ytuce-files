package sonLab;

public class Film implements Rol {
	private String filmAdi;
	private int yil;
	private double imdbPuan;
	
	public Film(String filmAdi, int yil){
		this.filmAdi=filmAdi;
		this.yil=yil;
		
	}
	public String getAd() {
		return filmAdi;
	}

	public int getYil() {
		return yil;
	}
	public void setImdbPuan(double puan){ imdbPuan=puan;}
	public double getImdbPuan(){return imdbPuan;}

	
}
