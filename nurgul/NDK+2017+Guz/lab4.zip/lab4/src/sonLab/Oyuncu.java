package sonLab;

public class Oyuncu extends Kisi {
	private int kapasite = 3;
	private int film_count = 0;

	private Film filmler[];

	public Oyuncu(String name, char genre) {
		super(name, genre);
		filmler = new Film[kapasite];
	}

	public void ekleFilm(Film film) {
		int i = 0;
		boolean check = film_count < kapasite;

		while ((check) && (i < film_count)) {
			if (film.getAd().equalsIgnoreCase(filmler[i].getAd())) {
				check = false;
			}
			i++;
		}
		if (check) {
			filmler[film_count] = film;
			film_count++;
		}

	}

	public void arttirFilmKapasite(int ekstra) {
		if (ekstra > filmler.length) {
			Film filmler2[] = new Film[kapasite + ekstra];
			for (int i = 0; i < film_count; i++) {
				filmler2[i] = filmler[i];
			}
			filmler = filmler2;
			kapasite += ekstra;
		}

		System.out.println(" Kapasite arttirildi. Yeni kapasite:" + filmler.length);
	}

	public String yazdirAyrintili() {
		String bilgi = getCinsiyet() == 'e' ? "Aktor " : "Aktrist ";

		bilgi += getAd();
		if (film_count > 0) {
			bilgi += "\nOynadigi filmler:";
			for (int i = 0; i < film_count; i++) {
				bilgi += "\n-" + filmler[i].getAd() + "(" + filmler[i].getYil()
						+ ")";

			}
		}
		return bilgi;
	}

}
