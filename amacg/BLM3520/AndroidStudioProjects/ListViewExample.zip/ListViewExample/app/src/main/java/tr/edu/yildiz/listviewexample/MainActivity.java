package tr.edu.yildiz.listviewexample;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.widget.Toast.LENGTH_LONG;

public class MainActivity extends AppCompatActivity {

    final List<Kisi> kisiler=new ArrayList<Kisi>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       // ListView listView = (ListView) findViewById(R.id.listview1);

        kisiler.add(new Kisi("Ahmet Yılmaz", false));
        kisiler.add(new Kisi("Ayşe Küçük", true));
        kisiler.add(new Kisi("Fatma Bulgurcu", true));
        kisiler.add(new Kisi("İzzet Altınmeşe", false));
        kisiler.add(new Kisi("Melek Subaşı", true));
        kisiler.add(new Kisi("Selim Serdilli", false));
        kisiler.add(new Kisi("Halil İbrahim", false));

        final ListView myList = (ListView) findViewById(R.id.listview1);
        OzelAdapter myAdapter = new OzelAdapter(this,kisiler);
        myList.setAdapter(myAdapter);


        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        int value = sharedPref.getInt("onCreateCount",0);
        value++;
        editor.putInt("onCreateCount", value);


        Toast.makeText(this,value, LENGTH_LONG).show();

    }
}
