These steps will modify your registry. The risk is yours... 

1-) Extract the contents of the zip file to a special folder
2-) Start->Run->Regedit 
3-) Extract HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Nls\CodePage
4-) Edit ACP and set value to 1254
5-) Edit OEMCP and set value to 857
6-) Reboot the system 

AT� 28.4.2004 
