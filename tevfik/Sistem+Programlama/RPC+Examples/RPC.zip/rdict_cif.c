#include <rpc/rpc.h>
#include <stdio.h>
#include "rdict.h"

extern CLIENT *handle;
int initw()
{
	return *initw_1(handle);
}

int insertw(word)
char *word;
{
	char **arg;
	arg= &word;
	return *insertw_1(arg,handle);
}

int deletew(word)
char *word;
{
	char **arg;
	arg = &word;
	return *deletew_1(arg,handle);
}

int lookupw(word)
char *word;
{
	char **arg;
	arg = &word;
	return *lookupw_1(arg,handle);
}
