#include <rpc/rpc.h>
#include "rdict.h"
static int retcode;


int * insertw_1(w)
char **w;
{
	retcode = insertw(*w);
	return &retcode;
}

int *initw_1()
{
	retcode = initw();
	return &retcode;
}

int * deletew_1(w)
char **w;
{
	retcode = deletew(*w);
	return &retcode;
}

int * lookupw_1(w)
char **w;
{
	retcode = lookupw(*w);
	return &retcode;
}
