#include <rpc/rpc.h>
#include <stdio.h>
#include <ctype.h>
#include "rdict.h"
#define RMACHINE "localhost"
CLIENT *handle;

int main(argc,argv)
int argc;
char *argv[];
{
	char word[MAXWORD+1];
	char cmd;
	int wrdlen;

	handle = clnt_create(RMACHINE,RDICTPROG,RDICTVERS,"tcp");
	if (handle == 0) 
	   { printf("Could not contact remote program\n");
		exit(1);
           }

	while (1)	{
			wrdlen = nextin(&cmd,word);
			if (wrdlen < 0 ) exit(0);
			switch (cmd) {
					case 'I':
						initw();
						printf("Directory initialized\n");
						break;
					case 'i':
						insertw(word);
						printf("%s inserted\n",word);
						break;
					case 'd':
						if (deletew(word))
							printf("%s deleted\n",word);
						else 
							printf("%s not found\n",word);
						break;
					case 'l':
						if (lookupw(word))
							printf("%s found\n",word);
						else 
							printf("%s not found \n",word);
						break;
					case 'q':
						printf("program quits\n");
						exit(0);
					default:
						printf("%c command invalid\n",cmd);
						break;
					}
			}
}

int nextin(cmd,word)
char *cmd,*word;
{
	int i,ch;
	ch = getc(stdin);
	while (ch == ' ')
		ch = getc(stdin);
	if (ch == EOF) 
		return -1;
	*cmd = (char) ch;
	ch = getc(stdin);
	while ( ch == ' ')
		ch = getc(stdin);
	if (ch == EOF)
		return -1;
	if (ch == '\n')
		return 0;
	i = 0;
	while (( ch!= ' ') && (ch !='\n')) {
		if (++i> MAXWORD) {
			printf("error word to log\n");
   			exit(1);
			}
		*word++ = ch;
		ch = getc(stdin);
		}
	return i;
}


