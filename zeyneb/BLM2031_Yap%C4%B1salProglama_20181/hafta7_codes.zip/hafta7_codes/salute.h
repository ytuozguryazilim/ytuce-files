/* salute.h header file contains prototypes: */
#ifndef __salute_h__#define __salute_h__void salute( void );#endif
