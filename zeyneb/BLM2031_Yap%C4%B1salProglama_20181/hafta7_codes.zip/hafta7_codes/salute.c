/* salute.c implements the .h in a .c file: */
#include "salute.h"
#include <stdio.h>void salute( void )  {    printf("\n\n HELLO!!! \n\n");}