#include <stdio.h>
#include <string.h>
#include <math.h>
#include "cv.h"
#include "cxcore.h"
#include "highgui.h"


short GetBit(short color, short position)
{
	short division,binaryValue=0;

	// TODO: numbers will be calculated 
	if(position == 8)
		binaryValue = 128;
	else if(position == 7)
		binaryValue = 64;

	division = (color / binaryValue)%2;
	return division;
}
short GetColorsValue(short red, short green,short blue)
{
	short bit,returnValue=0;


	//RED
	bit = GetBit(red,8);
	returnValue += bit * 32;

	bit = GetBit(red,7);
	returnValue += bit * 16;

	//GREEN
	bit = GetBit(green,8);
	returnValue += bit * 8;

	bit = GetBit(green,7);
	returnValue += bit * 4;

	//BLUE
	bit = GetBit(blue,8);
	returnValue += bit * 2;

	bit = GetBit(blue,7);
	returnValue += bit;

	return returnValue;
}


 int* Histogram(IplImage* img)
{

  int height,width,step,channels,i,j;
  short hisColor;
  uchar *data;

  	int* hisbin;
	hisbin = (int *)   calloc((64), sizeof(int));
  
	// get the image data
  height    = img->height;
  width     = img->width;
  step      = img->widthStep;
  channels  = img->nChannels;
  data      = (uchar *)img->imageData;

  // data BGR formatted and channels used to calculate
  for(i=0;i<height;i++) 
	for(j=0;j<width;j++) 
	{
		//TODO : + 2 OR +1 can change check this
		hisColor=	GetColorsValue(data[i*step+j*channels+2],data[i*step+j*channels+1],data[i*step+j*channels]);
		hisbin[hisColor] = 	hisbin[hisColor] + 1;
	}


	return hisbin;

}

 int ManhattanDistance(int *hisPre, int *hisCurrent)
 {
	 int distance=0,diff;
	for(int i = 0; i<64;i++)
	{
		diff = hisCurrent[i] - hisPre[i];
		diff = abs(diff);
		distance += diff;
	}
	 

	 return distance;
 }

int main( int argc, char** argv ){
    
	CvCapture* capture = 0; 
    IplImage* src = 0;
    
    int  i,index=0;
	char fileName[50];
	int	 *hisPre, * hisCurrent;
	hisPre = (int *)   calloc((64), sizeof(int));
	   
	// capture from *.avi (video is in the same folder)
    capture = cvCaptureFromAVI("VIDTEST.AVI"); 

    if( !capture ){
        fprintf(stderr,"Can't load video");
		return 1;
	}
   
	// read images
    for(;;){
        IplImage* frame = 0;

		// get frame 
        frame = cvQueryFrame( capture );
        if( !frame )
            break;

        if( !src ){
        
            src = cvCreateImage( cvGetSize(frame), IPL_DEPTH_8U, 3 );
	        src->origin  = frame->origin;
	    }

		//copy image from frame
		cvCopy( frame, src, 0 );

		//use index to called images and use as a counter
		index++;

		//All images saved to folder to check

	//	sprintf(fileName,"Images\\image_%d.jpeg",index);
	//	cvSaveImage(fileName,src);

		hisCurrent = Histogram(src);

    	//first image is written directly 
		if(index==1)
		{
			sprintf(fileName,"Summary\\image_%d.jpeg",index);
			cvSaveImage(fileName,src);
			
		/*
		// write histogram to check
		for(int i=0;i<64;i++)
			{
				printf(" %d : %d\n ",i,hisCurrent[i]);
			}
		*/
		}
		else
		{
			// calculate distance between previous image and current image
			int distance = ManhattanDistance(hisPre,hisCurrent);

			//image size = 400X272 (108800 pixel)
			// 108800 * 0,02 = 2176 (%2)
			if(distance>2176)
			{
				sprintf(fileName,"Summary\\image_%d.jpeg",index);
				cvSaveImage(fileName,src);
			}
		}

		//current histogram copied to previous histogram
		for( i=0;i<64;i++)
		{
			hisPre[i] = hisCurrent[i];
		} 
		free(hisCurrent);
     }

	// free 
    cvReleaseImage(&src);
    cvReleaseCapture( &capture );

    return 0;
}


