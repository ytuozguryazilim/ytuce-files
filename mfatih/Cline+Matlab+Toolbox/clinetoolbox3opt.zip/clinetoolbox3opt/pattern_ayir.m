function [prune_patterns ,prune_targets ,ytrain_patterns ,ytrain_targets]  = pattern_ayir(train_patterns, train_targets)

[boyut ornek_sayi]=size(train_patterns);

sifirlar=find(train_targets==0);
birler=find(train_targets==1);
[x sifirsayi]=size(sifirlar);
[x birsayi]=size(birler);

train_birsayi=floor(3*birsayi/4);
prune_birsayi=birsayi-train_birsayi;
train_sifirsayi=floor(3*sifirsayi/4);
prune_sifirsayi=sifirsayi-train_sifirsayi;
ytrain_patterns=[];
ytrain_targets=[];
prune_patterns=[];
prune_targets=[];

for i=1:train_birsayi
    ytrain_patterns=[ytrain_patterns train_patterns(:,birler(i))];
    ytrain_targets=[ytrain_targets 1];
end
for i=train_birsayi+1:birsayi
    prune_patterns=[prune_patterns train_patterns(:,birler(i))];
    prune_targets=[prune_targets 1];
end

for i=1:train_sifirsayi
    ytrain_patterns=[ytrain_patterns train_patterns(:,sifirlar(i))];
    ytrain_targets=[ytrain_targets 0];
end
for i=train_sifirsayi+1:sifirsayi
    prune_patterns=[prune_patterns train_patterns(:,sifirlar(i))];
    prune_targets=[prune_targets 0];
end