function [test_targets, ts] = Cline_agacNdim_v5xx_Forest(train_patterns, train_targets, test_patterns, AlgorithmParameters)

% parametreler
% P1    preprunin orani
% P2    post pruning var mi 1 var 0 yok
% P3    dal/ yaprak  1 dal   0 yaprak
% P4    forestsa agac sayisi
% P5    forestsa ozellik sayisi

[PreP, PosP, DY, FA, FF] = parametre_al(AlgorithmParameters);


AS=FA;  % agac sayisi
[boyut orneksayi]=size(train_patterns);

OZS=FF;  % rasgele secilecek ozellik sayisi


if (PosP==1) % posprune varsa
    [prune_patterns prune_targets train_patterns train_targets]=pattern_ayir(train_patterns, train_targets);
    %disp('posprune yap');
else
    %disp('posprune yapma');
end


for i=1:AS
    ppp = randperm(boyut);
    roz=ppp(1:OZS); %rasgele secilen ozellikler
    rozliste(i,:)=roz;
    rtrain_patterns=train_patterns(roz,:);
    agaclar(i)=agac_yap2(rtrain_patterns, train_targets,PreP);
    if (PosP==1) % posprune varsa
        rprune_patterns=prune_patterns(roz,:);
        agaclar(i)=prunit2(agaclar(i),rprune_patterns, prune_targets);
    end
end
% buranin bir anlami yok cunku bussuru agac uretiliyor 
y=agaci_goster(agaclar(1),'',1);
ts=sum(y=='*');

%test verilerini teker teker her agaci kullanarak siniflandir
[ boyut orneksayi]=size(test_patterns);
test_targets2=[];
for i=1:orneksayi
    for j=1:AS
        pattern=test_patterns(rozliste(j,:),i);
        SD=[];
        if (DY==1) % dalsa
            sonuc(j)=agac_kullan_dal(pattern',agaclar(j),SD);
            %disp('dal kullan');
        else
            sonuc(j)=agac_kullan_yaprak(pattern',agaclar(j));
            %disp('yaprak kullan');
        end
        
    end
    % elde  i. test ornegine ait j adet sonuc var. simple voting yap
    [Sinif ssayi]=elementCount(sonuc);
    
    if size(Sinif,2)==1  % hepsi ayni karari vermisse????
        test_targets2(i)=Sinif;
    else
    if ssayi(1)>ssayi(2)   
        test_targets2(i)=0;
    else
        test_targets2(i)=1;
    end
    end
    %test_targets2(i)
end
test_targets=test_targets2;

%
% agac yap
%
%by=basari yuzdesi
function agac=agac_yap2(train_patterns,train_targets,by);

%AGAC YAPISI
    %AGAC.BIR
    %AGAC.IKI
    %AGAC.PARAMS
    %AGAC.ISARET
    %AGAC.BASARI
    %AGAC.YAPRAK
    %AGAC.AS
    %AGAC.YU



patterns2=train_patterns;
targets=train_targets;

patterns2=patterns2';
[orneksayi boyut]=size(patterns2);
top=0;
for i=1:orneksayi
    top=top+train_targets(i);
end
if ((top/orneksayi)<by) & ((top/orneksayi)>1-by) & (orneksayi>3)% saf  degilse

sinif_1=[];
sinif_2=[];
for i=1:orneksayi
    if (targets(i)==1)
        sinif_1=[sinif_1 ;patterns2(i,:)];
    else sinif_2=[sinif_2 ;patterns2(i,:)];
    end
end

sinif_2=sinif_2';
%sinif_1 satir satir
%sinif_2 sutun sutun
mes=dist(sinif_1,sinif_2);
% mes(i,j)= sinif_1'in i. noktasinin sinif_2'nin j. noktasina olan uzakligi
sinif_2=sinif_2';

[M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
%{
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end
 
%K=1; 
%CI(K,1)=yerx;
%CI(K,2)=yery;
mes(yerx,yery)=1000;

%nokta1=[ sinif_1(yerx,:)]; % 1. nokta
%nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta


nokta1=mean(sinif_1); %[ sinif_1(yerx,:)]; % 1. nokta
nokta2=mean(sinif_2); %[ sinif_2(yery,:)]; % diger siniftan 2. nokta
if length(nokta1)==1 nokta1=sinif_1; end
if length(nokta2)==1 nokta2=sinif_2; end
    

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
%}
nokta1=mean(sinif_1); %[ sinif_1(yerx,:)]; % 1. nokta
nokta2=mean(sinif_2); %[ sinif_2(yery,:)]; % diger siniftan 2. nokta

if (boyut>1)
    if length(nokta1)==1 nokta1=sinif_1; end
    if length(nokta2)==1 nokta2=sinif_2; end
end


    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac.params(i)*nokta1(i);
    end
    isaret=isaret+agac.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac.isaret=1;%cline(K,3)=1;
    else
    agac.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac.params(i)*nokta(i);
        end
        isaret=isaret+agac.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac.basari=dsayi/orneksayi; %cline(K,4)=dsayi/orneksayi;
    
    % agacin kollarini belirle usttekileri birine alttakileri digerine yolla
    yukari=[];
    asagi=[];
    asagi_target=[];
    yukari_target=[];
    for j=1:orneksayi
        nokta=patterns2(j,:);
        
        isaret=0;
        for i=1:boyut-1
          isaret=isaret+agac.params(i)*nokta(i);
        end
        isaret=isaret+agac.params(boyut);        
        isaret=sign(nokta(boyut)-isaret);

        if (isaret==1) %dogrunun yukarisinda 
            yukari=[yukari nokta']; 
            yukari_target=[yukari_target targets(j)];
        else
            asagi=[asagi nokta'];
            asagi_target=[asagi_target targets(j)];
        end
    end    
    
    % datanin hepsi bir tarafta ise bit
    
    if  (length(yukari_target)==0) | (length(asagi_target)==0)  % hyper duzlem noktalari bolmuyorsa. noktalarin hepsi hyper duzlemin bir tarafinda kaliyorsa.
           agac.yaprak=0;
    
           agac.birincisinifsayi=sum(targets==0);
           agac.ikincisinifsayi =sum(targets==1);
    
           if (top/orneksayi>0.5) 
              agac.isaret= 1;
           else
              agac.isaret= 0;
           end
    else
   
    agac.yaprak=1;

    agac.birincisinifsayi=sum(targets==0);
    agac.ikincisinifsayi=sum(targets==1);

    agac.as=agac_yap2(asagi, asagi_target,by);
    agac.yu=agac_yap2(yukari, yukari_target,by);
    end
    
    
else % saf ise
    agac.yaprak=0;
    
    agac.birincisinifsayi=sum(targets==0);
    agac.ikincisinifsayi =sum(targets==1);

    if (top/orneksayi>0.5) 
            agac.isaret= 1;
    else
            agac.isaret= 0;
    end
end