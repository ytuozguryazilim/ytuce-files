function  [test_targets, ts] = Cline_agacNdim_MIX(train_patterns, train_targets, test_patterns, AlgorithmParameters)
% parametreler
% P1    preprunin orani
% P2    post pruning var mi 1 var 0 yok
% P3    dal/ yaprak  1 dal   0 yaprak
% P4    forestsa agac sayisi
% P5    forestsa ozellik sayisi

[PreP, PosP, DY, FA, FF] = parametre_al(AlgorithmParameters);

if (PosP==1) % posprune varsa
    [prune_patterns prune_targets train_patterns train_targets]=pattern_ayir(train_patterns, train_targets);
    disp('posprune yap');
else
    disp('posprune yapma');
end

agac=agac_yap2(train_patterns, train_targets,PreP);

if (PosP==1) % posprune varsa
    agac=prunit2(agac,prune_patterns, prune_targets);
end

y=agaci_goster(agac,'',1);
ts=sum(y=='*');

%test verilerini teker teker agaci kullanarak siniflandir
[ boyut orneksayi]=size(test_patterns);
test_targets2=[];
for i=1:orneksayi
    pattern=test_patterns(:,i);
    SD=[];
    if (DY==1) % dalsa
        test_targets2(i)=agac_kullan_dal(pattern',agac,SD);
        disp('dal kullan');
    else
        test_targets2(i)=agac_kullan_yaprak(pattern',agac);
        disp('yaprak kullan');
    end

end
test_targets=test_targets2;

%
% agac yap
%
%by=basari yuzdesi
function agac=agac_yap2(train_patterns,train_targets,by);

%AGAC YAPISI
    %AGAC.BIR
    %AGAC.IKI
    %AGAC.PARAMS
    %AGAC.ISARET
    %AGAC.BASARI
    %AGAC.YAPRAK
    %AGAC.AS
    %AGAC.YU



patterns2=train_patterns;
targets=train_targets;

patterns2=patterns2';
[orneksayi boyut]=size(patterns2);
top=0;
for i=1:orneksayi
    top=top+train_targets(i);
end
if ((top/orneksayi)<by) & ((top/orneksayi)>1-by) & (orneksayi>5)% saf  degilse

sinif_1=[];
sinif_2=[];
for i=1:orneksayi
    if (targets(i)==1)
        sinif_1=[sinif_1 ;patterns2(i,:)];
    else sinif_2=[sinif_2 ;patterns2(i,:)];
    end
end
% simdi V5 ile basari yuzdesini bul.
sinif_2=sinif_2';
%sinif_1 satir satir
%sinif_2 sutun sutun
mes=dist(sinif_1,sinif_2);
mes2=mes;
% mes(i,j)= sinif_1'in i. noktasinin sinif_2'nin j. noktasina olan uzakligi
sinif_2=sinif_2';

[M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end
mes(yerx,yery)=1000;


nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta



%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
    
    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac.params(i)*nokta1(i);
    end
    isaret=isaret+agac.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac.isaret=1;%cline(K,3)=1;
    else
    agac.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac.params(i)*nokta(i);
        end
        isaret=isaret+agac.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac.basari=dsayi/orneksayi; %cline(K,4)=dsayi/orneksayi;

    % simdi V9 ile basari yuzdesini bul.

mes=mes2;
[M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end

mes(yerx,yery)=1000;
% mes(i,j)= sinif_1'in i. noktasinin sinif_2'nin j. noktasina olan uzakligi
%mes matrisinde yerx inci satirdaki en kucuk ikinciyi bul.
%yani diger s�n�ftan 1. noktaya en yak�n ikinci noktay�
%1000 yaptigimizdan en kucugunu bulmak yeterli
[degeri yerz ]=min(mes(yerx,:));
[degeri yerk ]=min(mes(:,yery));

nokta1=[ sinif_1(yerx,:)]; % 1. nokta (1.sinif tan)
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta (2.sinif tan)
nokta3=[ sinif_2(yerz,:)]; % diger siniftan 3. nokta (2.sinif tan)
nokta4=[ sinif_1(yerk,:)]; % diger siniftan 4. nokta (1.sinif tan)

nokta2=(nokta2+nokta3)/2; % 2 ve 3. noktalar�n ortas�n� nokta2 olarak belirle
nokta1=(nokta1+nokta4)/2; % 1 ve 4. noktalar�n ortas�n� nokta1 olarak belirle
    
%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end

    %%%%%%%%%%%%%%
    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac2.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac2.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac2.params(i)*nokta1(i);
    end
    isaret=isaret+agac2.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac2.isaret=1;%cline(K,3)=1;
    else
    agac2.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac2.params(i)*nokta(i);
        end
        isaret=isaret+agac2.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac2.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac2.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac2.basari=dsayi/orneksayi; %cline(K,4)=dsayi/orneksayi;
    %%%%%%%%%%%%%%
 % simdi v7 ile bul
 %%%%%%%v7<
 mes=mes2;
[M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end
mes(yerx,yery)=1000;
% mes(i,j)= sinif_1'in i. noktasinin sinif_2'nin j. noktasina olan uzakligi
%mes matrisinde yerx inci satirdaki en kucuk ikinciyi bul.
%yani diger s�n�ftan 1. noktaya en yak�n ikinci noktay�
%1000 yaptigimizdan en kucugunu bulmak yeterli
[degeri yerz ]=min(mes(yerx,:));

nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta
nokta3=[ sinif_2(yerz,:)]; % diger siniftan 3. nokta

nokta2=(nokta2+nokta3)/2; % 2 ve 3. noktalar�n ortas�n� nokta2 olarak belirle
    
%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
    
    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac3.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac3.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac3.params(i)*nokta1(i);
    end
    isaret=isaret+agac3.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac3.isaret=1;%cline(K,3)=1;
    else
    agac3.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac3.params(i)*nokta(i);
        end
        isaret=isaret+agac3.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac3.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac3.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac3.basari=dsayi/orneksayi; %cline(K,4)=dsayi/orneksayi;


 %%%%%%%v7>
 
 %%%%% PCA<
 mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end
mes(yerx,yery)=1000;

nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
   
% varyansin en buyuk oldugu boyutu bul(en b�t�k eigen value ya sahip eigen vektoru bul)
[rd,ornek_sayi] = size(patterns2');
ortalama    = mean(patterns2)';
SS			= ((patterns2' - ortalama*ones(1,ornek_sayi)) * (patterns2' - ortalama*ones(1,ornek_sayi))');
[eigV, eigD]	    = eig(SS);
% eigD'si en buyuk olan eigen vektoru al
% en son vektordur
maxVec=eigV(:,rd);
% maxVec 0,0 noktasindan bir noktaya dogru bir dogrultu vektoru

    ortnok=(nokta1+nokta2)/2;
%    dikvek=nokta2-nokta1;
    dikvek=maxVec';
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);

    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac4.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac4.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac4.params(i)*nokta1(i);
    end
    isaret=isaret+agac4.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac4.isaret=1;%cline(K,3)=1;
    else
    agac4.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac4.params(i)*nokta(i);
        end
        isaret=isaret+agac4.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac4.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac4.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac4.basari=dsayi/orneksayi; %cline(K,4)=dsayi/orneksayi;

 %%%%% PCA>
 
 %%%%%%%%%%%% LDA5<
 mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end
 
%K=1; 
%CI(K,1)=yerx;
%CI(K,2)=yery;
mes(yerx,yery)=1000;

nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
   
DS.input=patterns2';
DS.output=targets;
[DS2, discrimVec] = LDAp(DS, 1);

    ortnok=(nokta1+nokta2)/2;
%    dikvek=nokta2-nokta1;
    dikvek=discrimVec';
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac5.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac5.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac5.params(i)*nokta1(i);
    end
    isaret=isaret+agac5.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac5.isaret=1;%cline(K,3)=1;
    else
    agac5.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac5.params(i)*nokta(i);
        end
        isaret=isaret+agac5.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac5.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac5.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac5.basari=dsayi/orneksayi; %cline(K,4)=dsayi/orneksayi;
    

 %%%%%%%%%%%% LDA5>
 
 %%%%% v5xx<
 mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
while (kt==0)

yerx=1;
yery=1;
mini=mes(1,1);    
 for j=1:M
    for k=1:N
        if mini>mes(j,k)
            mini=mes(j,k);
            yerx=j;
            yery=k;
        end
    end
 end
 
%K=1; 
%CI(K,1)=yerx;
%CI(K,2)=yery;
mes(yerx,yery)=1000;

%nokta1=[ sinif_1(yerx,:)]; % 1. nokta
%nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta


nokta1=mean(sinif_1); %[ sinif_1(yerx,:)]; % 1. nokta
nokta2=mean(sinif_2); %[ sinif_2(yery,:)]; % diger siniftan 2. nokta
if length(nokta1)==1 nokta1=sinif_1; end
if length(nokta2)==1 nokta2=sinif_2; end
    

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
    
    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    for i=1:boyut-1
       agac6.params(i)=dikvek(i)/dikvek(boyut)*-1;
    end
    agac6.params(boyut)=sabit/dikvek(boyut)*-1;

    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac6.params(i)*nokta1(i);
    end
    isaret=isaret+agac6.params(boyut);
    isaret=sign(nokta1(boyut)-isaret);
    
    if (isaret>0) %yukar�dakiler sinif1
    agac6.isaret=1;%cline(K,3)=1;
    else
    agac6.isaret=0;%cline(K,3)=-1;
    end
    
    % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac6.params(i)*nokta(i);
        end
        isaret=isaret+agac6.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac6.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac6.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac6.basari=dsayi/orneksayi; 

 %%%%%%%%%%%% v5xx>
 
 %%%%%%%%%%%% <LVQ
 mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
[SA SU]=size(mes);
while (kt==0)
if SA==1
    [e1 e2]=min(mes);
    yerx=1;
    yery=e2;
else
    if SU==1
        [e1 e2]=min(mes);
        yery=1;
        yerx=e2;
    else
        [e1 e2]=min(mes);
        [r1 yery]=min(e1);
        yery=yery(1);
        yerx=e2(yery);
    end
end
 
mes(yerx,yery)=1000;

nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
    

    [cents , cent_targets]=myLVQ2(patterns2', targets, 2);
    cents=cents';
    nokta1=cents(1,:);
    nokta2=cents(2,:);

    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    agac7.params=dikvek/dikvek(boyut)*-1;
    agac7.params(boyut)=sabit/dikvek(boyut)*-1;
   
    agac7.isaret=1;
    %agac.basari=1;

     % basari y�zdesini bul
    dsayi=0;
    for j=1:orneksayi
        nokta=patterns2(j,:);

        isaret=0;
        for i=1:boyut-1
           isaret=isaret+agac7.params(i)*nokta(i);
        end
        isaret=isaret+agac7.params(boyut);
        isaret=sign(nokta(boyut)-isaret); 
        
        if (isaret==1)&(agac7.isaret==targets(j)) 
            dsayi=dsayi+1;
        else 
            if (isaret==-1)&(agac7.isaret*targets(j)==0) % e�it de�ilse 
            dsayi=dsayi+1;
            end
        end
    end
    agac7.basari=dsayi/orneksayi; 
    
 
 
 %%%%%%%%%%%% LVQ>
 %  basarilar=[agac.basari agac2.basari agac3.basari agac4.basari agac5.basari agac6.basari agac7.basari];
 %  basarilar=[    V5          v9             v7           PCA        LDAp         v5xx         LVQ     ];
 %  basarilar=[agac.basari agac2.basari agac3.basari               agac5.basari agac6.basari];
 %  basarilar=[agac.basari              agac3.basari               agac5.basari];
    basarilar=[                                                    agac5.basari agac6.basari agac7.basari];
 %  basarilar=[                                                                 agac6.basari agac7.basari];
 %  basarilar=[            agac2.basari agac3.basari               agac5.basari agac6.basari agac7.basari];
    [ifg indt]=max(basarilar);
 if indt==1
     agac=agac5;
 end
 if indt==2
     agac=agac6;
 end
 if indt==3
     agac=agac7;
 end
 %{
 if indt==4
     agac=agac6;
 end
 if indt==5
     agac=agac7;
 end
 %}
 
    
    % agacin kollarini belirle usttekileri birine alttakileri digerine yolla
    yukari=[];
    asagi=[];
    asagi_target=[];
    yukari_target=[];
    for j=1:orneksayi
        nokta=patterns2(j,:);
        
        isaret=0;
        for i=1:boyut-1
          isaret=isaret+agac.params(i)*nokta(i);
        end
        isaret=isaret+agac.params(boyut);        
        isaret=sign(nokta(boyut)-isaret);

        if (isaret==1) %dogrunun yukarisinda 
            yukari=[yukari nokta']; 
            yukari_target=[yukari_target targets(j)];
        else
            asagi=[asagi nokta'];
            asagi_target=[asagi_target targets(j)];
        end
    end    
    agac.yaprak=1;
    agac.birincisinifsayi=sum(targets==0);
    agac.ikincisinifsayi=sum(targets==1);

    if length(asagi)==0 
        bosa=1
            agac.yaprak=0;
        if (top/orneksayi>0.5) 
             agac.isaret= 1;
        else
            agac.isaret= 0;
        end
        
    else
        if length(yukari)==0
            bosy=1
            agac.yaprak=0;
        if (top/orneksayi>0.5) 
             agac.isaret= 1;
        else
            agac.isaret= 0;
        end
        
        else
            agac.as=agac_yap2(asagi, asagi_target,by);
            agac.yu=agac_yap2(yukari, yukari_target,by);
    
        end
        
    end
    

    
    
else % saf ise
    agac.yaprak=0;
    agac.birincisinifsayi=sum(targets==0);
    agac.ikincisinifsayi =sum(targets==1);

    if (top/orneksayi>0.5) 
            agac.isaret= 1;
    else
            agac.isaret= 0;
    end
end