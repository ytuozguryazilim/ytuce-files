function [test_targets, ts] = Cline_agacNdim_MIX_Forest(train_patterns, train_targets, test_patterns, AlgorithmParameters)
% parametreler
% P1    preprunin orani
% P2    post pruning var mi 1 var 0 yok
% P3    dal/ yaprak  1 dal   0 yaprak
% P4    forestsa agac sayisi
% P5    forestsa ozellik sayisi

[PreP, PosP, DY, FA, FF] = parametre_al(AlgorithmParameters);

AS=FA;  % agac sayisi
[boyut orneksayi]=size(train_patterns);

OZS=FF;  % rasgele secilecek ozellik sayisi


if (PosP==1) % posprune varsa
    [prune_patterns prune_targets train_patterns train_targets]=pattern_ayir(train_patterns, train_targets);
    %disp('posprune yap');
else
    %disp('posprune yapma');
end


for i=1:AS
    ppp = randperm(boyut);
    roz=ppp(1:OZS); %rasgele secilen ozellikler
    rozliste(i,:)=roz;
    rtrain_patterns=train_patterns(roz,:);
    agaclar(i)=agac_yap2(rtrain_patterns, train_targets,PreP);
    if (PosP==1) % posprune varsa
        rprune_patterns=prune_patterns(roz,:);
        agaclar(i)=prunit2(agaclar(i),rprune_patterns, prune_targets);
    end
end
% buranin bir anlami yok cunku bussuru agac uretiliyor 
y=agaci_goster(agaclar(1),'',1);
ts=sum(y=='*');

%test verilerini teker teker her agaci kullanarak siniflandir
[ boyut orneksayi]=size(test_patterns);
test_targets2=[];
for i=1:orneksayi
    for j=1:AS
        pattern=test_patterns(rozliste(j,:),i);
        SD=[];
        if (DY==1) % dalsa
            sonuc(j)=agac_kullan_dal(pattern',agaclar(j),SD);
            %disp('dal kullan');
        else
            sonuc(j)=agac_kullan_yaprak(pattern',agaclar(j));
            %disp('yaprak kullan');
        end
        
    end
    % elde  i. test ornegine ait j adet sonuc var. simple voting yap
    [Sinif ssayi]=elementCount(sonuc);
    
    if size(Sinif,2)==1  % hepsi ayni karari vermisse????
        test_targets2(i)=Sinif;
    else
    if ssayi(1)>ssayi(2)   
        test_targets2(i)=0;
    else
        test_targets2(i)=1;
    end
    end
    %test_targets2(i)
end
test_targets=test_targets2;

%
% agac yap
%
%by=basari yuzdesi
function agac=agac_yap2(train_patterns,train_targets,by);

%AGAC YAPISI
    %AGAC.BIR
    %AGAC.IKI
    %AGAC.PARAMS
    %AGAC.ISARET
    %AGAC.BASARI
    %AGAC.YAPRAK
    %AGAC.AS
    %AGAC.YU



patterns2=train_patterns;
targets=train_targets;

patterns2=patterns2';
[orneksayi boyut]=size(patterns2);
top=0;
top=sum(train_targets);

% farkl� s�n�flardan ayn� noktalar varsa sonsuz dongu oluyor
sinifX1=patterns2(find(train_targets==1),:);
sinifX2=patterns2(find(train_targets==0),:);

if ~isempty(sinifX1) m1=mean(sinifX1); 
else m1=[];
end
if ~isempty(sinifX2) m2=mean(sinifX2); 
else m2=[];
end
if boyut>1 % orjinal data tek boyutlu degilse
    if length(m1)==1 m1=sinifX1; end
    if length(m2)==1 m2=sinifX2; end
end

if ((top/orneksayi)<by) & ((top/orneksayi)>1-by) & (orneksayi>5) & (sum(round(m1*100)==round(m2*100))<boyut) % saf  degilse

sinif_1=sinifX1;
sinif_2=sinifX2;

% simdi LDA ile basari yuzdesini bul.
sinif_2=sinif_2';
%sinif_1 satir satir
%sinif_2 sutun sutun
mes=dist(sinif_1,sinif_2);
mes2=mes;
sinif_2=sinif_2';
 %%%%%%%%%%%% LDA5<
% mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
[SA SU]=size(mes);
while (kt==0)
if SA==1
    [e1 e2]=min(mes);
    yerx=1;
    yery=e2;
else
    if SU==1
        [e1 e2]=min(mes);
        yery=1;
        yerx=e2;
    else
        [e1 e2]=min(mes);
        [r1 yery]=min(e1);
        yery=yery(1);
        yerx=e2(yery);
    end
end
 
mes(yerx,yery)=1000;

nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
   
DS.input=patterns2';
DS.output=targets;
[DS2, discrimVec] = LDAp(DS, 1);

    ortnok=(nokta1+nokta2)/2;
%    dikvek=nokta2-nokta1;
    dikvek=discrimVec';
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end

    agac5.params=dikvek/dikvek(boyut)*-1;
    agac5.params(boyut)=sabit/dikvek(boyut)*-1;
    
    isaret=sign(patterns2(:,boyut)-(sum((repmat(agac5.params, orneksayi,1).*patterns2)')-(agac5.params(boyut)*patterns2(:,boyut)')+agac5.params(boyut))');
    yukari=patterns2(find(isaret==1),:)';
    yukari_target=targets(find(isaret==1));
    asagi=patterns2(find(isaret==-1),:)';
    asagi_target=targets(find(isaret==-1));
    %sinif1 yukarida mi asagida mi?
    if mean(yukari_target)>0.5 % sinif 1 yukarida mi?
        dsayi=sum(yukari_target==1)+sum(asagi_target==0);
    else
        dsayi=sum(yukari_target==0)+sum(asagi_target==1);
    end
    
    agac5.isaret=1;
    agac5.basari=dsayi/length(targets);

 %%%%%%%%%%%% LDA5>
 
 %%%%% v5xx<
 mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
[SA SU]=size(mes);
while (kt==0)
if SA==1
    [e1 e2]=min(mes);
    yerx=1;
    yery=e2;
else
    if SU==1
        [e1 e2]=min(mes);
        yery=1;
        yerx=e2;
    else
        [e1 e2]=min(mes);
        [r1 yery]=min(e1);
        yery=yery(1);
        yerx=e2(yery);
    end
end
 
mes(yerx,yery)=1000;

nokta1=mean(sinif_1); %[ sinif_1(yerx,:)]; % 1. nokta
nokta2=mean(sinif_2); %[ sinif_2(yery,:)]; % diger siniftan 2. nokta
if boyut>1
    if length(nokta1)==1 nokta1=sinif_1; end
    if length(nokta2)==1 nokta2=sinif_2; end
end

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
    
    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    
    agac6.params=dikvek/dikvek(boyut)*-1;
    agac6.params(boyut)=sabit/dikvek(boyut)*-1;
   
    isaret=sign(patterns2(:,boyut)-(sum((repmat(agac6.params, orneksayi,1).*patterns2)')-(agac6.params(boyut)*patterns2(:,boyut)')+agac6.params(boyut))');
    yukari=patterns2(find(isaret==1),:)';
    yukari_target=targets(find(isaret==1));
    asagi=patterns2(find(isaret==-1),:)';
    asagi_target=targets(find(isaret==-1));
    %sinif1 yukarida mi asagida mi?
    if mean(yukari_target)>0.5 % sinif 1 yukarida mi?
        dsayi=sum(yukari_target==1)+sum(asagi_target==0);
    else
        dsayi=sum(yukari_target==0)+sum(asagi_target==1);
    end
    
    agac6.isaret=1;
    agac6.basari=dsayi/length(targets);
 %%%%%%%%%%%% v5xx>
 
 %%%%%%%%%%%% <LVQ
 mes=mes2;
 [M,N]=size(mes);

% en k���k mesafedeki nokta �iftlerini bul
kt=0;
[SA SU]=size(mes);
while (kt==0)
if SA==1
    [e1 e2]=min(mes);
    yerx=1;
    yery=e2;
else
    if SU==1
        [e1 e2]=min(mes);
        yery=1;
        yerx=e2;
    else
        [e1 e2]=min(mes);
        [r1 yery]=min(e1);
        yery=yery(1);
        yerx=e2(yery);
    end
end
 
mes(yerx,yery)=1000;

nokta1=[ sinif_1(yerx,:)]; % 1. nokta
nokta2=[ sinif_2(yery,:)]; % diger siniftan 2. nokta

%bulunan iki nokta birbirine esit mi
if (nokta1==nokta2) else kt=1; end
end
    

    [cents , cent_targets]=myLVQ2(patterns2', targets, 2);
    cents=cents';
    nokta1=cents(1,:);
    nokta2=cents(2,:);

    ortnok=(nokta1+nokta2)/2;
    dikvek=nokta2-nokta1;
    eksiort=ortnok*-1;
    sabit=dikvek.*eksiort;
    sabit=sum(sabit);
    
    if (dikvek(boyut)==0) 
        dikvek(boyut)=0.00001;
    end
    agac7.params=dikvek/dikvek(boyut)*-1;
    agac7.params(boyut)=sabit/dikvek(boyut)*-1;
   
    isaret=sign(patterns2(:,boyut)-(sum((repmat(agac7.params, orneksayi,1).*patterns2)')-(agac7.params(boyut)*patterns2(:,boyut)')+agac7.params(boyut))');
    yukari=patterns2(find(isaret==1),:)';
    yukari_target=targets(find(isaret==1));
    asagi=patterns2(find(isaret==-1),:)';
    asagi_target=targets(find(isaret==-1));
    %sinif1 yukarida mi asagida mi?
    if mean(yukari_target)>0.5 % sinif 1 yukarida mi?
        dsayi=sum(yukari_target==1)+sum(asagi_target==0);
    else
        dsayi=sum(yukari_target==0)+sum(asagi_target==1);
    end
    
    agac7.isaret=1;
    agac7.basari=dsayi/length(targets);

 %%%%%%%%%%%% LVQ>
 %  basarilar=[agac.basari agac2.basari agac3.basari agac4.basari agac5.basari agac6.basari agac7.basari];
 %  basarilar=[    V5          v9             v7           PCA        LDAp         v5xx         LVQ     ];
 %  basarilar=[agac.basari agac2.basari agac3.basari               agac5.basari agac6.basari];
 %  basarilar=[agac.basari              agac3.basari               agac5.basari];
    basarilar=[                                                    agac5.basari agac6.basari agac7.basari];
 %  basarilar=[                                                                 agac6.basari agac7.basari];
 %  basarilar=[            agac2.basari agac3.basari               agac5.basari agac6.basari agac7.basari];
    [ifg indt]=max(basarilar);
 if indt==1
     agac=agac5;
     disp('LDA i sectim');
 end
 if indt==2
     agac=agac6;
     disp('V5xx i sectim');
 end
 if indt==3
     agac=agac7;
     disp('LVQ i sectim');
 end
%{
 if indt==4
     agac=agac6;
 end
 if indt==5
     agac=agac7;
 end
 %}
 
    
    % agacin kollarini belirle usttekileri birine alttakileri digerine yolla
    isaret=sign(patterns2(:,boyut)-(sum((repmat(agac.params, orneksayi,1).*patterns2)')-(agac.params(boyut)*patterns2(:,boyut)')+agac.params(boyut))');
    yukari=patterns2(find(isaret==1),:)';
    yukari_target=targets(find(isaret==1));
    asagi=patterns2(find(isaret==-1),:)';
    asagi_target=targets(find(isaret==-1));

    agac.yaprak=1;
    agac.birincisinifsayi=sum(targets==0);
    agac.ikincisinifsayi=sum(targets==1);
   
    %agac.as=[];
    %agac.yu=[];
   
    if length(asagi)==0 
        bosa=1
            agac.yaprak=0;
        if (top/orneksayi>0.5) 
             agac.isaret= 1;
        else
            agac.isaret= 0;
        end
        
    else
        if length(yukari)==0
            bosy=1
            agac.yaprak=0;
        if (top/orneksayi>0.5) 
             agac.isaret= 1;
        else
            agac.isaret= 0;
        end
        
        else
            agac.as=agac_yap2(asagi, asagi_target,by);
            agac.yu=agac_yap2(yukari, yukari_target,by);
    
        end
        
    end
    

    
    
else % saf ise
    agac.yaprak=0;
    agac.birincisinifsayi=sum(targets==0);
    agac.ikincisinifsayi =sum(targets==1);

    if (top/orneksayi>0.5) 
            agac.isaret= 1;
    else
            agac.isaret= 0;
    end
end