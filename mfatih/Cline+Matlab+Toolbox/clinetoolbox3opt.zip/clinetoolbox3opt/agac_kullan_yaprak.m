function target = agac_kullan_yaprak(pattern,agac)
[ x boyut ]=size(pattern);
if agac.yaprak==0
    target=agac.isaret;
else
    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac.params(i)*pattern(i);
    end
    isaret=isaret+agac.params(boyut);
    isaret=sign(pattern(boyut)-isaret);
    
    if (isaret==1) %dogrunun yukarisinda 
            a=agac.yu;
    else
            a=agac.as;
    end
    target=agac_kullan_yaprak(pattern,a);
end