function [test_targets ,ort_tree_size]= Cline_agacNdimNclass_1vs1(train_patterns, train_targets, test_patterns, AlgorithmParameters, AlgorithmX)
% one versus one

[k sinif_sayisi]=size(unique(train_targets));
%olasi tum kombinasyonlari bul
combos = combntns(1:sinif_sayisi,2);
[kom_sayi k]=size(combos);

[boyut egitim_ornek_sayisi]=size(train_patterns);
[boyut test_ornek_sayisi]=size(test_patterns);

ts=0;
for i=1:kom_sayi
    %sadece combos'un i satirindaki siniflarin(2 tane) ornekleriyle egitecez.  
    asinif=combos(i,1);
    bsinif=combos(i,2);
    tp=[];
    tt=[];
    for j=1:egitim_ornek_sayisi 
        if (train_targets(j)==asinif)   % ilk siniftansa 1
            tp=[tp train_patterns(:,j)];
            tt=[tt 1];
        else
            if (train_targets(j)==bsinif) 
                tp=[tp train_patterns(:,j)]; 
                tt=[tt 0];  % ikinci siniftansa 0
            end
        end
    end
    [temp treesize]=feval(AlgorithmX,tp, tt, test_patterns, AlgorithmParameters);
    ts=ts+treesize;
    %1 leri asinif 0 lari bsinif yap
    for j=1:test_ornek_sayisi 
        if (temp(j)==1) temp(j)=asinif;
        else temp(j)=bsinif;
        end
    end
    
    sonuclar(i,:)=temp;
    
end
%sonuclar

[boyut test_ornek_sayisi]=size(test_patterns);

ort_tree_size=round(ts/kom_sayi);

for i=1:test_ornek_sayisi
% her bir sutunda en fazla olan sinif o test orneginin sinifidir (max-wins-voting)
sonuc=[]; %herbir sinifin tekrar etme sayisini bul
 for j=1:sinif_sayisi
     [sonuc(j) k]=size(find(sonuclar(:,i) == j));
 end
[k test_targets(i)]=max(sonuc);  % tekrar etme sayilarinin maksimumunun yeri 
  
end