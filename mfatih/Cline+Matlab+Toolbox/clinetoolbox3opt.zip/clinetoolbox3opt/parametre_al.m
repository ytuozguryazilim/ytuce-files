function [P1, P2, P3, P4, P5, P6] = parametre_al(params)
%The parameter vector is completely numeric.
[P1, P2, P3, P4, P5, P6] = deal([]);

for i = 1:length(params),
   eval(['P' num2str(i) ' = ' num2str(params(i)) ';']);
end
Nassigned = length(params);   

if (Nassigned ~= nargout),
    warning('Not all parameters in the parameter vector were read by the algorithm')
end
