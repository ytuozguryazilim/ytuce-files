function [patterns, targets] = myLVQ2(train_patterns, train_targets, Nmu, plot_on)

%Reduce the number of data points using linear vector quantization
%Inputs:
%	train_patterns	- Input patterns
%	train_targets	- Input targets
%	Nmu				- Number of output data points
%   plot_on         - Plot stages of the algorithm
%
%Outputs
%	patterns		- New patterns
%	targets			- New targets

if (nargin < 4),
    plot_on = 0;
end

alpha   = 0.3;
L		= length(train_targets);
dist	= zeros(Nmu,L);
label   = zeros(1,L);
Dim     = size(train_patterns, 1);

%Initialize the mu's
mu			= randn(Dim,Nmu);
%mu			= sqrtm(cov(train_patterns',1))*mu + mean(train_patterns')'*ones(1,Nmu);
x1=find(train_targets==1);
x0=find(train_targets==0);

mu= [train_patterns(:,x1(1)) train_patterns(:,x0(1))];
mu_target   = rand(1,Nmu)>0.5;
mu_target=[0 1];
old_mu	    = zeros(Dim,Nmu);

while (sum(sum(abs(mu - old_mu))) > 0.1),
   old_mu = mu;
   
   %Classify all the patterns to one of the mu's
   for i = 1:Nmu,
      dist(i,:) = sum((train_patterns - mu(:,i)*ones(1,L)).^2);
   end
   
   %Label the points
   [m,label] = min(dist);
   
   %Label the mu's
	for i = 1:Nmu,
   	if (length(train_targets(:,find(label == i))) > 0),
      	mu_target(i) = (sum(train_targets(:,find(label == i)))/length(train_targets(:,find(label == i))) > .5);
	   end
	end	
   
   %Recompute the mu's
   for i = 1:Nmu,
      indices = find(label == i);
      if ~isempty(indices),
         Q		  = ones(Dim,1) * (2*(train_targets(indices) == mu_target(i)) - 1);
         mu(:,i) = mu(:,i) + mean(((train_patterns(:,indices)-mu(:,i)*ones(1,length(indices))).*Q)')'*alpha;
      end
      
   end
   
   alpha = 0.95 * alpha;
   
   %Plot centers during training
   %plot_process(mu, plot_on)

end

%Label the data
targets = zeros(1,Nmu);
Uc      = unique(train_targets);

for i = 1:Nmu,
    in				= find(label == i);
    if ~isempty(in),
        h            = hist(train_targets(in), Uc);
        [m, best]    = max(h);
        targets(i)	 = Uc(best);
        %if length(in) == 1,
        %    patterns(:,i)	= train_patterns(:,in);
        %else
        %    patterns(:,i)  = mean(train_patterns(:,in)')';
        %end
    else
        patterns(:,i) = nan;
    end   
end
%patterns = mu;

% targets
if (sum(targets)==0) % ikiside 0 sa
    in = find(train_targets == 1);
    uz=length(in);
    d1=train_patterns(:,in)-mu(:,1)*ones(1,uz);
    d1=sum(sqrt(sum(d1.*d1)));
    %d1=sum(dist(mu(:,1),train_patterns(:,in)));
    d2=train_patterns(:,in)-mu(:,2)*ones(1,uz);
    d2=sum(sqrt(sum(d2.*d2)));
    %d2=sum(dist(mu(:,2),train_patterns(:,in)));
    if d1>d2 % d2 daha yakin
        targets(2)=1;
        if length(in) == 1,
            mu(:,2)= train_patterns(:,in);
        else
            mu(:,2)= mean(train_patterns(:,in)')';
        end
    else % d1 daha yakin
        targets(1)=1;
        if length(in) == 1,
            mu(:,1)= train_patterns(:,in);
        else
            mu(:,1)= mean(train_patterns(:,in)')';
        end
    end
end
if (sum(targets)==2) % ikiside 1 se
    in = find(train_targets == 0);
    uz=length(in);
    d1=train_patterns(:,in)-mu(:,1)*ones(1,uz);
    d1=sum(sqrt(sum(d1.*d1)));
    %d1=sum(dist(mu(:,1),train_patterns(:,in)));
    d2=train_patterns(:,in)-mu(:,2)*ones(1,uz);
    d2=sum(sqrt(sum(d2.*d2)));
    %d2=sum(dist(mu(:,2),train_patterns(:,in)));
    if d1>d2 % d2 daha yakin
        targets(2)=0;
        if length(in) == 1,
            mu(:,2)= train_patterns(:,in);
        else
            mu(:,2)= mean(train_patterns(:,in)')';
        end
    else % d1 daha yakin
        targets(1)=0;
        if length(in) == 1,
            mu(:,1)= train_patterns(:,in);
        else
            mu(:,1)= mean(train_patterns(:,in)')';
        end
    end
end
patterns=mu;