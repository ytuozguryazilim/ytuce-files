function agac = prunit2(agac,prune_patterns, prune_targets)
% yukaridan baslayarak cocugu yaprak olan ve hatayi duzleten ilk node u prune eder.
if agac.yaprak==0  % yaprak sa
    agac=agac;    
else
    %agaci yedekle
    yed_agac=agac;
    %agaci prune et
    agac.yaprak=0;
    
    sifirlar=find(prune_targets==0);
    birler=find(prune_targets==1);
    [x sifirsayi]=size(sifirlar);
    [x birsayi]=size(birler);
    if (sifirsayi<birsayi)
        agac.isaret=1;
    else
        agac.isaret=0;
    end
    
    % her iki agacin (prune edilmis ve edilmemisin) performanslarini olc
    [ boyut orneksayi]=size(prune_patterns);
    topps=0;
    topss=0;
    for i=1:orneksayi
        pattern=prune_patterns(:,i);
        ps=agac_kullan_yaprak(pattern',agac);
        ss=agac_kullan_yaprak(pattern',yed_agac);
        if prune_targets(i)==ps
            topps=topps+1;
        end
        if prune_targets(i)==ss
            topss=topss+1;
        end
    end
    
    yed_agac1=agac.as;
    yed_agac2=agac.yu;

    if (yed_agac1.yaprak==0) | (yed_agac2.yaprak==0)
        enaz_biri_yaprak=1;
    else
        enaz_biri_yaprak=0; % 
    end
    if (yed_agac1.yaprak==0) & (yed_agac2.yaprak==0)
        ikisi_yaprak=1;
    else
        ikisi_yaprak=0;
    end
    
    
    if (topps>topss) & (ikisi_yaprak==1) % prune nun performansi daha iyi ise ve node un her iki koluda yaprak ise
        agac=agac;
    else % degilse dallarina git
            agac=yed_agac;
            prune_patterns=prune_patterns';
            yukari=[];
            asagi=[];
            asagi_target=[];
            yukari_target=[];
            for j=1:orneksayi
                nokta=prune_patterns(j,:);
                isaret=sum(agac.params.*nokta);
                isaret=isaret-agac.params(boyut)*nokta(boyut);
                isaret=isaret+agac.params(boyut);        
                isaret=sign(nokta(boyut)-isaret);
                if (isaret==1) %dogrunun yukarisinda 
                    yukari=[yukari nokta']; 
                    yukari_target=[yukari_target prune_targets(j)];
                else
                    asagi=[asagi nokta'];
                    asagi_target=[asagi_target prune_targets(j)];
                end
            end 
    
            % her bir kola o tarafa dusenleri yolladik
            agac.as=prunit(yed_agac.as,asagi, asagi_target);
            agac.yu=prunit(yed_agac.yu,yukari, yukari_target);
    end
end