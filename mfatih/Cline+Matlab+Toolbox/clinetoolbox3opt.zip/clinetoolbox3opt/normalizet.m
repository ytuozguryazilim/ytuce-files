function [Ntrain_patterns,Ntest_patterns] = normalizet(train_patterns, test_patterns)
[ozsayisi k]=size(train_patterns);
Ntrain_patterns=[];
Ntest_patterns=[];
for i=1:ozsayisi
    m1=mean(train_patterns(i,:));
    std1=std(train_patterns(i,:));
    if (std1==0) 
        Ntrain_patterns(i,:)=train_patterns(i,:);
        Ntest_patterns(i,:)=test_patterns(i,:);
    else
        Ntrain_patterns(i,:)=(train_patterns(i,:)-m1)./std1;
        Ntest_patterns(i,:)=(test_patterns(i,:)-m1)./std1;
    end
end
%Ntrain_patterns=zscore(train_patterns);
%Z = (V-mean(V))./std(V)
%Ntest_patterns=zscore(test_patterns);