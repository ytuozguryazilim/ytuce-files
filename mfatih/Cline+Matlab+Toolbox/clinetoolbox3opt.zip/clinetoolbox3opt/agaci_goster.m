function yapi = agaci_goster(agac,yapi,seviye)
if agac.yaprak==0 
    yapi=[ yapi, '*'];
    %seviye
else
    a=agac.yu;
    yapi=[agaci_goster(a,yapi,seviye+1),'1'];
    a=agac.as;
    yapi=[agaci_goster(a,yapi,seviye+1),'2'];
end