function varargout = clinetoolbox(varargin)
% CLINETOOLBOX M-file for clinetoolbox.fig
%      CLINETOOLBOX, by itself, creates a new CLINETOOLBOX or raises the existing
%      singleton*.
%
%      H = CLINETOOLBOX returns the handle to a new CLINETOOLBOX or the handle to
%      the existing singleton*.
%
%      CLINETOOLBOX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CLINETOOLBOX.M with the given input arguments.
%
%      CLINETOOLBOX('Property','Value',...) creates a new CLINETOOLBOX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before clinetoolbox_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to clinetoolbox_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help clinetoolbox

% Last Modified by GUIDE v2.5 27-Feb-2006 12:47:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @clinetoolbox_OpeningFcn, ...
                   'gui_OutputFcn',  @clinetoolbox_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before clinetoolbox is made visible.
function clinetoolbox_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to clinetoolbox (see VARARGIN)

% Choose default command line output for clinetoolbox
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes clinetoolbox wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = clinetoolbox_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function YuzdeEdit_Callback(hObject, eventdata, handles)
% hObject    handle to YuzdeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of YuzdeEdit as text
%        str2double(get(hObject,'String')) returns contents of YuzdeEdit as a double


% --- Executes during object creation, after setting all properties.
function YuzdeEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to YuzdeEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function DataEdit_Callback(hObject, eventdata, handles)
% hObject    handle to DataEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of DataEdit as text
%        str2double(get(hObject,'String')) returns contents of DataEdit as a double


% --- Executes during object creation, after setting all properties.
function DataEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to DataEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function TestEdit_Callback(hObject, eventdata, handles)
% hObject    handle to TestEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of TestEdit as text
%        str2double(get(hObject,'String')) returns contents of TestEdit as a double


% --- Executes during object creation, after setting all properties.
function TestEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to TestEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function PrePruneEdit_Callback(hObject, eventdata, handles)
% hObject    handle to PrePruneEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PrePruneEdit as text
%        str2double(get(hObject,'String')) returns contents of PrePruneEdit as a double


% --- Executes during object creation, after setting all properties.
function PrePruneEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PrePruneEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in postPrunePop.
function postPrunePop_Callback(hObject, eventdata, handles)
% hObject    handle to postPrunePop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns postPrunePop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from postPrunePop


% --- Executes during object creation, after setting all properties.
function postPrunePop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to postPrunePop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in hiperPop.
function hiperPop_Callback(hObject, eventdata, handles)
% hObject    handle to hiperPop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns hiperPop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from hiperPop


% --- Executes during object creation, after setting all properties.
function hiperPop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to hiperPop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in dalyaprakPop.
function dalyaprakPop_Callback(hObject, eventdata, handles)
% hObject    handle to dalyaprakPop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns dalyaprakPop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from dalyaprakPop


% --- Executes during object creation, after setting all properties.
function dalyaprakPop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dalyaprakPop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function agacsayiEdit_Callback(hObject, eventdata, handles)
% hObject    handle to agacsayiEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of agacsayiEdit as text
%        str2double(get(hObject,'String')) returns contents of agacsayiEdit as a double


% --- Executes during object creation, after setting all properties.
function agacsayiEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to agacsayiEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in popupmenu4.
function popupmenu4_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns popupmenu4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu4


% --- Executes during object creation, after setting all properties.
function popupmenu4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function ozelliksayiEdit_Callback(hObject, eventdata, handles)
% hObject    handle to ozelliksayiEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ozelliksayiEdit as text
%        str2double(get(hObject,'String')) returns contents of ozelliksayiEdit as a double


% --- Executes during object creation, after setting all properties.
function ozelliksayiEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ozelliksayiEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on button press in siniflandirBut.
function siniflandirBut_Callback(hObject, eventdata, handles)
% hObject    handle to siniflandirBut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%val=get(hObject,'String');

h = findobj('Tag','hiperPop');
hipermetot=get(h,'Value');

hipermetotlar={'Cline_agacNdim_v5s' 'Cline_agacNdim_v10' 'Cline_agacNdim_v5xx' 'Cline_agacNdim_LVQ2' 'Cline_agacNdim_LDAp'...
          'Cline_agacNdim_MIX' 'Cline_agacNdim_v5xx_Forest' 'Cline_agacNdim_LVQ_Forest' 'Cline_agacNdim_LDA_Forest' 'Cline_agacNdim_MIX_Forest' };

moreclass=str2func('Cline_agacNdimNclass_1vs1');
twoclass=str2func(char(hipermetotlar{hipermetot}))

h = findobj('Tag','DataEdit');
dataisim=get(h,'String');

% dosya mat ise load ile txt ise dlmread ile oku
if dataisim(length(dataisim)-2:end)=='mat'
    load (char(dataisim));
else
    dataset=dlmread(char(dataisim));
end

h = findobj('Tag','TestEdit');
testisim=get(h,'String');

if length(testisim{1})==9 %testisim(1:end)=='Edit Text' % test dosyasi girilmemisse
    
    [orneksayi boyut]=size(dataset);
    h = findobj('Tag','YuzdeEdit');
    testoran=str2num(get(h,'String'))/100;

    egitsayi=ceil(orneksayi*(1-testoran));

    % patterns i sinilarin sirali olma ihtimaline karsi reorder et.
    ysira=randperm(orneksayi);
    dataset=dataset(ysira,:);  % satirlari yer degistir

    if length(find(dataset(:,boyut)==0))>1 % siniflar 0 - 1 seklindeyse 1 - 2 ye cevir
    dataset(:,boyut)=dataset(:,boyut)+1;
    end

    egit=dataset(1:egitsayi,1:boyut-1)';
    egitT=dataset(1:egitsayi,boyut)';
    test=dataset(egitsayi+1:orneksayi,1:boyut-1)';
    testT=dataset(egitsayi+1:orneksayi,boyut)';
    
    testorneksayi=orneksayi-egitsayi; 
else % test datasi girilmi��se
    % test dosyasi simdilik txt olmak zorunda 
    
    testset=dlmread(char(testisim));
    
    [egitsayi boyut]=size(dataset);
    [testorneksayi boyut]=size(testset);
    
    if length(find(dataset(:,boyut)==0))>1 % siniflar 0 - 1 seklindeyse 1 - 2 ye cevir
    dataset(:,boyut)=dataset(:,boyut)+1;
    end
    
    if length(find(testset(:,boyut)==0))>1 % siniflar 0 - 1 seklindeyse 1 - 2 ye cevir
    testset(:,boyut)=testset(:,boyut)+1;
    end
    
    egit=dataset(:,1:boyut-1)';
    egitT=dataset(:,boyut)';
    test=testset(:,1:boyut-1)';
    testT=testset(:,boyut)';
    
    
end

[egit, test]=normalizet(egit,test);


% parametreler
% prp    preprun orani
% psp    post pruning var mi 1 var 0 yok
% DY    dal/ yaprak  1 dal   0 yaprak
% FA    forestsa agac sayisi
% FF    forestsa ozellik sayisi

h = findobj('Tag','PrePruneEdit');
prp=str2num(get(h,'String'));
h = findobj('Tag','PostPrunePop');
psp=get(h,'Value');
h = findobj('Tag','dalyaprakPop');
DY=get(h,'Value');
h = findobj('Tag','agacsayiEdit');
FA=str2num(get(h,'String'));
h = findobj('Tag','ozelliksayituruPop');
FE=get(h,'Value');
% FE=1 ise 1 * XX  
% FE=2 ise log2(boyut) * XX
h = findobj('Tag','ozelliksayiEdit');
FT=str2num(get(h,'String'));
if FE==1 
    FF=FT;
else
    FF=FT*ceil(log2(boyut));
end

algoritmaparametreleri=[prp psp DY FA FF]
[Yc ort_tree_size] =feval(moreclass,egit, egitT, test, algoritmaparametreleri,twoclass); 
[yuzdebasari confmatrix ]= sonuclari_al(testT,Yc);

disp(yuzdebasari);  
disp('rows correspond to actual classes and columns correspond to estimated classes');
disp(confmatrix);

h = findobj('Tag','sonuclarEdit');
sinifsayisi=length(unique(egitT));
confmat=cell(1,sinifsayisi);
for i=1:sinifsayisi
    confmat{i}=mat2str(confmatrix(i,:),3);
end
%confmat={mat2str(confmatrix(1,:),3),mat2str(confmatrix(2,:),3)};

ert={'Egitim Ornek Sayi:',egitsayi,'Test Ornek Sayi',testorneksayi,'Ozellik Sayisi:',boyut-1,...
     'Sinif Sayisi:',sinifsayisi,'Algoritma:',char(hipermetotlar{hipermetot}),'Basari yuzdesi',yuzdebasari};
set(h,'String',ert);
h = findobj('Tag','confEdit');
set(h,'String',confmat);

% --- Executes on selection change in listbox4.
function listbox4_Callback(hObject, eventdata, handles)
% hObject    handle to listbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox4 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox4


% --- Executes during object creation, after setting all properties.
function listbox4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end




% --- Executes on selection change in PostPrunePop.
function PostPrunePop_Callback(hObject, eventdata, handles)
% hObject    handle to PostPrunePop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns PostPrunePop contents as cell array
%        contents{get(hObject,'Value')} returns selected item from PostPrunePop


% --- Executes during object creation, after setting all properties.
function PostPrunePop_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PostPrunePop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end





function confEdit_Callback(hObject, eventdata, handles)
% hObject    handle to confEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of confEdit as text
%        str2double(get(hObject,'String')) returns contents of confEdit as a double


% --- Executes during object creation, after setting all properties.
function confEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to confEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


