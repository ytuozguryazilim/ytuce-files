function target = agac_kullan_dal(pattern,agac,sinif_dagilimlari)
[ x boyut ]=size(pattern);
if agac.yaprak==0
    %direkt isarete bakmak yerine ustteki dugumlerdeki sinif dagilimlarina da bakilir
    %target=agac.isaret;
    sinif_dagilimlari=[sinif_dagilimlari agac.birincisinifsayi agac.ikincisinifsayi];
    sdL=length(sinif_dagilimlari);
    % sondan_kac_oran_alinsin=6 daha iyi
    sondan_kac_oran_alinsin=3;
    if sdL<(sondan_kac_oran_alinsin*2) 
        target=agac.isaret;
    else
        % toplamlari bul
        %sifirtop=sinif_dagilimlari(sdL-1)+sinif_dagilimlari(sdL-3)+sinif_dagilimlari(sdL-5)+sinif_dagilimlari(sdL-7);
        %birtop=sinif_dagilimlari(sdL)+sinif_dagilimlari(sdL-2)+sinif_dagilimlari(sdL-4)+sinif_dagilimlari(sdL-6);
        
        %sifirtop=(sinif_dagilimlari(sdL-3)/(sinif_dagilimlari(sdL-3)+sinif_dagilimlari(sdL-2)))+(sinif_dagilimlari(sdL-1)/(sinif_dagilimlari(sdL)+sinif_dagilimlari(sdL-1)));
        %birtop=(sinif_dagilimlari(sdL-2)/(sinif_dagilimlari(sdL-3)+sinif_dagilimlari(sdL-2)))+(sinif_dagilimlari(sdL)/(sinif_dagilimlari(sdL)+sinif_dagilimlari(sdL-1)));
        
        %oranlari bul
        ty=1;
        zt=1;
        sifir_oranlar=[];
        bir_oranlar=[];
        while ty<=sdL
            sifir_oranlar(zt)=sinif_dagilimlari(ty)/(sinif_dagilimlari(ty)+sinif_dagilimlari(ty+1));
            bir_oranlar(zt)=1- sifir_oranlar(zt); 
            ty=ty+2;
            zt=zt+1;
        end
        

        sifirtop=0;
        birtop=0;
        for ty=(sdL/2)-sondan_kac_oran_alinsin+1:(sdL/2)
            sifirtop=sifirtop+sifir_oranlar(ty);
            birtop=birtop+bir_oranlar(ty);
        end
        
        if sifirtop>birtop 
            target=0;
        else
            target=1;
        end
    end
    
else

    
    isaret=0;
    for i=1:boyut-1
       isaret=isaret+agac.params(i)*pattern(i);
    end
    isaret=isaret+agac.params(boyut);
    isaret=sign(pattern(boyut)-isaret);
    
    if (isaret==1) %dogrunun yukarisinda 
            a=agac.yu;
    else
            a=agac.as;
    end
    target=agac_kullan_dal(pattern,a,[sinif_dagilimlari agac.birincisinifsayi agac.ikincisinifsayi]);
end
