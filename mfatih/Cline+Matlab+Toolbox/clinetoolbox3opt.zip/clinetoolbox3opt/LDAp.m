function [DS2, discrimVec] = LDA(DS, discrimVecNum)
%lda: Linear discriminant analysis
%	Usage:
%	[newSample, discrimVec] = lda(DS, discrimVecNum)
%	SAMPLE: Sample data with class information
%		(Each column of SAMPLE is a sample point, with the 
%		last row being the class label ranging from 1 to
%		no. of classes.)
%	discrimVecNum: No. of discriminant vectors
%	newSample: new sample after projection
%
%	Reference:
%	J. Duchene and S. Leclercq, "An Optimal Transformation for
%	Discriminant Principal Component Analysis," IEEE Trans. on
%	Pattern Analysis and Machine Intelligence,
%	Vol. 10, No 6, November 1988
%
%	Type "lda" for a self-demo.

%	Roger Jang, 19990829, 20030607

if nargin<1, selfdemo; return; end
if nargin<2, discrimVecNum=size(DS.input,1); end

% ====== Initialization
m = size(DS.input,1);	% Dimension of data point
n = size(DS.input,2);	% No. of data point
A = DS.input; 
classLabel = DS.output;
[diffClassLabel, classSize] = elementCount(classLabel);
classNum = length(diffClassLabel);
mu = mean(A, 2);

% ====== Compute B and W
% ====== B: between-class scatter matrix
% ====== W:  within-class scatter matrix
% M = \sum_k m_k*mu_k*mu_k^T
M = zeros(m, m);
for i = 1:classNum,
	index = find(classLabel==diffClassLabel(i));
	classMean = mean(A(:, index), 2);
	M = M + length(index)*classMean*classMean';
end
W = A*A'-M;
B = M-n*mu*mu';

% ====== Find the best discriminant vectors
invW = pinv(W);
%if invW==Inf invW=W;
%end
Q = invW*B;
D = [];
for i = 1:discrimVecNum
	[eigVec, eigVal] = eig(Q);
	[maxEigVal, index] = max(abs(diag(eigVal)));  
	D = [D, eigVec(:, index)];	% Each col of D is a eigenvector
	Q = (eye(m)-invW*D*inv(D'*invW*D)*D')*invW*B;
end
DS2=DS;
DS2.input = D(:,1:discrimVecNum)'*A; 
discrimVec = D;