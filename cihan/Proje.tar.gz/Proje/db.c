#include <stdio.h>

#include "ptypes.h"
#include "db.h"

FILE *openDB(char *fName) {

	printf("Openning DB file..\n");

	return NULL;
}


struct WORD *getWords(FILE *fi) {

	printf("Reading DB file..\n");

	return NULL;
}

