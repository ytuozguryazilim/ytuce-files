#ifndef __db_h__
#define __db_h__

#include <stdio.h>
#include "ptypes.h"

FILE *openDB(char *);
struct WORD *getWords(FILE *);


#endif

