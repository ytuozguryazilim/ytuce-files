#ifndef __text_h__
#define __text_h__

#include <stdio.h>

#include "ptypes.h"


FILE *openTxtFile(char *);



#endif

