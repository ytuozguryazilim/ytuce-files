#include <stdio.h>

#include "ptypes.h"
#include "text.h"


FILE *openTxtFile(char *fName) {

	printf("Openning Text file..\n");

}

