#include <stdio.h>

#include "ptypes.h"
#include "db.h"
#include "text.h"


int main(void)  {

	FILE *fTXT, *fDB;

	printf("Hello World...\n");

	fTXT = openTxtFile("Test.txt");
	fDB = openDB("test.db");

	return 0;
} 
