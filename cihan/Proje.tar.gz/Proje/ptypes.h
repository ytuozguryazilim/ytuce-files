#ifndef __ptypes_h__
#define __ptypes_h__

#define MAX_WORD_SIZE	32

struct WORD{

	char word[MAX_WORD_SIZE];
	unsigned int count;
};


#endif

