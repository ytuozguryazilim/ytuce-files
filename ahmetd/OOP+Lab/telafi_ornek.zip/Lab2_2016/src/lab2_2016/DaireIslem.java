/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2016;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author AHMET
 */
public class DaireIslem {

    private ArrayList<Daire> bekleyenDaireler;
    private ArrayList<Daire> islemDaireler;
    private double toplamKar;

    public DaireIslem(String yol1, String yol2) {
        File dosya1 = new File(yol1);
        File dosya2 = new File(yol2);

        if (dosya2.exists()) {
            bekleyenDaireler = listeyukle(yol1);
            islemDaireler = listeyukle(yol2);
            System.out.println("kayıtlı listeler yüklendi");
        } else if (dosya1.exists()) {
            bekleyenDaireler = listeyukle(yol1);
            islemDaireler = new ArrayList<Daire>();

        } else {
            bekleyenDaireler = new ArrayList<Daire>();
            islemDaireler = new ArrayList<Daire>();

            System.out.println("yeni liste olusturuldu");
        }
        for (Daire daire : islemDaireler) {
            toplamKar += daire.getkar();
        }
    }

    public ArrayList<Daire> getbekleyenDaireler() {
        return bekleyenDaireler;
    }

    public ArrayList<Daire> getislemDaireler() {
        return islemDaireler;
    }

    public double gettoplamKar() {
        return toplamKar;
    }

    public void listeyazdir(ArrayList<Daire> daireler) {
        if (daireler.isEmpty()) {
            System.out.println("liste boş.");
        }
        for (Daire daire : daireler) {
            System.out.println(daire);
        }

    }

    public boolean daireEkle(Daire daire) {

        if (bekleyendairebul(daire.getdaireId()) != null) {
            System.out.println("daire listede var");
            return false;
        } else {
            bekleyenDaireler.add(daire);
            System.out.println("daire bekleyen daireler listesine eklendi");
        }
        return true;
    }

    public Daire bekleyendairebul(String id) {
        for (Daire daire : bekleyenDaireler) {
            if (daire.getdaireId().compareTo(id) == 0) {
                return daire;
            }
        }
        return null;
    }

    public Daire islemdairebul(String id) {
        for (Daire daire : islemDaireler) {
            if (daire.getdaireId().compareTo(id) == 0) {
                return daire;
            }
        }
        return null;
    }

    public void islemYap(Daire daire, double indOrani) {
        if (islemdairebul(daire.getdaireId()) == null) {
            daire.setindirimOrani(indOrani);
            if (daire instanceof Satilik) {
                toplamKar += ((Satilik) daire).karHesabi(indOrani);
            } else {
                toplamKar += ((Kiralik) daire).karHesabi(indOrani);
            }
            islemDaireler.add(daire);
            bekleyenDaireler.remove(daire);
        }
    }

    public void listekaydet(String yol, ArrayList<Daire> daireler) {
        try {
            ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream(yol));
            stream.writeObject(daireler);
            System.out.println("kayıt yapıldı.");
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Daire> listeyukle(String yol) {
        ArrayList<Daire> daireler = new ArrayList<Daire>();
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream(yol));
            daireler = (ArrayList<Daire>) stream.readObject();
            System.out.println("satis veya kira icin bekleyen yüklendi.");
            stream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException cle) {
            cle.printStackTrace();
        }
        return daireler;
    }

    public String toString() {
        return "toplam yapılan kar: " + toplamKar;
    }
}
