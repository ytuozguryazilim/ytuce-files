/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2016;

/**
 *
 * @author AHMET
 */
public class Lab2_2016 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        
       String yol1="bekleyenDaireler.dat";
       String yol2="islemDireler.dat";
       DaireIslem islem=new DaireIslem(yol1,yol2);
        
        Kiralik kr1,kr2;
        Satilik st1,st2;
        kr1=new Kiralik("k1", 1000);
        kr2=new Kiralik("k2", 1500);
        
        st1=new Satilik("s1", 100000);
        st2=new Satilik("s2", 300000);
        
        
        islem.daireEkle(kr1);
        islem.daireEkle(kr2);
        islem.daireEkle(st1);
        islem.daireEkle(st2);
        
        System.out.println("hazırda bekleyen daireler");
        islem.listeyazdir(islem.getbekleyenDaireler());
        
        islem.listekaydet(yol1,islem.getbekleyenDaireler());
        islem.listekaydet(yol2,islem.getislemDaireler());
        
        islem.islemYap(kr2, 0);
        islem.islemYap(st2, .1);
        islem.listekaydet(yol1,islem.getbekleyenDaireler());
        islem.listekaydet(yol2,islem.getislemDaireler());
        
        System.out.println("islem yapılmıs daireler");
        islem.listeyazdir(islem.getislemDaireler());
        System.out.println(islem);
        
        System.out.println("hazırda bekleyen daireler");
        islem.listeyazdir(islem.getbekleyenDaireler());
        
    }
    
}
