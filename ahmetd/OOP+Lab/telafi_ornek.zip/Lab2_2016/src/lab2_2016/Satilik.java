/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2016;

/**
 *
 * @author AHMET
 */
public class Satilik extends Daire{

public Satilik(String daireId,double deger){
super(daireId,deger);
}  
    
public double karHesabi(double indOrani){

super.setkar(super.getdeger()*(1-indOrani)*0.05);
return super.getkar();
}
public String toString(){

return super.toString()+"  "+Double.toString(super.getkar());
}
}
