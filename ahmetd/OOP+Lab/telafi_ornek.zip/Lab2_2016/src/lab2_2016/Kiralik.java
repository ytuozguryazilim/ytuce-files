/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2016;

/**
 *
 * @author AHMET
 */
public class Kiralik extends Daire{

    

public Kiralik(String daireId,double deger){
super(daireId,deger);
}  
    
public double karHesabi(double indOrani){
super.setkar(super.getdeger()*(1-indOrani));
return super.getkar();
}

public String toString(){
return super.toString()+"    "+Double.toString(super.getkar());
}

}
