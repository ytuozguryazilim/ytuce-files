/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_2016;

import java.io.Serializable;

/**
 *
 * @author AHMET
 */
public abstract class Daire implements Serializable{
    private static final long serialVersionUID=1L;
    private String daireId;
    private double deger;
    private double indirimOrani;
    private double kar;
    
    public Daire(String daireId,double deger){
    this.daireId=daireId;
    this.deger=deger;
    this.indirimOrani=0;
    }
    
    public void setdaireId(String daireID){this.daireId=daireID;}
    public void setdeger(double deger){this.deger=deger;}
    public void setindirimOrani(double indirimOrani){this.indirimOrani=indirimOrani;}
    public void setkar(double kar){this.kar=kar;}
    
    public String getdaireId(){return this.daireId;}
    public double getdeger(){return this.deger;}
    public double getindirimOrani(){return this.indirimOrani;}
    public double getkar(){return this.kar;}
    
    public abstract double karHesabi(double indOrani);
    
    public String toString(){
    return daireId+"  "+deger+"  "+indirimOrani;
    }
    
}
