#ifndef __stipler_h__
#define __stipler_h__

struct Yazar{
	char ad[32];
	char soyad[64];
	int id;	
};

struct Kitap{
	char k_ad[32];
	int ISBN;
	float fiyat;
	int y_id;
};
#endif
