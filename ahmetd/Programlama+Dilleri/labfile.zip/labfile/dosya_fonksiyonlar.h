#ifndef __dosya_fonksiyonlar_h__
#define __dosya_fonksiyonlar_h__

void y_ekle(struct Yazar *);

void y_ekrana_yazdir();

void k_ekle(struct Kitap *);

void k_ekrana_yazdir(int);


#endif
