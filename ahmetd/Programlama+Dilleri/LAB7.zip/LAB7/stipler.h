#ifndef __stipler_h__
#define __stipler_h__
#define m_boyut 100

struct Dizi_Ozellik{
	char dizi[m_boyut];
	int a_f;
	int t_f;
	int c_f;
	int g_f;
};


#endif
