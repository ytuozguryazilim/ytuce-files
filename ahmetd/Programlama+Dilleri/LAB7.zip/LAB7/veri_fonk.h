#ifndef __veri_fonk_h__
#define __veri_fonk_h__

void * f_hesapla(void *); 

#endif
