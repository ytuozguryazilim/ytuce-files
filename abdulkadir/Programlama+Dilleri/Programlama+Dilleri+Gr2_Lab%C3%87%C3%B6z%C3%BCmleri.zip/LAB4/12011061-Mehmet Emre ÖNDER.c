#include<stdio.h>
#include<string.h>

struct kayit {
    char model[25];
    char marka[25];
    char plaka [25];
    char yil [25];
};
void menuHazirla();
int arabaEkle();
int arabaListesi();

void menuHazirla(){
        printf("\n\n\t\tAraba Listesi");
        printf("\n\t\t1-Yeni Araba Ekle");
        printf("\n\t\t2-Araba Goruntule");
        printf("\n\t\t3-Cikis");

}

int arabaEkle(){
struct kayit newcar;
FILE *ptVeri;

ptVeri=(fopen("arabaListesi.txt","a+"));
if(ptVeri==NULL){
    return -1;
}
        printf("\nModeli Giriniz: ");
        scanf("%s",&newcar.model);
        //printf("\n\n\t%s",newcar.model);
        printf("\nMarkayi Giriniz: ");
        scanf("%s",&newcar.marka);
        printf("\nPlakayi Giriniz: ");
        scanf("%s",&newcar.plaka);
        printf("\nYilini Giriniz: ");
        scanf("%s",&newcar.yil);
        fprintf(ptVeri,"\n%s\t%s\t%s\t%s",newcar.model,newcar.marka,newcar.plaka,newcar.yil);
    fclose(ptVeri);

return 0;
}

int arabaListesi(){
    struct kayit newcar;
    FILE *ptVeri;
        ptVeri=fopen("arabaListesi.txt","r+");
        printf("\n\n\tModel\tMarka\tPlaka\tYil\n");

        fscanf(ptVeri,"\n%s\t%s\t%s\t%s",&newcar.model,&newcar.marka,&newcar.plaka,&newcar.yil);
        printf("\t%s",newcar.model);
        printf("\t%s",newcar.marka);
        printf("\t%s",newcar.plaka);
        printf("\t%s",newcar.yil);
        fclose(ptVeri);
return 0;
}


int main (){
    int secim=0;
do{
menuHazirla();
printf("\n Seciminiz: ");
scanf("%d",&secim);
if(secim>3 || secim<0){
    printf("Lutfen 1-3 arasinda bir secim giriniz: ");
    scanf("%d",&secim);
}
switch(secim){
    case 1: if(arabaEkle()==0){
    }
    break;
    case 2: arabaListesi();
            break;
    case 3: printf("Program Bitti.");
 break;
 }
}
while(secim<=2);

return 0;}
