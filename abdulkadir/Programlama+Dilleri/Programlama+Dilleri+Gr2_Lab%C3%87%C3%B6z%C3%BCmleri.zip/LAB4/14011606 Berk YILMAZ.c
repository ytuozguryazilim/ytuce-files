#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

typedef struct{
	char ad[10], soyad[20];
	int notu;
}ogrenci;

int main(){
	int secim;
	ogrenci *ogrenciler;
	int sayi=0, toplam=0, ortalama;
	int i;

while(secim!=3){
	
	printf("\n\n***Menu***\n\n1.Ogrenci eklemek icin\n2.Goruntulemek icin\n3.Cikis\n\n");
	scanf("%d",&secim);
	
	if(secim==1){
		printf("\nOgrenci sayisini giriniz: ");
		scanf("%d",&sayi);
		
		ogrenciler=(ogrenci*)malloc(sayi*sizeof(ogrenci));
		
		if(ogrenciler==NULL){
			printf("Hata meydana geldi!");
			exit(1);
		}
		
		for(i=0; i<sayi; i++){
			printf("\n%d. ogrencinin adini giriniz: ",i+1);
			scanf("%s",&ogrenciler[i].ad);
			printf("\n%d. ogrencinin soyadini giriniz: ",i+1);
			scanf("%s",&ogrenciler[i].soyad);
			printf("\n%d. ogrencinin notunu giriniz: ",i+1);
			scanf("%d",&ogrenciler[i].notu);
			
			toplam+=ogrenciler[i].notu;	
		}
		
		ortalama=toplam/sayi;
		printf("\n\nOgrenciler basariyla eklendi.\n\n");
	}
	
	if(secim==2){
		for(i=0; i<sayi; i++){
			printf("\n%d. ogrencinin notu: %d\n",i+1,ogrenciler[i].notu);
		}
		
		printf("\n\n\nOgrencilerin not ortalamasi: %d\n",ortalama);
		
	}
	
}
	
	free(ogrenciler);
	
	getch();
	return 0;
}
