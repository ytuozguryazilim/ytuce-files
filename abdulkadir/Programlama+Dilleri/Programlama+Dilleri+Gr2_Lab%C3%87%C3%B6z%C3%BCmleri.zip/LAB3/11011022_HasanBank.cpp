#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct {
	int id;
	char isim[16];
	char soyisim[16];
}Contact;

Contact *veriEkle()
{
	int n,i;
	Contact *str;
	printf("How many people will you add:");
	scanf("%d",&n);
	
	str=(Contact *)malloc (n*sizeof(Contact));
	
	for(i=0;i<n;i++)
	{	
		printf("%d.Contact Information:\n",i+1);
		printf("ID:");
		scanf("%d",&str[i].id);
		printf("FirstName:\n");
		scanf("%s",&str[i].isim);
		printf("Surname:");
		scanf("%s",&str[i].soyisim);
		printf("\n");
	}
    return str;
}

void Arama(Contact str[])
{
	int i,j,k;
	i=0;
	j=0;
	k=0;
	char key[32];
	
	printf("Enter the word to find in contacts:");
	scanf("%s",&key);
	
	while( (str[i].id!='\0') )
	{
	   if( key[j]==str[i].isim[k] )
	      j++;
	   else
	     {
	      j=0;
		 }
		k++;     
	   
	   if( key[j] =='\0' )
	   {
	    printf("ID:%d\n",str[i].id);
	    printf("Name:%s\n",str[i].isim);
	    printf("LastName:%s\n",str[i].soyisim);
		k=0;
	    i++;
	    j=0;
	   }
	   if (str[i].isim[k]=='\0')
	     {
	      i++;
	      k=0;
	      j=0;
	      
		}
	
	}
}

int main()
{
	int x;
	Contact *adr;	
	
	
	printf("To enter contact , press key 1\n");
	printf("To search contact , press key 2\n");
	printf("To exit,press key 0\n");
	
	while (x!=0)
	{
	  printf("Make your choice:");	
	 scanf("%d",&x);
	
	if( x== 1)
	 adr=veriEkle();
	 
	 printf("%d %s %s",adr[0].id,adr[0].isim,adr[0].soyisim);
	if( x==2 )
	  Arama(adr);
	
	}
	
	
	
	
	
}
