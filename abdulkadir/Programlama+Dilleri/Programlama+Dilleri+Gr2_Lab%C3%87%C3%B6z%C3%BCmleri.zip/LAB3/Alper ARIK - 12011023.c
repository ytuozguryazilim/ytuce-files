#include <stdio.h>
#include <stdlib.h>
#include<string.h>

struct contact {
	char cepNo[16];
	char ad[20];
	char soyad[20];
};


struct contact* contactOlustur( int);
void kelimeAra(char * ,int ,struct contact *);

int main() {
	int n,i;
	char kontrol,kelime[20];
	struct contact *rehber;
do{	
	printf("\n\n1.Veri ekleme");
	printf("\n2.Arama");
	printf("\n3.Cikis");
	scanf("%c",&kontrol);
	printf("\n\n\n\n\n\n\n\n\n");
	
	if(kontrol=='1'){
		printf("\n\nKac kisi ekleyeceksiniz.");
		scanf("%d",&n);
		rehber=contactOlustur(n);
		for(i=0;i<n;i++){
			printf("\n%d. kisinin cep telefonunu giriniz:",i+1); 	scanf("%s",rehber[i].cepNo);
			printf("\n%d. ki�inin adini giriniz",i+1);				scanf("%s",rehber[i].ad);
			printf("\n%d. kisinin soyadini giriniz:",i+1);			scanf("%s",rehber[i].soyad);
		}
	}
	
	else if(kontrol=='2'){
		printf("Aranacak kelimeyi giriniz:");	scanf("%s",kelime); 
		kelimeAra(kelime,n,rehber);
	}
	
}while(kontrol!='3');

	return 0;
}

struct contact* contactOlustur(int n){
	struct contact *rehber;
	rehber=(struct contact*)malloc(n*sizeof(struct contact));
	return rehber;
}

void kelimeAra(char * kelime,int n,struct contact *rehber){
	int i,j,k,count=0,bul=0;
	
	for(k=0;k<n;k++){
		i=0;	j=0;
		//ad arama
		while(kelime[i]!='\0' && rehber[k].ad[j]!='\0' ){
			if(rehber[k].ad[j]==kelime[i]){
				count++;
				i++;
				j++;
			}
			else{
				i=0;
				count=0;
				j++;
			}
			
		}
		if(count==strlen(kelime)){
			printf("\nBulunan ki�i : %s \t %s",rehber[k].ad,rehber[k].soyad);
			bul=1;
		}

		//soyad arama
		i=0;j=0;
		while( rehber[k].soyad[j]!='\0' && kelime[i]!='\0'){
			if(rehber[k].soyad[j]==kelime[i]){
				count++;
				i++;
				j++;
			}
			else{
				i=0;
				count=0;
				j++;
			}
		}
		if(count==strlen(kelime)){
			printf("\nBulunan ki�i : %s \t %s",rehber[k].ad,rehber[k].soyad);
			bul=1;
		}
	}
	
	if(bul==0)
	printf("\nAranan kisi bulunamadi");
}

