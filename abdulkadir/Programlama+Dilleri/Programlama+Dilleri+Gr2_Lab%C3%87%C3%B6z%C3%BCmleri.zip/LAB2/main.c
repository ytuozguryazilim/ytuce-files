#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
struct ROOM{
	int width,lenght,hight;
	char name[20];
};
struct home{
	char address[100];
	struct ROOM room[10];
};


int main(int argc, char *argv[]) {
	struct home ev[10];
	int od,i,es,j;
	pr�ntf("Pouya Yavari\n13011907\n\n\n");
	printf("kac ev tanimliyicaksiniz.\n");
	scanf("%d",&es);
	for(j=1;j<=es;j++){
		printf("%d sayili ev icin kac oda tanimliyicaksiniz.\n",j);
		scanf("%d",&od);
		for(i=1;i<=od;i++){
			printf("%d sayili evin %d sayili odanin adini girin.\n",j,i);
			scanf("%s", &ev[j].room[i].name);
			printf("\n%d sayili evin %d sayili odanin uzunlugunu girin.\n",j,i);
			scanf("%d",&ev[j].room[i].width);
			printf("\n%d sayili evin %d sayili odanin genisligini girin.\n",j,i);
			scanf("%d",&ev[j].room[i].lenght);
			printf("\n%d sayili evin %d sayili odanin yuksekligini girin.\n",j,i);
			scanf("%d",&ev[j].room[i].hight);
		}
	}
	system("cls");
	for(j=1;j<=es;j++){
		printf("\nHOME NO.	ROOM NO.	WIDTH	LENGHT	HIGHT		  NAME");
		for(i=1;i<=od;i++){
			printf("\n 	%d   		%d     	 %d 	  %d  	  %d		 %s",j,i,ev[1].room[i].width,ev[1].room[i].lenght,ev[1].room[i].hight,ev[1].room[i].name);
		}
	}
		return 0;
}
