#include <stdio.h>
#include <stdlib.h>

typedef struct {
	char name[16];
	int uzunluk,genislik,yukseklik;
}ROOM;
struct home{
	char adres[20];
	ROOM  ev;
};

struct ar* ev_olustur(int n)
{
	struct home *ar;
	ar=(struct home*)malloc (n*sizeof(struct home));
	if(ar==NULL)
	{
		printf("Dizi Olusturulamad�");
		return -1;
	}
	return ar;
}

void sethome(int n,int oda_sayisi, struct home *ar)
{
;
	
	
	int i,j;
	for(i=0;i<n;i++)
	{
		printf("\n%d. evin adresini giriniz: ",i+1);
		scanf("%s",&ar[i].adres);
		
		for(j=0;j<oda_sayisi;j++)
		{
	
	
		
		printf("\n%d. Odanin adini giriniz: ",j+1);
		scanf("%s",&ar[i].ev.name);
		
		printf("\n%d. odanin uzunlugunu girini: ",j+1);
		scanf("%d",&ar[i].ev.uzunluk);
		
		printf("\n%d. odanin genisligini giriniz: ",j+1);
	    scanf("%d",&ar[i].ev.genislik);
		
		printf("\n%d. odanin yuksekliginigiriniz: ",j+1);
		scanf("%d",&ar[i].ev.yukseklik);
			}
	}
}

void gethome(int n,int oda_sayisi, struct home *ar)
{
	int i,j;
	for(i=0;i<n;i++)
	{	
	printf("%d. evin adresi: %s",i+1,ar[i].adres);
			for(j=0;j<oda_sayisi;j++)
		{
	
	
		printf("\n%d. Odanin adi: %s",j+1,ar[i].ev.name);
		printf("\n%d. odanin uzunlu:%d ",j+1,ar[i].ev.uzunluk);
		printf("\n%d. odanin genisligi:%d",j+1,ar[i].ev.genislik);
	    printf("\n%d. odanin yuksekligi:%d",j+1,ar[i].ev.yukseklik);
		
		}
		
	}
}
int main()
{
	int n;
	int oda_sayisi=0;
	
	struct home *ar;
	printf("Ev Sayisini Giriniz:");
	scanf("%d",&n);
	printf("oda Sayisini Giriniz:");
	scanf("%d",&oda_sayisi);
	ar=ev_olustur(n);
	sethome(n,oda_sayisi,ar);
	gethome(n,oda_sayisi,ar);
}

