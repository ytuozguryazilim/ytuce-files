#include<stdio.h>


struct room {
float width,length,height;
char name[10];

};
struct home{
char adress[100];
struct room rooms[5];
int roomnumber;
};

struct home fromuser()
{
    struct home home1;
    int i;
    printf("\n How many room are there in this home?\n");
    scanf("%d",&home1.roomnumber);
    for(i=1;i<=home1.roomnumber;i++)
    {
        printf("\n Please enter the name of %d.st room\n",i);
        scanf("%s",home1.rooms[i].name);
        printf("\n Please enter the width of %d.st room\n",i);
        scanf("%f",&home1.rooms[i].width);
        printf("\n Please enter the length of %d.st room\n",i);
        scanf("%f",&home1.rooms[i].length);
        printf("\n Please enter the height of %d.st room\n",i);
        scanf("%f",&home1.rooms[i].height);
    }
     printf("\n Please enter the adress of this house\n");
     scanf("%s",home1.adress);

     return home1;
}
void output(struct home home1)
{

    int i;
    printf("\n\t NAME\t  WIDTH  \tLENGTH\t    HEIGHT\n");
    for(i=1;i<=home1.roomnumber;i++)
    {

    printf("ROOM %d:\t%s\t%f\t%f\t%f\n",i,home1.rooms[i].name,home1.rooms[i].width,home1.rooms[i].length,home1.rooms[i].height);
    }
printf("\nAdress of this house:  %s\n",home1.adress);
return;

}

int main()
{
    struct home fromuser();
    void output(struct home);
    struct home home1;
    home1=fromuser();
    output(home1);




return 0;
}
