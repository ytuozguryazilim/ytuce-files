#include <stdio.h>

struct Room
{
    int width, height, length;
    char name[10] ;
};

struct Home
{
    char adress[25];
    int roomNumber;
    struct Room *room;
};


int main(void)
{
    int homeNumber, i, j;
    printf("Kac tane ev oldugunu giriniz: ");
    scanf("%d", &homeNumber);
    struct Home *homes = (struct Home*) malloc(homeNumber * sizeof(struct Home));

    for(i = 0; i < homeNumber; i++)
    {
        printf("%d. evin kac odasi oldugunu yaziniz: ", i+1);
        scanf("%d", &homes[i].roomNumber);

        homes[i].room = malloc(homes[i].roomNumber * sizeof(struct Room));
        printf("Evin adresini yaziniz : ");

        scanf("%s", &homes[i].adress);
        for(j = 0; j < homes[i].roomNumber; j++)
        {
            printf("%d. odanin sirasiyla odanin adi, width'i, height'i, length'i giriniz\n", j+1);
            scanf("%s", &homes[i].room[j].name);
            scanf("%d", &homes[i].room[j].width);
            scanf("%d", &homes[i].room[j].height);
            scanf("%d", &homes[i].room[j].length);
        }

    }

    for(i = 0; i < homeNumber; i++)
    {
        printf("House %d\n", i + 1);
        printf("Adress : %s\n", homes[i].adress);
        for(j = 0; j < homes[i].roomNumber; j++)
        {
            printf("Room %d\n", j + 1);
            printf("name: %s\n height: %d\n length: %d\n width: %d\n", homes[i].room[j].name, homes[i].room[j].height, homes[i].room[j].length, homes[i].room[j].width);
        }

    }


}



