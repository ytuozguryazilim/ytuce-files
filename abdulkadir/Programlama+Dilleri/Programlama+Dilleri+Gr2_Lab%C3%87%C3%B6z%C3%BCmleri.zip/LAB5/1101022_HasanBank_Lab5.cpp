#include<stdio.h>
#include<stdlib.h>
struct Ogrenci{
	
	char name[32];
	int puan;
	struct Ogrenci *sonraki ;
};



struct Ogrenci * Ekle(struct Ogrenci *goz)
{
	struct Ogrenci * tmp;
	struct Ogrenci * yeni;
	yeni=(struct Ogrenci *)malloc(sizeof(struct Ogrenci));

	
	printf("Eklemek istediginiz ogrencinin bilgileri:\n");
   
	
	
	if ( goz== NULL)
	{
	 goz=(struct Ogrenci*)malloc(sizeof(struct Ogrenci));	
	 printf("Adi:");
	 scanf("%s",goz->name);
	 printf("Notu:");
	 scanf("%d",&goz->puan); 
	 printf("test");
	 goz->sonraki=NULL;
	 
    }
    else
    {
     printf("Adi:");
	 scanf("%s",yeni->name);
	 printf("Notu:");
	 scanf("%d",&yeni->puan);
	 yeni->sonraki=NULL;
	 tmp=goz;
	 while(tmp->sonraki!=NULL) {
	 	tmp=tmp->sonraki;
	 	
	 }
      tmp->sonraki=yeni;	
	    
   }

	 return goz ;
    	
}

void print( struct Ogrenci *start){
	
	float ort=0;
	int kisi=0;	
	printf("ADI:\tNOTU:\n");
	while(start!=NULL)
	 { 
	 	kisi++;
	 	ort=ort+start->puan;
	   printf("%s\t%d\n",start->name,start->puan);
	   start=start->sonraki;
	 }
	 
	 printf("Ortalama:%f",ort/kisi);
}



int main()
{
	int n;
	struct Ogrenci *goz;
	goz=NULL;
	
	printf("Ogrenci Eklemek icin 1\n");
	printf("Ogrencileri goruntulemek icin 2\n");
	printf("Cikis icin 3'e basiniz.\n");
	scanf("%d",&n);
	
	while ( n!=3)
	 {	
	 	 if (n==1)
	 	 goz=Ekle(goz);
	 	 
	 	 if(n==2)
	 	  print(goz);
	 	  printf("Secim Giriniz:");
	 	  scanf("%d",&n);
	 	  
	 }
	 
	 return 0;
	 
		

	
	
}
