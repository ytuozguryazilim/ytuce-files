#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct Student{
	int grade;
	char name[32];
	struct Student *next;
};
struct Student *ilkStudent=NULL;
struct Student *sonStudent=NULL;
struct Student *silinmedenOncekiStudent =NULL;
void yeniListeOlustur(){
		
	struct Student *yeniStudent = (struct Student*)malloc(sizeof(struct Student)); 
	
	
		yeniStudent->next=NULL;
		printf("Ogrencinin ismini giriniz : ");
		scanf("%s",&(yeniStudent)->name);
		
		printf("\nOgrencinin notunu giriniz : ");
		scanf("%d",&(yeniStudent)->grade);
		ilkStudent=sonStudent=yeniStudent;
}
void Input(){
	
	if(ilkStudent==NULL){
		yeniListeOlustur();
	}
	else{
		struct Student *yeniStudent = (struct Student*)malloc(sizeof(struct Student));
		printf("Ogrencinin ismini giriniz : ");
		scanf("%s",&(yeniStudent)->name);
		printf("Ogrencinin notunu giriniz : ");
		scanf("%d",&(yeniStudent)->grade);
		if(ilkStudent==sonStudent){
			ilkStudent->next=yeniStudent;
			yeniStudent->next = NULL;
			sonStudent=yeniStudent;
		}
		else{
			sonStudent->next = yeniStudent;
			yeniStudent->next = NULL;
			sonStudent = yeniStudent;
		}	
	}
			
}
void Output(){
	struct Student *students = ilkStudent;
	while(students != NULL){
		printf("%s  notu :  %d\n",students->name,students->grade);
		students=students->next;
	}
}
 struct Student *notaGoreAra(int *not){
	struct Student *temp = ilkStudent; 
	while(temp!=NULL){
		if(temp->grade==not){
			printf("%s bulundu notu : %d",temp->name,temp->grade);
			return temp;
		}
			silinmedenOncekiStudent=temp;	
			temp=temp->next;
	}
	printf("Boyle bir ogrenci Bulunamadi!!!");
	return NULL;
}
void studentSilme(int *not){
	struct Student *silinecekStudent=NULL;
	silinecekStudent=notaGoreAra(not);
	if(silinecekStudent != NULL){
		printf(" Silindi\n");
		if(silinecekStudent==ilkStudent){
			ilkStudent=silinecekStudent->next;
		}
		else{
			silinmedenOncekiStudent->next=silinecekStudent->next;
		}
		free(silinecekStudent);
	}
	else{
		printf("\n Bulunamadi\n");
	}
	Output();
}	

int main(int argc, char *argv[]) {
	int i , urunSayisi,m=0;
	while(m!=4){
	printf("1.Ogrenci Ekleme\n");
	printf("2.Ogrenci Silme\n");
	printf("3.Goruntuleme\n");
	printf("4.Cikis\n");
	scanf("%d",&m);
	if(m==1){
		Input();
	}
	if(m==2){
		printf("\n Silmek isteginiz notu giriniz\n");
		int silinecek;
		scanf("%d",&silinecek);
		studentSilme(silinecek);
	} 
	if(m==3){
		Output();	
	}
	}
	return 0;
}			
			
			
		
		
		
		
		
	
	

	
		
	

	
	
	
	


