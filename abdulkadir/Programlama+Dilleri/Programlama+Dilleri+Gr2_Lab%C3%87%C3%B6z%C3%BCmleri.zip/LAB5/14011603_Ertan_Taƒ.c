#include <stdio.h>
#include <stdlib.h>

struct student{
	char name[20];
	int grade;
	struct student *next;
};
typedef struct student std;
typedef std *stdptr;

stdptr head=NULL;

stdptr createnode();
void ekle();
void sil(int);
void listele();

int main(){
	int sec=0;
	int osayi;
	int i=0;
	int silnot;
	
	
	
	
	while(sec!=4){
		printf("\n1-)Ogrenci Ekleme\n2-)Ogrenci Silme\n3-)Goruntuleme\n4-)Cikis\nSecim:");
		scanf("%d",&sec);
	
		if(sec==1){
			ekle();		
		}
		
		if(sec==2){
			printf("Silmek �stediginiz Notu Giriniz:");
			scanf("%d",&silnot);
			sil(silnot);
		}
		
		
		if(sec==3){
			listele();
			
		}
	}
	

	
	
}

void ekle(){
	stdptr tmp=head;
	stdptr new=createnode();
	printf("Ogrenci ismini giriniz: ");
	scanf("%s",&new->name);
	
	printf("Ogrenci notunu giriniz: ");
	scanf("%d",&new->grade);
	
	if(head==NULL){
		head=new;
	}
	else{
		while(tmp->next!=NULL){
			tmp=tmp->next;
		}
		tmp->next=new;
	}
		
}

void sil(int not){
	stdptr tmp2=head;
	stdptr before=head;
	int bul=0;
	
	if(head->grade==not){
		head=head->next;
		free(tmp2);	
		bul=1;	
	}
	
	else {
		while(tmp2->next!=NULL&&bul==0){
			tmp2=tmp2->next;
			
			if(tmp2->grade==not){
				
				bul=1;
				before->next=tmp2->next;
				free(tmp2);
			}
			else{
			before=tmp2;
			}
		}
		
	}
	
	if(bul==1){
		printf("\nSilme Basarili\n");
	}
	
	if(bul==0){
		printf("\nSilme Basarisiz\n");
	}
	
	
}

void listele(){
	stdptr tmp=head;
	printf("\nAD\tNOT\n");
	while(tmp!=NULL){
		printf("%s\t%d\n",tmp->name,tmp->grade);
		tmp=tmp->next;
	}
}

stdptr createnode(){
	stdptr node=(stdptr)malloc(sizeof(std));
	node->next=NULL;
	return node;
}
