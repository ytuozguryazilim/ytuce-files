#include <stdio.h>
#include <stdlib.h>

 struct student{
	char isim[32];
	int not;
	
	struct student *next;
	
};

struct student *fstudent=NULL;
struct student *lstudent=NULL;
void ilkOgrOlustur(){
	
	struct student *newStudent = (struct student*)malloc(sizeof(struct student));
	
	printf("\nOgrencinin ismini giriniz\n");
	scanf("%s",&(newStudent)-> isim);
	printf("\nOgrencinin notunu giriniz\n");
	scanf("%d",&(newStudent)->not);
	
	newStudent->next=NULL;
	
	fstudent=lstudent=newStudent;
	
	
	
}

void OgrEkle(){
	if(fstudent==NULL){
		
		ilkOgrOlustur();
		
	}else{
		struct student *newStudent = (struct student*)malloc(sizeof(struct student));
		
		printf("\nOgrencinin ismini giriniz\n");
		scanf("%s",&(newStudent)-> isim);
		printf("\nOgrencinin notunu giriniz\n");
		scanf("%d",&(newStudent)->not);
		
		if(fstudent==lstudent){
			
			fstudent->next = newStudent;
			
			newStudent->next = NULL;
			
			lstudent = newStudent;
			
			
			}else{
			
			lstudent->next=newStudent;
			
			newStudent->next = NULL;
			
			lstudent=newStudent;
				
			
		}
		
		
	}
	

}

void goruntuleme(){
	
	struct student *temp = fstudent;
	
	printf("\nVAR OLAN OGRENCILER\n");
	
	while(temp!=NULL){
		
		printf("%s : %d\n\n",temp->isim,temp->not);
		
		temp=temp->next;
		
		
		
		
	}
	
	
	
	
}


struct student *arananOgr = NULL;

struct student *arama(int note){
	struct student *temp;
	temp=fstudent;
	
	while(temp!=NULL){
		
		if(temp->not == note){
			
		return temp;	
			
		}
		
		arananOgr=temp;
		
		temp=temp->next;
	}
	
	return NULL;
	
	
}

void silme(int note){
	struct student *temp = NULL;
	temp=arama(note);
	if(temp==fstudent){
		
		fstudent=temp->next;
		
	}else{
		
		arananOgr->next=temp->next;
		
	}
	
	
	
	
}








int main(int argc, char *argv[]) {
	int j=0;
	
	while(j<1){
	
	printf("1-OGRENCI EKLEME\n");
	printf("2-OGRENCI SILME \n");
	printf("3-GORUNTULEME \n");
	printf("4-CIKIS\n");
	
	int i,secim,ogrenciSayisi ;
	
	scanf("%d",&secim);
	
	if(secim==1){
		printf("\nKac adet ogrenci gireceksiniz\n"	);
		
		scanf("%d",&ogrenciSayisi);
		
		for(i=0;i<ogrenciSayisi;i++){
		
			OgrEkle();
				
		}
		
		
	}else if(secim==2){
	goruntuleme();
	int note;
	printf("\nSILMEK ISTEGINIZ OGRENCININ NOTUNU GIRINIZ : ");
	
	scanf("%d",&note);
				
	silme(note);
				
		
		
	}else if(secim==3){
		
	goruntuleme();		
		
	}else if(secim==4 ){
		return -1;
	}
	
	




}
	return 0;
}
