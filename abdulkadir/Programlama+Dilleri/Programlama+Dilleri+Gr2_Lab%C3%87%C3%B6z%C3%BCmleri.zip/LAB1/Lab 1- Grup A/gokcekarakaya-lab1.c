#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{   srand(time(NULL));
    int m,n,i,j;
    int **ar;
    printf("satir sayisini giriniz: \n");
    scanf("%d",&m);
    printf("satir sayisindan farkli olacak sekilde sutun sayisini giriniz: \n");
    scanf("%d",&n);
    ar=(int**)malloc(m*sizeof(int*));
    for(i=0;i<m;i++){
        ar[i]=(int*)malloc(n*sizeof(int));
    }
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            printf("dizinin A[%d][%d].ci elemanini giriniz \n ",i,j);
            scanf("%d",&ar[i][j]);

        }

    }

    printf("\n");
    printf("\n");
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            printf(" %d ",ar[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    printf("A dizisinin 0 olmayan elemanlarinin satir numaralari: \n ");
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            if(ar[i][j]!=0){
            printf(" %d ",i);
            }
        }
    }
    printf(" \n A dizisinin degeri 0 olmayan elemanlarinin sutun numaralari: \n");
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            if(ar[i][j]!=0){
                printf(" %d ",j);
            }
        }
    }
    printf(" \n A dizisinin degeri 0 olmayan elemanlarinin degerleri: \n");
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            if(ar[i][j]!=0){

                printf(" %d ",ar[i][j]);
            }
        }
    }


}
