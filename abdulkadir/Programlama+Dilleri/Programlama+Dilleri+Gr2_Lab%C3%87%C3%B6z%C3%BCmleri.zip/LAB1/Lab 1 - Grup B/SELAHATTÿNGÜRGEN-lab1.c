#include<stdio.h>
#include<stdlib.h>
int main()
{
    int **mat,x,i,y,j,b[4][4],s,g;
    printf("Satir sayisini giriniz\n");
    scanf("%d",&x);
    printf("Sutun sayisini giriniz\n");
    scanf("%d",&y);
    mat=(int **) malloc(x*sizeof(int*));
    printf("Degerleri giriniz\n");

    for(i=0;i<x;i++)
    {

        mat[i]=(int *) malloc(y*sizeof(int));
        for(j=0;j<y;j++)
        {
            printf(" %d. satir %d.sutun degerini giriniz=  ",(i+1),(j+1));
            scanf("%d",&mat[i][j]);
        }
    }
    for(i=0;i<x;i++)
    {
        printf("\n");

        for(j=0;j<y;j++)
        {
            printf("%d",mat[i][j]);
        }
    }
    printf("\n\n****ISTENILEN MATRIS****\n\n");
    for(i=0;i<=3;i++)
    {
        for(j=0;j<=3;j++)
        {
            b[i][j]=0;
        }
    }
    for(i=0;i<x;i++)
    {
        for(j=0;j<y-1;j++)
        {
            s=mat[i][j];
            g=mat[i][j+1];
            b[s][g]++;



        }

    }
    for(i=0;i<=3;i++)
    {
        printf("\n");

        for(j=0;j<=3;j++)
        {
            printf("%d",b[i][j]);
        }
    }



    return 0;
}

