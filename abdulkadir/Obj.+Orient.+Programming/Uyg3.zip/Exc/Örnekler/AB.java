
import java.io.*;

class A {

    public void basla() throws FileNotFoundException, EOFException {
	// ...
    } 
}     

public class AB extends A  {
    public void basla() throws  IOException {
	//...
    }
}
