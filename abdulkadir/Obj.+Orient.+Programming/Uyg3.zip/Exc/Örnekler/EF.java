import java.io.*;

class E {

    public void basla() throws  IOException {
	// ...
    } 
}     

public class EF extends E  {
    public void basla()  {
	//...
    }
}
