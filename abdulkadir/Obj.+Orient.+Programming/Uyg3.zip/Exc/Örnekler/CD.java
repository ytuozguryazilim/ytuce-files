
import java.io.*;

class C {

    public void basla() throws  IOException {
	// ...
    } 
}     

public class CD extends C  {
    public void basla() throws FileNotFoundException, EOFException {
	//...
    }
}
