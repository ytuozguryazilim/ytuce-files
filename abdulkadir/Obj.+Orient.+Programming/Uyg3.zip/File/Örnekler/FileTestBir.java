

import java.io.*;

public class FileTestBir {

    public static void main(String[] args) throws IOException {
	
	File dosya = new File("Test1.txt");
    }

}
