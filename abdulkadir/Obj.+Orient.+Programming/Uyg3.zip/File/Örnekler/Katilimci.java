

public class Katilimci extends Aday {

    public void sarkiSoyle() {
	System.out.println("Selamlar ben "+isim+soyad);
	// sarki soyleme islemi
    }


}
