
import java.io.*;

class Calisan {

	public void calis(int deger) throws IOException {
		System.out.println("Calisan calisiyor "+ deger);
	} 
}     

public class Sekreter extends Calisan {

	public void calis(int deger) throws FileNotFoundException, EOFException {
		
		System.out.println("Calisan calisiyor "+ deger);
		if(deger == 0) {
			throw new  FileNotFoundException("Dosyayi bulamadim");
		} else if(deger == 1) {
			throw new  EOFException("Dosyanin sonuna geldim");
		}  
	}


	public static void basla(Calisan c, int deger)  {
		try {
			c.calis(deger);   
		} catch (IOException ex) {
			System.out.println("Istisna olustu: "+ ex);
		}
		
	}

	public static void main(String args[]) {
		Sekreter s1 = new Sekreter();
		Sekreter s2 = new Sekreter();
		Sekreter s3 = new Sekreter();
		basla(s1,2); //  sorunsuz
		basla(s1,1); //  EOFException
		basla(s3,0); //  FileNotFoundException

	}  
}
