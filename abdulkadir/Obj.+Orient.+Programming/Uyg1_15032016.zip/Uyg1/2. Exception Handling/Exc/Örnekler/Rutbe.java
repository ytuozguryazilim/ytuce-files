

public class Rutbe {

    public static void main(String args[]) {
        try { 
            throw new Throwable();
        } catch ( Exception ex ) {
            System.out.println(" istisna yakalandi : " + ex);
        }
        
    }  
}
