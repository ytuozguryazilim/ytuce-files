
public class DiziErisim {


    public static void main(String args[]) {

        int sayilar[] = {1,2,3,4};
        System.out.println("Basla");
        for (int i=0 ; i < 5 ; i++) {
            System.out.println("--> " + sayilar[i]);
        } 
        System.out.println("Bitti");
    }
}
