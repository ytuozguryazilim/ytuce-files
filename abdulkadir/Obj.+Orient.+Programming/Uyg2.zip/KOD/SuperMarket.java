
import java.util.ArrayList;

public class SuperMarket {

	public static void main(String args[]) {

		String  meyva1 = "elma";
		String  meyva2  = "portakal";
		String  meyva3  = "mandalina";


		// alis veris basliyor
		ArrayList torba = new ArrayList();
		torba.add(meyva1);
		torba.add(meyva2);
		torba.add(meyva3);

		

		// alis veris bitti, kasaya odeme yapma zamani
		for (int i=0; i<torba.size(); i++) {
			String alinan = (String) torba.get(i); // dikkat
			System.out.println( alinan + " --> odeme yapildi");
		}
	}
}



