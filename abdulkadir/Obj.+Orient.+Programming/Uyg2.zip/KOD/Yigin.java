

import java.util.LinkedList;


public class Yigin {

    private LinkedList torba = new LinkedList();

    public void veriAt(Object o) {
	torba.addFirst(o);
    }
    
    public Object veriCek() {
	return torba.removeFirst();
    }


    public static void main(String[] args) {
	
	String u1 = "Turkiye" ; 
	String u2 = "Japonya" ; 
	String u3 = "Almanya" ; 
	
	Yigin y = new Yigin();
	y.veriAt(u3);
	y.veriAt(u2);
	System.out.println(" --> " + y.veriCek());
	y.veriAt(u1);
	System.out.println(" --> " + y.veriCek());
    }
}



